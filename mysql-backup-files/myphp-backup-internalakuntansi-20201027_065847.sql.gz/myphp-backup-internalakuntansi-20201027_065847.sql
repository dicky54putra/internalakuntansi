CREATE DATABASE IF NOT EXISTS `internalakuntansi`;

USE `internalakuntansi`;

SET foreign_key_checks = 0;

DROP TABLE IF EXISTS `akt_akun`;

CREATE TABLE `akt_akun` (
  `id_akun` int(11) NOT NULL AUTO_INCREMENT,
  `kode_akun` varchar(200) NOT NULL,
  `nama_akun` varchar(200) NOT NULL,
  `saldo_akun` int(11) NOT NULL,
  `header` int(11) NOT NULL,
  `parent` int(11) NOT NULL,
  `jenis` int(11) NOT NULL,
  `klasifikasi` int(11) NOT NULL,
  `status_aktif` int(11) NOT NULL,
  `saldo_normal` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id_akun`)
) ENGINE=InnoDB AUTO_INCREMENT=134 DEFAULT CHARSET=latin1;

INSERT INTO `akt_akun` VALUES (1,"AK001","kas",0,1,1,1,1,1,1),
(2,"AK002","Piutang Usaha",2147483647,1,1,1,3,1,1),
(3,"AK003","Perlengkapan (Barang Habis Pakai)",0,1,1,1,1,1,1),
(5,"AK005","Kendaraan Mobil",0,1,1,2,1,1,1),
(6,"AK006","Akumulasi Depresiasi - Mobil",0,1,1,2,1,1,2),
(7,"AK007","Peralatan Kantor ",0,1,1,2,1,1,1),
(8,"AK008","Akumulasi Depresiasi - Peralatan Kantor",0,1,1,2,1,1,2),
(37,"AK037","Piutang Wesel",0,1,1,1,4,1,1),
(38,"AK038","Uang Muka Pembelian",1000,1,1,1,7,1,1),
(39,"AK039","Tanah",0,1,1,2,1,1,1),
(40,"AK040","Gedung",0,1,1,2,1,1,1),
(41,"AK041","Beban Dibayar di Muka",0,1,1,1,12,1,1),
(42,"AK042","Mesin ",0,0,1,2,10,1,1),
(43,"AK043","PPH Pasal 21",0,1,1,8,23,1,2),
(44,"AK044","PPH 25/Final 0,5%",0,1,1,8,23,1,1),
(45,"AK045","Cadangan Kerugian Piutang",0,1,1,1,6,1,2),
(46,"AK046","Alat Angkut",0,0,1,2,10,1,1),
(47,"AK047","Hutang Pengiriman",0,1,1,5,13,1,2),
(48,"AK048","Cadangan Kerugian Piutang Tak Tertagih",0,0,1,1,6,1,1),
(49,"AK049","Sewa Dibayar di Muka",0,0,1,1,12,1,1),
(50,"AK050","Iklan Dibayar di Muka",0,0,1,1,12,1,1),
(51,"AK051","Asuransi Dibayar di Muka",0,0,1,1,12,1,1),
(53,"AK053","PPN Masukan",810600,0,1,1,12,1,1),
(54,"AK054","Uang Muka PPH",0,0,1,1,12,1,1),
(55,"AK055","Akumulasi Penyusutan Bangunan ",0,0,1,2,12,1,2),
(56,"AK056","Akumulasi Penyusunan Kendaraan ",0,0,1,2,12,1,2),
(57,"AK057","Akumulasi Penyusutan Mesin ",0,0,1,2,12,1,2),
(58,"AK058","Hak Paten (Trade Mark)",0,0,1,3,11,1,1),
(59,"AK059","Hak Cipta ",0,1,1,3,11,1,1),
(60,"AK060","Goodwill",0,0,1,3,11,1,1),
(61,"AK061","Merk",0,0,1,3,11,1,1),
(62,"AK062","Hak Sewa",0,0,1,3,11,1,1),
(63,"AK063","Franchise",0,0,1,3,11,1,1),
(64,"AK064","Hutang Usaha ",9201080,0,1,6,16,1,2),
(65,"AK065","Hutang Gaji ",0,0,1,5,28,1,2),
(66,"AK066","Pendapatan  Diterima di Muka",0,0,1,5,15,1,2),
(67,"AK067","Beban yang Masih Harus Dibayar",0,0,1,5,13,1,2),
(68,"AK068","Hutang Bank",0,1,1,6,16,1,2),
(69,"AK069","Wesel Bayar ",0,0,1,6,13,1,2),
(70,"AK070","Hutang Hipotek",0,0,1,6,16,1,2),
(71,"AK071","Hutang Obligasi",0,0,1,6,16,1,2),
(72,"AK072","Hutang Pemegang Saham",0,0,1,6,16,1,2),
(73,"AK073","PPN Keluaran",0,0,1,5,17,1,2),
(74,"AK074","Hutang Dividen ",0,0,1,6,17,1,2),
(75,"AK075","Hutang Lain-Lain",0,0,1,6,17,1,2),
(76,"AK076","Modal",0,0,1,7,18,1,2),
(77,"AK077","Prive",0,0,1,7,19,1,1),
(78,"AK078","Ikhtisar Laba Rugi",0,0,1,7,20,1,2),
(79,"AK079","Laba Ditahan",0,0,1,7,20,1,2),
(80,"AK080","Laba Tahun Berjalan",0,0,1,7,20,1,2),
(81,"AK081","Deviden",0,0,1,7,18,1,1),
(82,"AK082","Pendapatan ",0,0,1,4,21,1,2),
(83,"AK083","Beban Angkut Penjualan",0,0,1,4,25,1,1),
(84,"AK084","Denda Bayar Lambat",0,0,1,4,21,1,2),
(85,"AK085","Potongan Penjualan",0,0,1,4,21,1,1),
(86,"AK086","Pendapatan Diluar Usaha",0,0,1,4,26,1,2),
(87,"AK087","Pendapatan Bunga",0,0,1,4,21,1,2),
(88,"AK088","Pendapatan Dividen",0,0,1,4,21,1,2),
(89,"AK089","Pendapatan Lain-lain",0,0,1,4,26,1,2),
(90,"AK090","Penjualan",0,0,1,4,21,1,2),
(91,"AK091","Retur Penjualan",0,0,1,4,21,1,1),
(92,"AK092","Beban BBM",0,1,1,8,24,1,1),
(93,"AK093","Beban Sewa Kantor",0,1,1,8,24,1,1),
(94,"AK094","Beban Rental Mobil",0,0,1,8,24,1,1),
(95,"AK095","Beban Gaji",0,1,1,8,24,1,1),
(96,"AK096","Beban Listrik, Air, Telepon",0,1,1,8,24,1,1),
(97,"AK097","Beban Perlengkapan",0,0,1,8,24,1,1),
(98,"AK098","Beban Iklan",0,0,1,8,24,1,1),
(99,"AK099","Beban Perbaikan Kendaraan ",0,1,1,8,25,1,1),
(100,"AK100","Beban Bunga",0,1,1,8,24,1,1),
(101,"AK101","Beban Asuransi",0,1,1,8,24,1,1),
(102,"AK102","Beban ATK",0,1,1,8,25,1,1),
(103,"AK103","Beban Akumulasi Penyusutan Mesin",0,1,1,8,24,1,1),
(104,"AK104","Beban Akumulasi Penyusutan Bangunan",0,1,1,8,25,1,1),
(105,"AK105","Beban Akumulasi Penyusutan Peralatan",0,1,1,8,25,1,1),
(106,"AK106","Beban Akumulasi Penyusutan Kendaraan",0,1,1,8,25,1,1),
(107,"AK107","Beban Kerugian Piutang",0,1,1,8,25,1,1),
(108,"AK108","Beban Denda",0,1,1,8,25,1,1),
(109,"AK109","Beban Pemeliharaan Aset/Mesin/Kendaraan/Gedung/Bangunan",0,1,1,8,25,1,1),
(110,"AK110","Beban Pajak Penghasilan",0,1,1,8,24,1,1),
(111,"AK111","Beban Administrasi Bank",0,0,1,8,25,1,1),
(112,"AK112","Laba Rugi Penjualan Kendaraan",0,1,1,8,23,1,2),
(113,"AK113","Beban Lain-lain",0,1,1,8,23,1,1),
(114,"AK114","HPP",0,1,1,8,18,1,1),
(115,"AK115","Biaya Admin Kantor",106000,1,1,8,25,1,1),
(116,"AK116","Retur Pembelian",0,1,1,8,25,1,1),
(117,"AK117","Persediaan Barang Dagang",-2147462168,1,1,1,7,1,1),
(118,"AK118","Diskon Penjualan",0,1,1,4,18,1,1),
(119,"AK119","Saldo Awal Modal ",400000000,0,1,7,18,1,2),
(120,"AK120","Saham Biasa",0,0,1,7,18,1,2),
(121,"AK121","Pembelian Barang",0,1,1,8,24,1,1),
(122,"AK122","Piutang Pengiriman",155000,1,1,1,6,1,1),
(123,"AK123","Beban Penyusutan Gedung",0,1,1,8,23,1,1),
(124,"AK124","PPH 23",0,1,1,8,23,1,1),
(125,"AK125","PPH 22",0,1,1,8,23,1,2),
(126,"AK126","bunga dibayar dimuka",0,1,1,1,12,1,1),
(127,"AK127","Gaji dibayar dimuka",0,0,1,1,12,1,1),
(128,"AK128","Pajak dibayar dimuka",0,1,1,1,12,1,1),
(129,"AK129","biaya sampel",0,1,1,8,23,1,1),
(130,"AK130","Bonus Barang",0,1,1,4,21,1,2),
(131,"AK131","Uang Muka Penjualan",0,1,1,4,15,1,2),
(132,"AK132","Bangunan",0,1,1,2,10,1,1),
(133,"AK133","Aset Tetap",0,1,1,2,10,1,1);


DROP TABLE IF EXISTS `akt_approver`;

CREATE TABLE `akt_approver` (
  `id_approver` int(11) NOT NULL AUTO_INCREMENT,
  `id_login` int(11) DEFAULT NULL,
  `id_jenis_approver` int(11) NOT NULL,
  `tingkat_approver` int(11) NOT NULL,
  PRIMARY KEY (`id_approver`)
) ENGINE=InnoDB AUTO_INCREMENT=77 DEFAULT CHARSET=latin1;

INSERT INTO `akt_approver` VALUES (45,5,1,3),
(46,6,1,2),
(47,6,1,1),
(51,17,3,1),
(52,NULL,3,1),
(57,17,6,1),
(58,11,6,1),
(59,17,7,1),
(60,11,7,1),
(63,NULL,9,1),
(64,NULL,9,1),
(65,NULL,10,2),
(66,NULL,10,1),
(69,17,15,1),
(70,NULL,15,1),
(73,4,17,1),
(74,NULL,17,1),
(75,NULL,18,1),
(76,NULL,18,1);


DROP TABLE IF EXISTS `akt_bom`;

CREATE TABLE `akt_bom` (
  `id_bom` int(11) NOT NULL AUTO_INCREMENT,
  `no_bom` varchar(11) NOT NULL,
  `keterangan` text NOT NULL,
  `tipe` varchar(200) NOT NULL,
  `id_item_stok` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `total` double NOT NULL,
  `tanggal_approve` date DEFAULT NULL,
  `id_login` int(11) DEFAULT NULL,
  `status_bom` int(2) NOT NULL,
  PRIMARY KEY (`id_bom`),
  KEY `id_login` (`id_login`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



DROP TABLE IF EXISTS `akt_bom_detail_bb`;

CREATE TABLE `akt_bom_detail_bb` (
  `id_bom_detail_bb` int(11) NOT NULL AUTO_INCREMENT,
  `id_bom` int(11) NOT NULL,
  `id_item_stok` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `harga` double NOT NULL,
  `keterangan` text NOT NULL,
  PRIMARY KEY (`id_bom_detail_bb`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



DROP TABLE IF EXISTS `akt_bom_detail_hp`;

CREATE TABLE `akt_bom_detail_hp` (
  `id_bom_hasil_detail_hp` int(11) NOT NULL AUTO_INCREMENT,
  `id_bom` int(11) NOT NULL,
  `id_item_stok` int(11) NOT NULL,
  PRIMARY KEY (`id_bom_hasil_detail_hp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



DROP TABLE IF EXISTS `akt_cek_giro`;

CREATE TABLE `akt_cek_giro` (
  `id_cek_giro` int(11) NOT NULL AUTO_INCREMENT,
  `no_transaksi` varchar(11) NOT NULL,
  `no_cek_giro` varchar(11) NOT NULL,
  `tanggal_terbit` date NOT NULL,
  `tanggal_effektif` date NOT NULL,
  `tipe` int(11) NOT NULL,
  `in_out` int(11) NOT NULL,
  `id_bank_asal` int(11) NOT NULL,
  `id_mata_uang` int(11) NOT NULL,
  `jumlah` double NOT NULL,
  `cabang_bank` varchar(20) NOT NULL,
  `tanggal_kliring` date NOT NULL,
  `bank_kliring` varchar(20) NOT NULL,
  `id_penerbit` int(11) NOT NULL,
  `id_penerima` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_cek_giro`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



DROP TABLE IF EXISTS `akt_depresiasi_harta_tetap`;

CREATE TABLE `akt_depresiasi_harta_tetap` (
  `id_depresiasi_harta_tetap` int(11) NOT NULL AUTO_INCREMENT,
  `kode_depresiasi` varchar(20) NOT NULL,
  `tanggal` date NOT NULL,
  `id_pembelian_harta_tetap_detail` int(11) NOT NULL,
  `nilai` bigint(20) NOT NULL,
  PRIMARY KEY (`id_depresiasi_harta_tetap`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



DROP TABLE IF EXISTS `akt_gmb_dua`;

CREATE TABLE `akt_gmb_dua` (
  `id_gmb_dua` int(11) NOT NULL AUTO_INCREMENT,
  `kode_gmb_dua` varchar(200) NOT NULL,
  `keterangan_gmb_dua` text NOT NULL,
  `level_gmb_dua` int(11) NOT NULL,
  PRIMARY KEY (`id_gmb_dua`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `akt_gmb_satu`;

CREATE TABLE `akt_gmb_satu` (
  `id_gmb_satu` int(11) NOT NULL AUTO_INCREMENT,
  `kode_gmb_satu` varchar(200) NOT NULL,
  `keterangan_gmb_satu` text NOT NULL,
  `level_gmb_satu` int(11) NOT NULL,
  PRIMARY KEY (`id_gmb_satu`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `akt_gmb_tiga`;

CREATE TABLE `akt_gmb_tiga` (
  `id_gmb_tiga` int(11) NOT NULL AUTO_INCREMENT,
  `kode_gmb_tiga` varchar(200) NOT NULL,
  `keterangan_gmb_tiga` text NOT NULL,
  `level_gmb_tiga` int(11) NOT NULL,
  PRIMARY KEY (`id_gmb_tiga`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `akt_gudang`;

CREATE TABLE `akt_gudang` (
  `id_gudang` int(11) NOT NULL AUTO_INCREMENT,
  `kode_gudang` varchar(200) NOT NULL,
  `nama_gudang` varchar(200) NOT NULL,
  `status_aktif_gudang` int(11) NOT NULL,
  PRIMARY KEY (`id_gudang`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `akt_gudang` VALUES (1,"GD001","SAKAMED 01",1),
(2,"GD002","MASKER COVID",1);


DROP TABLE IF EXISTS `akt_harta_tetap`;

CREATE TABLE `akt_harta_tetap` (
  `id_harta_tetap` int(11) NOT NULL AUTO_INCREMENT,
  `kode` varchar(50) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `id_kelompok_harta_tetap` int(11) NOT NULL,
  `tipe` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id_harta_tetap`),
  KEY `id_kelompok_harta_tetap` (`id_kelompok_harta_tetap`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



DROP TABLE IF EXISTS `akt_history_transaksi`;

CREATE TABLE `akt_history_transaksi` (
  `id_history_transaksi` int(11) NOT NULL AUTO_INCREMENT,
  `id_tabel` int(11) DEFAULT NULL,
  `id_jurnal_umum` int(11) NOT NULL,
  `nama_tabel` varchar(50) NOT NULL,
  PRIMARY KEY (`id_history_transaksi`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4;

INSERT INTO `akt_history_transaksi` VALUES (5,4,33,"akt_penjualan"),
(6,5,34,"akt_penjualan"),
(7,2,230,"akt_kas_bank"),
(8,3,36,"akt_saldo_awal_kas"),
(9,1,232,"akt_kas_bank"),
(10,4,37,"akt_saldo_awal_kas"),
(11,NULL,240,"akt_kas_bank"),
(14,1,40,"akt_pembelian");


DROP TABLE IF EXISTS `akt_item`;

CREATE TABLE `akt_item` (
  `id_item` int(11) NOT NULL AUTO_INCREMENT,
  `kode_item` varchar(200) NOT NULL,
  `barcode_item` varchar(200) DEFAULT NULL,
  `nama_item` varchar(200) NOT NULL,
  `nama_alias_item` varchar(200) DEFAULT NULL,
  `id_tipe_item` int(11) NOT NULL,
  `id_merk` int(11) DEFAULT NULL,
  `id_satuan` int(11) DEFAULT NULL,
  `id_mitra_bisnis` int(11) DEFAULT NULL,
  `keterangan_item` text,
  `status_aktif_item` int(11) NOT NULL,
  PRIMARY KEY (`id_item`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `akt_item` VALUES (1,"AI001","","KERTAS PUYER","",1,1,2,1,"",1),
(2,"AI002","","MASKER","PENUTUP WAJAH",1,1,5,5,"1 PAK ISI 50 PCS",1),
(3,"AI003","","FACE SHIELD","PELINDUNG WAJAH",1,2,2,7,"BISA DILIPAT",1);


DROP TABLE IF EXISTS `akt_item_harga_jual`;

CREATE TABLE `akt_item_harga_jual` (
  `id_item_harga_jual` int(11) NOT NULL AUTO_INCREMENT,
  `id_item` int(11) NOT NULL,
  `id_mata_uang` int(11) NOT NULL,
  `id_level_harga` int(11) NOT NULL,
  `harga_satuan` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_item_harga_jual`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `akt_item_harga_jual` VALUES (1,1,1,1,40),
(2,2,1,2,165000),
(3,3,1,2,17500);


DROP TABLE IF EXISTS `akt_item_stok`;

CREATE TABLE `akt_item_stok` (
  `id_item_stok` int(11) NOT NULL AUTO_INCREMENT,
  `id_item` int(11) NOT NULL,
  `id_gudang` int(11) NOT NULL,
  `location` varchar(200) DEFAULT NULL,
  `qty` int(11) NOT NULL,
  `hpp` int(11) NOT NULL,
  `min` int(11) NOT NULL,
  PRIMARY KEY (`id_item_stok`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `akt_item_stok` VALUES (1,1,1,"KIRI A2",300000,27,0),
(2,2,2,"JAWA TIMUR",0,150000,5),
(3,3,2,"JAWA TIMUR",0,15000,5);


DROP TABLE IF EXISTS `akt_item_tipe`;

CREATE TABLE `akt_item_tipe` (
  `id_tipe_item` int(11) NOT NULL AUTO_INCREMENT,
  `nama_tipe_item` varchar(200) NOT NULL,
  PRIMARY KEY (`id_tipe_item`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

INSERT INTO `akt_item_tipe` VALUES (1,"Barang Jadi"),
(2,"Biaya Tenaga Kerja"),
(3,"Barang Hasil Produksi"),
(4,"Barang Lain-lain"),
(5,"Paket"),
(6,"Bahan Pembantu"),
(7,"Bahan Baku"),
(8,"Jasa"),
(9,"Work In Progress");


DROP TABLE IF EXISTS `akt_jenis_approver`;

CREATE TABLE `akt_jenis_approver` (
  `id_jenis_approver` int(11) NOT NULL AUTO_INCREMENT,
  `nama_jenis_approver` varchar(50) NOT NULL,
  PRIMARY KEY (`id_jenis_approver`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4;

INSERT INTO `akt_jenis_approver` VALUES (1,"Pengajuan Biaya"),
(2,"Permintaan Pembelian"),
(3,"Order Pembelian"),
(4,"Pembelian"),
(5,"Penerimaan Pembelian"),
(6,"Pembelian Harta Tetap"),
(7,"Retur Pembelian"),
(8,"Permintaan Barang"),
(9,"Bill Of Material"),
(10,"Produksi Bill Of Material"),
(13,"Penawaran Penjualan"),
(15,"Order Penjualan"),
(17,"Retur Penjualan"),
(18,"Penjualan Harta Tetap");


DROP TABLE IF EXISTS `akt_jurnal_umum`;

CREATE TABLE `akt_jurnal_umum` (
  `id_jurnal_umum` int(11) NOT NULL AUTO_INCREMENT,
  `no_jurnal_umum` varchar(50) NOT NULL,
  `tanggal` date NOT NULL,
  `tipe` int(11) NOT NULL,
  `keterangan` text,
  PRIMARY KEY (`id_jurnal_umum`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4;

INSERT INTO `akt_jurnal_umum` VALUES (1,"JU2010001","2020-10-15",1,"Set saldo awal kas : SW2010001"),
(2,"JU2010002","2020-10-15",1,"Set saldo awal kas : SW2010002"),
(3,"JU2010003","2020-10-15",1,"Order Pembelian : PO2010001"),
(9,"JU2010004","2020-10-16",1,"Pembelian : PE2010002"),
(11,"JU2010005","2020-10-16",1,"Pembelian : PE2010003"),
(27,"JU2010006","2020-10-17",1,"Pembelian : PE2010004"),
(33,"JU2010007","2020-10-17",1,"Order Penjualan : OP2010001"),
(34,"JU2010008","2020-10-17",1,"Order Penjualan : OP2010002"),
(35,"JU2010009","2020-10-20",1,NULL),
(36,"JU2010010","2020-10-20",1,"Set saldo awal kas : SW2010003"),
(37,"JU2010011","2020-10-20",1,"Set saldo awal kas : SW2010004"),
(40,"JU2010013","2020-10-20",1,"Pembelian : PE2010001");


DROP TABLE IF EXISTS `akt_jurnal_umum_detail`;

CREATE TABLE `akt_jurnal_umum_detail` (
  `id_jurnal_umum_detail` int(11) NOT NULL AUTO_INCREMENT,
  `id_jurnal_umum` int(11) NOT NULL,
  `id_akun` int(11) NOT NULL,
  `debit` int(11) DEFAULT '0',
  `kredit` int(11) DEFAULT '0',
  `keterangan` text,
  PRIMARY KEY (`id_jurnal_umum_detail`),
  KEY `id_jurnal_umum` (`id_jurnal_umum`),
  KEY `id_akun` (`id_akun`)
) ENGINE=InnoDB AUTO_INCREMENT=255 DEFAULT CHARSET=utf8mb4;

INSERT INTO `akt_jurnal_umum_detail` VALUES (1,1,1,50000000,0,NULL),
(2,1,119,0,50000000,NULL),
(3,2,1,50000000,0,NULL),
(4,2,119,0,50000000,NULL),
(5,3,117,8100000,0,"Order Pembelian : PO2010001"),
(6,3,64,0,8945000,"Order Pembelian : PO2010001"),
(7,3,53,810000,0,"Order Pembelian : PO2010001"),
(8,3,122,35000,0,"Order Pembelian : PO2010001"),
(9,3,115,0,0,"Order Pembelian : PO2010001"),
(10,3,38,0,0,"Order Pembelian : PO2010001"),
(11,3,1,0,0,"Order Pembelian : PO2010001"),
(47,9,117,100000,0,"Pembelian : PE2010002"),
(48,9,64,0,200000,"Pembelian : PE2010002"),
(49,9,53,0,0,"Pembelian : PE2010002"),
(50,9,122,100000,0,"Pembelian : PE2010002"),
(51,9,115,0,0,"Pembelian : PE2010002"),
(52,9,38,0,0,"Pembelian : PE2010002"),
(53,9,1,0,0,"Pembelian : PE2010002"),
(61,11,117,2000,0,"Pembelian : PE2010003"),
(62,11,64,0,2000,"Pembelian : PE2010003"),
(63,11,53,0,0,"Pembelian : PE2010003"),
(64,11,122,0,0,"Pembelian : PE2010003"),
(65,11,115,0,0,"Pembelian : PE2010003"),
(66,11,38,1000,0,"Pembelian : PE2010003"),
(67,11,1,0,1000,"Pembelian : PE2010003"),
(173,27,117,6000,0,"Pembelian : PE2010004"),
(174,27,64,0,32600,"Pembelian : PE2010004"),
(175,27,53,600,0,"Pembelian : PE2010004"),
(176,27,122,20000,0,"Pembelian : PE2010004"),
(177,27,115,6000,0,"Pembelian : PE2010004"),
(178,27,38,0,0,"Pembelian : PE2010004"),
(179,27,1,0,0,"Pembelian : PE2010004"),
(215,33,117,0,2147483647,"Order Penjualan : OP2010001"),
(216,33,2,2147483647,0,"Order Penjualan : OP2010001"),
(217,33,73,0,0,"Order Penjualan : OP2010001"),
(218,33,47,0,0,"Order Penjualan : OP2010001"),
(219,33,115,0,0,"Order Penjualan : OP2010001"),
(220,33,131,0,0,"Order Penjualan : OP2010001"),
(221,33,1,0,0,"Order Penjualan : OP2010001"),
(222,34,117,0,400,"Order Penjualan : OP2010002"),
(223,34,2,400,0,"Order Penjualan : OP2010002"),
(224,34,73,0,0,"Order Penjualan : OP2010002"),
(225,34,47,0,0,"Order Penjualan : OP2010002"),
(226,34,115,0,0,"Order Penjualan : OP2010002"),
(227,34,131,0,0,"Order Penjualan : OP2010002"),
(228,34,1,0,0,"Order Penjualan : OP2010002"),
(229,35,115,100000,0,"beli kalkulator dan bolpoin kantor"),
(230,36,1,100000000,0,NULL),
(231,36,119,0,100000000,NULL),
(232,37,1,200000000,0,NULL),
(233,37,119,0,200000000,NULL),
(248,40,117,21480,0,"Pembelian : PE2010001"),
(249,40,64,0,21480,"Pembelian : PE2010001"),
(250,40,53,0,0,"Pembelian : PE2010001"),
(251,40,122,0,0,"Pembelian : PE2010001"),
(252,40,115,0,0,"Pembelian : PE2010001"),
(253,40,38,0,0,"Pembelian : PE2010001"),
(254,40,1,0,0,"Pembelian : PE2010001");


DROP TABLE IF EXISTS `akt_kas_bank`;

CREATE TABLE `akt_kas_bank` (
  `id_kas_bank` int(11) NOT NULL AUTO_INCREMENT,
  `kode_kas_bank` varchar(123) NOT NULL,
  `keterangan` text NOT NULL,
  `jenis` varchar(123) NOT NULL,
  `id_mata_uang` int(11) NOT NULL,
  `saldo` int(11) DEFAULT '0',
  `total_giro_keluar` int(11) DEFAULT '0',
  `id_akun` int(11) DEFAULT '0',
  `status_aktif` int(11) NOT NULL,
  PRIMARY KEY (`id_kas_bank`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `akt_kas_bank` VALUES (1,"KB001","Bank BCA",2,1,249998100,0,1,1),
(2,"KB002","Kas Utama",1,1,150000000,0,1,1);


DROP TABLE IF EXISTS `akt_kelompok_harta_tetap`;

CREATE TABLE `akt_kelompok_harta_tetap` (
  `id_kelompok_harta_tetap` int(11) NOT NULL AUTO_INCREMENT,
  `kode` varchar(50) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `umur_ekonomis` int(11) NOT NULL,
  `metode_depresiasi` int(11) NOT NULL,
  `id_akun_harta` int(11) NOT NULL,
  `id_akun_akumulasi` int(11) NOT NULL,
  `id_akun_depresiasi` int(11) NOT NULL,
  `keterangan` text NOT NULL,
  PRIMARY KEY (`id_kelompok_harta_tetap`),
  KEY `id_akun_depresiasi` (`id_akun_depresiasi`),
  KEY `id_akun_akumulasi` (`id_akun_akumulasi`),
  KEY `id_akun_harta` (`id_akun_harta`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;

INSERT INTO `akt_kelompok_harta_tetap` VALUES (1,"KH001","BANGUNAN",20,2,132,55,104,"-"),
(2,"KH002","MESIN",5,2,42,57,103,"-"),
(3,"KH003","KENDARAAN",10,2,5,56,106,"");


DROP TABLE IF EXISTS `akt_klasifikasi`;

CREATE TABLE `akt_klasifikasi` (
  `id_klasifikasi` int(11) NOT NULL AUTO_INCREMENT,
  `klasifikasi` varchar(50) NOT NULL,
  PRIMARY KEY (`id_klasifikasi`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4;

INSERT INTO `akt_klasifikasi` VALUES (1,"Kas"),
(2,"Bank"),
(3,"Piutang Usaha"),
(4,"Piutang Non Usaha"),
(5,"Piutang Pajak"),
(6,"Piutang Lainnya"),
(7,"Persedian"),
(8,"Biaya Bayar Di Muka"),
(9,"Investasi Jangka Panjang"),
(10,"Harta Tetap Berwujud"),
(11,"Harta Tetap Tidak Berwujud"),
(12,"Harta Lainnya"),
(13,"Hutang Lancar"),
(14,"Hutang Pajak"),
(15,"Pendapatan Di Terima Di Muka"),
(16,"Hutang Jangka Panjang"),
(17,"Hutang Lainnya"),
(18,"Modal"),
(19,"Prive"),
(20,"Laba"),
(21,"Pendapatan Usaha"),
(22,"Biaya Produksi"),
(23,"Biaya Lain"),
(24,"Biaya Operasional"),
(25,"Biaya Non Operasional"),
(26,"Pendapatan Luar Usaha"),
(27,"Pengeluaran Luar Usaha"),
(28,"Hutang Jangka Pendek");


DROP TABLE IF EXISTS `akt_kota`;

CREATE TABLE `akt_kota` (
  `id_kota` int(11) NOT NULL AUTO_INCREMENT,
  `kode_kota` varchar(123) NOT NULL,
  `nama_kota` varchar(123) NOT NULL,
  PRIMARY KEY (`id_kota`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `akt_kota` VALUES (1,"KT001","Brebes");


DROP TABLE IF EXISTS `akt_laba_rugi`;

CREATE TABLE `akt_laba_rugi` (
  `id_laba_rugi` int(11) NOT NULL AUTO_INCREMENT,
  `tanggal` date NOT NULL,
  `periode` int(11) NOT NULL,
  `id_login` int(11) DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `tanggal_approve` datetime NOT NULL,
  PRIMARY KEY (`id_laba_rugi`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

INSERT INTO `akt_laba_rugi` VALUES (1,"2020-10-23",1,17,1,"2020-10-23 02:42:47"),
(2,"2020-10-23",1,17,1,"2020-10-23 02:43:40");


DROP TABLE IF EXISTS `akt_laba_rugi_detail`;

CREATE TABLE `akt_laba_rugi_detail` (
  `id_laba_rugi_detail` int(11) NOT NULL AUTO_INCREMENT,
  `id_laba_rugi` int(11) NOT NULL,
  `id_akun` int(11) NOT NULL,
  `saldo_akun` int(20) NOT NULL,
  PRIMARY KEY (`id_laba_rugi_detail`)
) ENGINE=InnoDB AUTO_INCREMENT=87 DEFAULT CHARSET=utf8mb4;

INSERT INTO `akt_laba_rugi_detail` VALUES (1,1,43,0),
(2,1,44,0),
(3,1,82,0),
(4,1,83,0),
(5,1,84,0),
(6,1,85,0),
(7,1,86,0),
(8,1,87,0),
(9,1,88,0),
(10,1,89,0),
(11,1,90,0),
(12,1,91,0),
(13,1,92,0),
(14,1,93,0),
(15,1,94,0),
(16,1,95,0),
(17,1,96,0),
(18,1,97,0),
(19,1,98,0),
(20,1,99,0),
(21,1,100,0),
(22,1,101,0),
(23,1,102,0),
(24,1,103,0),
(25,1,104,0),
(26,1,105,0),
(27,1,106,0),
(28,1,107,0),
(29,1,108,0),
(30,1,109,0),
(31,1,110,0),
(32,1,111,0),
(33,1,112,0),
(34,1,113,0),
(35,1,115,106000),
(36,1,116,0),
(37,1,121,0),
(38,1,123,0),
(39,1,124,0),
(40,1,125,0),
(41,1,129,0),
(42,1,130,0),
(43,1,131,0),
(44,2,43,0),
(45,2,44,0),
(46,2,82,0),
(47,2,83,0),
(48,2,84,0),
(49,2,85,0),
(50,2,86,0),
(51,2,87,0),
(52,2,88,0),
(53,2,89,0),
(54,2,90,0),
(55,2,91,0),
(56,2,92,0),
(57,2,93,0),
(58,2,94,0),
(59,2,95,0),
(60,2,96,0),
(61,2,97,0),
(62,2,98,0),
(63,2,99,0),
(64,2,100,0),
(65,2,101,0),
(66,2,102,0),
(67,2,103,0),
(68,2,104,0),
(69,2,105,0),
(70,2,106,0),
(71,2,107,0),
(72,2,108,0),
(73,2,109,0),
(74,2,110,0),
(75,2,111,0),
(76,2,112,0),
(77,2,113,0),
(78,2,115,106000),
(79,2,116,0),
(80,2,121,0),
(81,2,123,0),
(82,2,124,0),
(83,2,125,0),
(84,2,129,0),
(85,2,130,0),
(86,2,131,0);


DROP TABLE IF EXISTS `akt_laporan_ekuitas`;

CREATE TABLE `akt_laporan_ekuitas` (
  `id_laporan_ekuitas` int(11) NOT NULL AUTO_INCREMENT,
  `id_laba_rugi` int(11) NOT NULL,
  `prive` int(20) NOT NULL,
  `modal` int(20) DEFAULT '0',
  `laba_bersih` int(20) NOT NULL,
  `setor_tambahan` int(20) DEFAULT '0',
  PRIMARY KEY (`id_laporan_ekuitas`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

INSERT INTO `akt_laporan_ekuitas` VALUES (1,1,0,0,-106000,0),
(2,2,0,0,-106000,NULL);


DROP TABLE IF EXISTS `akt_laporan_posisi_keuangan`;

CREATE TABLE `akt_laporan_posisi_keuangan` (
  `id_laporan_posisi_keuangan` int(11) NOT NULL AUTO_INCREMENT,
  `id_laba_rugi` int(11) NOT NULL,
  `id_akun` int(11) NOT NULL,
  `nominal` int(20) NOT NULL,
  PRIMARY KEY (`id_laporan_posisi_keuangan`)
) ENGINE=InnoDB AUTO_INCREMENT=109 DEFAULT CHARSET=utf8mb4;

INSERT INTO `akt_laporan_posisi_keuangan` VALUES (1,1,1,0),
(2,1,2,2147483647),
(3,1,3,0),
(4,1,5,0),
(5,1,6,0),
(6,1,7,0),
(7,1,8,0),
(8,1,37,0),
(9,1,38,1000),
(10,1,39,0),
(11,1,40,0),
(12,1,41,0),
(13,1,42,0),
(14,1,45,0),
(15,1,46,0),
(16,1,47,0),
(17,1,48,0),
(18,1,49,0),
(19,1,50,0),
(20,1,51,0),
(21,1,53,1110600),
(22,1,54,0),
(23,1,55,0),
(24,1,56,0),
(25,1,57,0),
(26,1,64,12621080),
(27,1,65,0),
(28,1,66,0),
(29,1,67,0),
(30,1,68,0),
(31,1,69,0),
(32,1,70,0),
(33,1,71,0),
(34,1,72,0),
(35,1,73,0),
(36,1,74,0),
(37,1,75,0),
(38,1,76,0),
(39,1,77,0),
(40,1,78,0),
(41,1,79,0),
(42,1,80,0),
(43,1,81,0),
(44,1,114,0),
(45,1,117,-2147462168),
(46,1,118,0),
(47,1,119,400000000),
(48,1,120,0),
(49,1,122,275000),
(50,1,126,0),
(51,1,127,0),
(52,1,128,0),
(53,1,132,0),
(54,1,133,3000000),
(55,2,1,0),
(56,2,2,2147483647),
(57,2,3,0),
(58,2,5,0),
(59,2,6,0),
(60,2,7,0),
(61,2,8,0),
(62,2,37,0),
(63,2,38,1000),
(64,2,39,0),
(65,2,40,0),
(66,2,41,0),
(67,2,42,0),
(68,2,45,0),
(69,2,46,0),
(70,2,47,0),
(71,2,48,0),
(72,2,49,0),
(73,2,50,0),
(74,2,51,0),
(75,2,53,1110600),
(76,2,54,0),
(77,2,55,0),
(78,2,56,0),
(79,2,57,0),
(80,2,64,12621080),
(81,2,65,0),
(82,2,66,0),
(83,2,67,0),
(84,2,68,0),
(85,2,69,0),
(86,2,70,0),
(87,2,71,0),
(88,2,72,0),
(89,2,73,0),
(90,2,74,0),
(91,2,75,0),
(92,2,76,0),
(93,2,77,0),
(94,2,78,0),
(95,2,79,0),
(96,2,80,0),
(97,2,81,0),
(98,2,114,0),
(99,2,117,-2147462168),
(100,2,118,0),
(101,2,119,400000000),
(102,2,120,0),
(103,2,122,275000),
(104,2,126,0),
(105,2,127,0),
(106,2,128,0),
(107,2,132,0),
(108,2,133,3000000);


DROP TABLE IF EXISTS `akt_level_harga`;

CREATE TABLE `akt_level_harga` (
  `id_level_harga` int(11) NOT NULL AUTO_INCREMENT,
  `kode_level_harga` varchar(20) NOT NULL,
  `keterangan` text NOT NULL,
  PRIMARY KEY (`id_level_harga`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;

INSERT INTO `akt_level_harga` VALUES (1,"LH001","Retail"),
(2,"LH002","Grosir"),
(3,"LH003","Reseller");


DROP TABLE IF EXISTS `akt_mata_uang`;

CREATE TABLE `akt_mata_uang` (
  `id_mata_uang` int(11) NOT NULL AUTO_INCREMENT,
  `kode_mata_uang` varchar(123) NOT NULL,
  `mata_uang` varchar(123) NOT NULL,
  `simbol` varchar(123) NOT NULL,
  `kurs` varchar(123) NOT NULL,
  `fiskal` varchar(123) NOT NULL,
  `rate_type` varchar(123) NOT NULL,
  `status_default` int(11) NOT NULL,
  PRIMARY KEY (`id_mata_uang`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `akt_mata_uang` VALUES (1,"IDR","Rupiah","Rp",0,0,1,1);


DROP TABLE IF EXISTS `akt_merk`;

CREATE TABLE `akt_merk` (
  `id_merk` int(11) NOT NULL AUTO_INCREMENT,
  `kode_merk` varchar(200) NOT NULL,
  `nama_merk` varchar(200) NOT NULL,
  PRIMARY KEY (`id_merk`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `akt_merk` VALUES (1,"MI001","SAKAMED"),
(2,"MI002","JUPITER");


DROP TABLE IF EXISTS `akt_mitra_bisnis`;

CREATE TABLE `akt_mitra_bisnis` (
  `id_mitra_bisnis` int(11) NOT NULL AUTO_INCREMENT,
  `kode_mitra_bisnis` varchar(200) NOT NULL,
  `nama_mitra_bisnis` varchar(200) NOT NULL,
  `deskripsi_mitra_bisnis` text,
  `tipe_mitra_bisnis` int(11) NOT NULL,
  `id_gmb_satu` int(11) DEFAULT NULL,
  `id_gmb_dua` int(11) DEFAULT NULL,
  `id_gmb_tiga` int(11) DEFAULT NULL,
  `id_level_harga` int(11) DEFAULT NULL,
  `id_sales` int(11) DEFAULT NULL,
  `status_mitra_bisnis` int(11) NOT NULL,
  PRIMARY KEY (`id_mitra_bisnis`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

INSERT INTO `akt_mitra_bisnis` VALUES (1,"MB001","PT. MEGAPRINT","SEMARANG- KERTAS PUYER",2,NULL,NULL,NULL,NULL,NULL,1),
(2,"MB002","CV. KOMPUTER JAYA","",2,NULL,NULL,NULL,NULL,NULL,1),
(3,"MB003","CV. GARUDA SARANA SEJAHTERA","",1,NULL,NULL,NULL,NULL,NULL,1),
(4,"MB004","PT. MANDIRI PRIMA MULTIALKESINDO","",1,NULL,NULL,NULL,NULL,NULL,1),
(5,"MB005","UD. MITRA JAYA","TRENGGALEK",1,NULL,NULL,NULL,NULL,NULL,1),
(6,"MB006","Wisnu","qwe",2,NULL,NULL,NULL,1,NULL,1),
(7,"MB007","PT. PLASTIK MELAMBUNG","ALAT-ALAT KESEHATAN",2,NULL,NULL,NULL,0,0,1);


DROP TABLE IF EXISTS `akt_mitra_bisnis_alamat`;

CREATE TABLE `akt_mitra_bisnis_alamat` (
  `id_mitra_bisnis_alamat` int(11) NOT NULL AUTO_INCREMENT,
  `id_mitra_bisnis` int(11) NOT NULL,
  `keterangan_alamat` text NOT NULL,
  `alamat_lengkap` text NOT NULL,
  `id_kota` int(11) NOT NULL,
  `telephone` varchar(200) DEFAULT NULL,
  `fax` varchar(200) DEFAULT NULL,
  `kode_pos` varchar(200) DEFAULT NULL,
  `alamat_pengiriman_penagihan` int(11) NOT NULL,
  PRIMARY KEY (`id_mitra_bisnis_alamat`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `akt_mitra_bisnis_bank_pajak`;

CREATE TABLE `akt_mitra_bisnis_bank_pajak` (
  `id_mitra_bisnis_bank_pajak` int(11) NOT NULL AUTO_INCREMENT,
  `id_mitra_bisnis` int(11) NOT NULL,
  `nama_bank` varchar(200) NOT NULL,
  `no_rekening` varchar(200) NOT NULL,
  `atas_nama` varchar(200) NOT NULL,
  `npwp` varchar(200) DEFAULT NULL,
  `pkp` varchar(200) DEFAULT NULL,
  `tanggal_pkp` date DEFAULT NULL,
  `no_nik` varchar(200) DEFAULT NULL,
  `atas_nama_nik` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id_mitra_bisnis_bank_pajak`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `akt_mitra_bisnis_kontak`;

CREATE TABLE `akt_mitra_bisnis_kontak` (
  `id_mitra_bisnis_kontak` int(11) NOT NULL AUTO_INCREMENT,
  `id_mitra_bisnis` int(11) NOT NULL,
  `nama_kontak` varchar(200) NOT NULL,
  `jabatan` varchar(200) DEFAULT NULL,
  `handphone` varchar(200) DEFAULT NULL,
  `email` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id_mitra_bisnis_kontak`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `akt_mitra_bisnis_pembelian_penjualan`;

CREATE TABLE `akt_mitra_bisnis_pembelian_penjualan` (
  `id_mitra_bisnis_pembelian_penjualan` int(11) NOT NULL AUTO_INCREMENT,
  `id_mitra_bisnis` int(11) NOT NULL,
  `id_mata_uang` int(11) NOT NULL,
  `termin_pembelian` int(11) NOT NULL,
  `tempo_pembelian` int(11) NOT NULL,
  `termin_penjualan` int(11) NOT NULL,
  `tempo_penjualan` int(11) NOT NULL,
  `batas_hutang` varchar(200) NOT NULL,
  `batas_frekuensi_hutang` varchar(200) NOT NULL,
  `id_akun_hutang` int(11) NOT NULL,
  `batas_piutang` varchar(200) NOT NULL,
  `batas_frekuensi_piutang` varchar(200) NOT NULL,
  `id_akun_piutang` int(11) NOT NULL,
  PRIMARY KEY (`id_mitra_bisnis_pembelian_penjualan`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `akt_pajak`;

CREATE TABLE `akt_pajak` (
  `id_pajak` int(11) NOT NULL AUTO_INCREMENT,
  `kode_pajak` varchar(20) NOT NULL,
  `nama_pajak` varchar(100) NOT NULL,
  `id_akun_pembelian` int(11) NOT NULL,
  `id_akun_penjualan` int(11) NOT NULL,
  `presentasi_npwp` varchar(100) NOT NULL,
  `presentasi_non_npwp` varchar(100) NOT NULL,
  PRIMARY KEY (`id_pajak`),
  KEY `id_akun_pembelian` (`id_akun_pembelian`),
  KEY `id_akun_penjualan` (`id_akun_penjualan`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



DROP TABLE IF EXISTS `akt_pegawai`;

CREATE TABLE `akt_pegawai` (
  `id_pegawai` int(11) NOT NULL AUTO_INCREMENT,
  `kode_pegawai` varchar(20) NOT NULL,
  `nama_pegawai` varchar(100) NOT NULL,
  `alamat` text NOT NULL,
  `id_kota` int(11) NOT NULL,
  `kode_pos` varchar(20) DEFAULT NULL,
  `telepon` varchar(20) DEFAULT NULL,
  `handphone` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `status_aktif` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id_pegawai`),
  KEY `id_kota` (`id_kota`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



DROP TABLE IF EXISTS `akt_pembayaran_biaya`;

CREATE TABLE `akt_pembayaran_biaya` (
  `id_pembayaran_biaya` int(11) NOT NULL AUTO_INCREMENT,
  `tanggal_pembayaran_biaya` date NOT NULL,
  `id_pembelian` int(11) NOT NULL,
  `cara_bayar` int(11) NOT NULL,
  `id_kas_bank` int(11) NOT NULL,
  `nominal` int(11) NOT NULL,
  `keterangan` text,
  PRIMARY KEY (`id_pembayaran_biaya`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



DROP TABLE IF EXISTS `akt_pembayaran_biaya_harta_tetap`;

CREATE TABLE `akt_pembayaran_biaya_harta_tetap` (
  `id_pembayaran_biaya_harta_tetap` int(11) NOT NULL AUTO_INCREMENT,
  `tanggal_pembayaran_biaya` date NOT NULL,
  `id_pembelian_harta_tetap` int(11) NOT NULL,
  `cara_bayar` int(11) NOT NULL,
  `id_kas_bank` int(11) NOT NULL,
  `nominal` int(11) NOT NULL,
  `keterangan` text NOT NULL,
  PRIMARY KEY (`id_pembayaran_biaya_harta_tetap`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `akt_pembelian`;

CREATE TABLE `akt_pembelian` (
  `id_pembelian` int(11) NOT NULL AUTO_INCREMENT,
  `no_order_pembelian` varchar(255) DEFAULT NULL,
  `tanggal_order_pembelian` date DEFAULT NULL,
  `id_customer` int(11) NOT NULL,
  `id_sales` int(11) DEFAULT NULL,
  `id_mata_uang` int(11) NOT NULL,
  `no_pembelian` varchar(255) DEFAULT NULL,
  `tanggal_pembelian` date DEFAULT NULL,
  `no_faktur_pembelian` varchar(255) DEFAULT NULL,
  `tanggal_faktur_pembelian` date DEFAULT NULL,
  `ongkir` int(11) DEFAULT NULL,
  `diskon` float DEFAULT NULL,
  `pajak` int(11) DEFAULT NULL,
  `total` int(11) DEFAULT NULL,
  `jenis_bayar` int(11) DEFAULT NULL,
  `jatuh_tempo` int(11) DEFAULT NULL,
  `tanggal_tempo` date DEFAULT NULL,
  `materai` int(11) DEFAULT NULL,
  `id_penagih` int(11) DEFAULT NULL,
  `no_penerimaan` varchar(255) DEFAULT NULL,
  `tanggal_penerimaan` date DEFAULT NULL,
  `pengantar` varchar(255) DEFAULT NULL,
  `keterangan_penerimaan` text,
  `no_spb` varchar(255) DEFAULT NULL,
  `id_mitra_bisnis_alamat` int(11) DEFAULT NULL,
  `penerima` varchar(255) DEFAULT NULL,
  `status` int(11) NOT NULL,
  `tanggal_approve` datetime DEFAULT NULL,
  `id_login` int(11) DEFAULT NULL,
  `uang_muka` int(40) DEFAULT '0',
  `id_kas_bank` int(11) DEFAULT NULL,
  `tanggal_estimasi` date DEFAULT NULL,
  PRIMARY KEY (`id_pembelian`),
  KEY `id_customer` (`id_customer`),
  KEY `id_sales` (`id_sales`),
  KEY `id_mata_uang` (`id_mata_uang`),
  KEY `id_penagih` (`id_penagih`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `akt_pembelian` VALUES (1,NULL,NULL,1,NULL,1,"PE2010001","2020-10-17",NULL,NULL,0,"10.5",0,21480,1,NULL,NULL,0,NULL,"PQ2010001",NULL,NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,0,NULL,NULL);


DROP TABLE IF EXISTS `akt_pembelian_detail`;

CREATE TABLE `akt_pembelian_detail` (
  `id_pembelian_detail` int(11) NOT NULL AUTO_INCREMENT,
  `id_pembelian` int(11) NOT NULL,
  `id_item_stok` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `harga` bigint(20) NOT NULL,
  `diskon` float DEFAULT NULL,
  `total` bigint(20) NOT NULL,
  `keterangan` text NOT NULL,
  PRIMARY KEY (`id_pembelian_detail`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `akt_pembelian_detail` VALUES (1,1,1,12,2000,0,24000,"");


DROP TABLE IF EXISTS `akt_pembelian_harta_tetap`;

CREATE TABLE `akt_pembelian_harta_tetap` (
  `id_pembelian_harta_tetap` int(11) NOT NULL AUTO_INCREMENT,
  `no_pembelian_harta_tetap` varchar(123) NOT NULL,
  `tanggal` date NOT NULL,
  `termin` int(11) DEFAULT NULL,
  `id_kas_bank` int(11) DEFAULT NULL,
  `jatuh_tempo` int(11) DEFAULT NULL,
  `tanggal_tempo` date DEFAULT NULL,
  `id_supplier` int(11) DEFAULT NULL,
  `id_mata_uang` int(11) DEFAULT NULL,
  `no_faktur_pembelian` int(11) DEFAULT NULL,
  `tanggal_faktur_pembelian` date DEFAULT NULL,
  `pajak` int(11) DEFAULT NULL,
  `diskon` int(11) DEFAULT NULL,
  `materai` bigint(20) DEFAULT NULL,
  `keterangan` text NOT NULL,
  `status` int(11) NOT NULL,
  `ongkir` int(11) DEFAULT NULL,
  `jenis_bayar` int(11) DEFAULT NULL,
  `uang_muka` int(20) DEFAULT NULL,
  `id_login` int(11) DEFAULT NULL,
  `tanggal_approve` date DEFAULT NULL,
  PRIMARY KEY (`id_pembelian_harta_tetap`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `akt_pembelian_harta_tetap` VALUES (1,"BT2010001","2020-10-15",NULL,NULL,NULL,NULL,2,1,NULL,NULL,1,0,0,"",3,120000,1,0,17,"2020-10-23");


DROP TABLE IF EXISTS `akt_pembelian_harta_tetap_detail`;

CREATE TABLE `akt_pembelian_harta_tetap_detail` (
  `id_pembelian_harta_tetap_detail` int(11) NOT NULL AUTO_INCREMENT,
  `id_pembelian_harta_tetap` int(11) NOT NULL,
  `kode_pembelian` varchar(20) DEFAULT NULL,
  `qty` int(11) NOT NULL,
  `diskon` int(11) DEFAULT '0',
  `keterangan` text,
  `harga` int(20) NOT NULL,
  `nama_barang` varchar(100) NOT NULL,
  `status` int(11) DEFAULT '1',
  `residu` bigint(20) DEFAULT '0',
  `total` bigint(20) NOT NULL,
  `tipe_harta_tetap` int(11) DEFAULT '0',
  `tanggal_pakai` date DEFAULT NULL,
  `lokasi` varchar(50) DEFAULT NULL,
  `id_kelompok_aset_tetap` int(11) DEFAULT NULL,
  `terhitung_tanggal` date DEFAULT NULL,
  `umur_ekonomis` int(11) DEFAULT '0',
  `beban_per_bulan` bigint(20) DEFAULT '0',
  PRIMARY KEY (`id_pembelian_harta_tetap_detail`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;

INSERT INTO `akt_pembelian_harta_tetap_detail` VALUES (1,1,"HT2010001",1,0,"KOMPUTER HP",3000000,"KOMPUTER",1,0,3000000,0,NULL,NULL,NULL,NULL,0,0);


DROP TABLE IF EXISTS `akt_pembelian_penerimaan`;

CREATE TABLE `akt_pembelian_penerimaan` (
  `id_pembelian_penerimaan` int(11) NOT NULL AUTO_INCREMENT,
  `no_penerimaan` varchar(200) NOT NULL,
  `tanggal_penerimaan` date NOT NULL,
  `penerima` varchar(255) NOT NULL,
  `foto_resi` varchar(255) NOT NULL,
  `id_pembelian` int(11) NOT NULL,
  `pengantar` varchar(200) NOT NULL,
  `keterangan_pengantar` text NOT NULL,
  PRIMARY KEY (`id_pembelian_penerimaan`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `akt_pembelian_penerimaan` VALUES (1,"PQ2010001","2020-10-15","IBNU"," ",1,"HERNI","");


DROP TABLE IF EXISTS `akt_pembelian_penerimaan_detail`;

CREATE TABLE `akt_pembelian_penerimaan_detail` (
  `id_pembelian_penerimaan_detail` int(11) NOT NULL AUTO_INCREMENT,
  `id_pembelian_penerimaan` int(11) NOT NULL,
  `id_pembelian_detail` int(11) NOT NULL,
  `qty_diterima` int(11) NOT NULL,
  `keterangan` text NOT NULL,
  PRIMARY KEY (`id_pembelian_penerimaan_detail`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `akt_pembelian_penerimaan_detail` VALUES (1,1,1,300000,"");


DROP TABLE IF EXISTS `akt_penagih`;

CREATE TABLE `akt_penagih` (
  `id_penagih` int(11) NOT NULL AUTO_INCREMENT,
  `kode_penagih` varchar(20) NOT NULL,
  `nama_penagih` varchar(100) NOT NULL,
  `alamat` text NOT NULL,
  `id_kota` int(11) NOT NULL,
  `kode_pos` varchar(20) NOT NULL,
  `telepon` varchar(20) NOT NULL,
  `handphone` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `status_aktif` int(11) NOT NULL,
  PRIMARY KEY (`id_penagih`),
  KEY `id_kota` (`id_kota`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



DROP TABLE IF EXISTS `akt_penerimaan_pembayaran`;

CREATE TABLE `akt_penerimaan_pembayaran` (
  `id_penerimaan_pembayaran_penjualan` int(11) NOT NULL AUTO_INCREMENT,
  `tanggal_penerimaan_pembayaran` date NOT NULL,
  `id_penjualan` int(11) NOT NULL,
  `cara_bayar` int(11) NOT NULL,
  `id_kas_bank` int(11) NOT NULL,
  `nominal` int(11) NOT NULL,
  `keterangan` text,
  PRIMARY KEY (`id_penerimaan_pembayaran_penjualan`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `akt_penerimaan_pembayaran_harta_tetap`;

CREATE TABLE `akt_penerimaan_pembayaran_harta_tetap` (
  `id_penerimaan_pembayaran_harta_tetap` int(11) NOT NULL AUTO_INCREMENT,
  `tanggal_penerimaan_pembayaran` date NOT NULL,
  `id_penjualan_harta_tetap` int(11) NOT NULL,
  `cara_bayar` int(11) NOT NULL,
  `id_kas_bank` int(11) NOT NULL,
  `nominal` int(11) NOT NULL,
  `keterangan` text NOT NULL,
  PRIMARY KEY (`id_penerimaan_pembayaran_harta_tetap`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `akt_pengajuan_biaya`;

CREATE TABLE `akt_pengajuan_biaya` (
  `id_pengajuan_biaya` int(11) NOT NULL AUTO_INCREMENT,
  `nomor_pengajuan_biaya` varchar(200) NOT NULL,
  `tanggal_pengajuan` date NOT NULL,
  `nomor_purchasing_order` varchar(200) DEFAULT NULL,
  `nomor_kendaraan` varchar(200) DEFAULT NULL,
  `volume` varchar(200) NOT NULL,
  `keterangan_pengajuan` text,
  `dibuat_oleh` int(11) NOT NULL,
  `jenis_bayar` varchar(200) NOT NULL,
  `dibayar_oleh` varchar(200) NOT NULL,
  `dibayar_kepada` varchar(200) NOT NULL,
  `alamat_dibayar_kepada` text,
  `approver1` int(11) DEFAULT NULL,
  `approver2` int(11) DEFAULT NULL,
  `approver3` int(11) DEFAULT NULL,
  `approver1_date` datetime DEFAULT NULL,
  `approver2_date` datetime DEFAULT NULL,
  `approver3_date` datetime DEFAULT NULL,
  `status` int(11) NOT NULL,
  `alasan_reject` text,
  `tanggal_jatuh_tempo` date DEFAULT NULL,
  `sumber_dana` int(11) NOT NULL,
  `status_pembayaran` int(11) NOT NULL,
  PRIMARY KEY (`id_pengajuan_biaya`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



DROP TABLE IF EXISTS `akt_pengajuan_biaya_detail`;

CREATE TABLE `akt_pengajuan_biaya_detail` (
  `id_pengajuan_biaya_detail` int(11) NOT NULL AUTO_INCREMENT,
  `id_pengajuan_biaya` int(11) NOT NULL,
  `id_akun` int(11) NOT NULL,
  `kode_rekening` varchar(200) NOT NULL,
  `nama_pengajuan` varchar(200) NOT NULL,
  `debit` bigint(20) DEFAULT '0',
  `kredit` bigint(20) DEFAULT '0',
  PRIMARY KEY (`id_pengajuan_biaya_detail`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



DROP TABLE IF EXISTS `akt_penjualan`;

CREATE TABLE `akt_penjualan` (
  `id_penjualan` int(11) NOT NULL AUTO_INCREMENT,
  `no_order_penjualan` varchar(200) DEFAULT NULL,
  `tanggal_order_penjualan` date DEFAULT NULL,
  `id_customer` int(11) NOT NULL,
  `id_sales` int(11) DEFAULT NULL,
  `id_mata_uang` int(11) NOT NULL,
  `the_approver` int(11) DEFAULT NULL,
  `the_approver_date` datetime DEFAULT NULL,
  `no_penjualan` varchar(200) DEFAULT NULL,
  `tanggal_penjualan` date DEFAULT NULL,
  `no_faktur_penjualan` varchar(200) DEFAULT NULL,
  `tanggal_faktur_penjualan` date DEFAULT NULL,
  `ongkir` bigint(20) DEFAULT NULL,
  `pajak` bigint(20) DEFAULT NULL,
  `uang_muka` bigint(20) DEFAULT NULL,
  `id_kas_bank` int(11) DEFAULT NULL,
  `total` bigint(20) DEFAULT NULL,
  `diskon` float DEFAULT NULL,
  `jenis_bayar` int(11) DEFAULT NULL,
  `jumlah_tempo` int(11) DEFAULT NULL,
  `tanggal_tempo` date DEFAULT NULL,
  `materai` int(11) DEFAULT NULL,
  `status` int(11) NOT NULL,
  `tanggal_estimasi` date DEFAULT NULL,
  PRIMARY KEY (`id_penjualan`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

INSERT INTO `akt_penjualan` VALUES (3,NULL,NULL,3,1,1,NULL,NULL,"PJ2010001","2020-10-17",NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,NULL),
(4,"OP2010001","2020-10-17",3,NULL,1,11,"2020-10-17 12:28:50","PJ2010002","2020-10-17",NULL,NULL,0,0,0,NULL,40000000000,0,1,NULL,NULL,0,2,"2020-10-17"),
(5,"OP2010002","2020-10-17",3,1,1,11,"2020-10-17 12:30:44","PJ2010003","2020-10-17",NULL,NULL,0,0,0,NULL,400,0,1,NULL,NULL,0,2,"2020-10-28"),
(6,"OP2010003","2020-10-19",3,1,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL),
(7,NULL,NULL,3,3,1,NULL,NULL,"PJ2010004","2020-10-19",NULL,NULL,NULL,NULL,NULL,NULL,7824000,NULL,NULL,NULL,NULL,NULL,2,NULL);


DROP TABLE IF EXISTS `akt_penjualan_detail`;

CREATE TABLE `akt_penjualan_detail` (
  `id_penjualan_detail` int(11) NOT NULL AUTO_INCREMENT,
  `id_penjualan` int(11) NOT NULL,
  `id_item_stok` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `harga` bigint(20) NOT NULL,
  `diskon` float(3,1) DEFAULT '0.0',
  `total` bigint(20) NOT NULL,
  `keterangan` text,
  `id_item_harga_jual` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_penjualan_detail`),
  KEY `id_penjualan` (`id_penjualan`),
  KEY `id_item_stok` (`id_item_stok`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

INSERT INTO `akt_penjualan_detail` VALUES (3,4,1,1000000000,40,"0.0",40000000000,"",1),
(5,5,1,10,40,"0.0",400,"",1),
(12,7,1,100,400000,"80.4",7824000,"",1);


DROP TABLE IF EXISTS `akt_penjualan_harta_tetap`;

CREATE TABLE `akt_penjualan_harta_tetap` (
  `id_penjualan_harta_tetap` int(11) NOT NULL AUTO_INCREMENT,
  `no_penjualan_harta_tetap` varchar(200) NOT NULL,
  `tanggal_penjualan_harta_tetap` date NOT NULL,
  `id_customer` int(11) NOT NULL,
  `id_sales` int(11) DEFAULT NULL,
  `id_mata_uang` int(11) NOT NULL,
  `the_approver` int(11) DEFAULT NULL,
  `the_approver_date` datetime DEFAULT NULL,
  `no_faktur_penjualan_harta_tetap` varchar(200) DEFAULT NULL,
  `tanggal_faktur_penjualan_harta_tetap` date DEFAULT NULL,
  `ongkir` bigint(20) DEFAULT NULL,
  `pajak` bigint(20) DEFAULT NULL,
  `uang_muka` bigint(20) DEFAULT NULL,
  `id_kas_bank` int(11) DEFAULT NULL,
  `total` bigint(20) DEFAULT NULL,
  `diskon` int(11) DEFAULT NULL,
  `jenis_bayar` int(11) DEFAULT NULL,
  `jumlah_tempo` int(11) DEFAULT NULL,
  `tanggal_tempo` date DEFAULT NULL,
  `materai` int(11) DEFAULT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id_penjualan_harta_tetap`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `akt_penjualan_harta_tetap_detail`;

CREATE TABLE `akt_penjualan_harta_tetap_detail` (
  `id_penjualan_harta_tetap_detail` int(11) NOT NULL AUTO_INCREMENT,
  `id_penjualan_harta_tetap` int(11) NOT NULL,
  `id_pembelian_harta_tetap_detail` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `harga` bigint(20) NOT NULL,
  `diskon` float NOT NULL,
  `total` bigint(20) NOT NULL,
  `keterangan` text,
  PRIMARY KEY (`id_penjualan_harta_tetap_detail`),
  KEY `id_penjualan` (`id_penjualan_harta_tetap`),
  KEY `id_item_stok` (`id_pembelian_harta_tetap_detail`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `akt_penjualan_pengiriman`;

CREATE TABLE `akt_penjualan_pengiriman` (
  `id_penjualan_pengiriman` int(11) NOT NULL AUTO_INCREMENT,
  `no_pengiriman` varchar(200) NOT NULL,
  `tanggal_pengiriman` date NOT NULL,
  `pengantar` varchar(200) NOT NULL,
  `keterangan_pengantar` text,
  `foto_resi` varchar(200) DEFAULT NULL,
  `id_penjualan` int(11) NOT NULL,
  `id_mitra_bisnis_alamat` int(11) NOT NULL,
  `penerima` varchar(200) DEFAULT NULL,
  `keterangan_penerima` text,
  `tanggal_penerimaan` date DEFAULT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id_penjualan_pengiriman`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `akt_penjualan_pengiriman_detail`;

CREATE TABLE `akt_penjualan_pengiriman_detail` (
  `id_penjualan_pengiriman_detail` int(11) NOT NULL AUTO_INCREMENT,
  `id_penjualan_pengiriman` int(11) NOT NULL,
  `id_penjualan_detail` int(11) NOT NULL,
  `qty_dikirim` int(11) NOT NULL,
  `keterangan` text,
  PRIMARY KEY (`id_penjualan_pengiriman_detail`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `akt_penyesuaian_kas`;

CREATE TABLE `akt_penyesuaian_kas` (
  `id_penyesuaian_kas` int(11) NOT NULL AUTO_INCREMENT,
  `no_transaksi` varchar(20) NOT NULL,
  `tanggal` date NOT NULL,
  `id_akun` int(11) NOT NULL,
  `id_mitra_bisnis` int(11) NOT NULL,
  `no_referensi` varchar(20) NOT NULL,
  `id_kas_bank` int(11) NOT NULL,
  `id_mata_uang` int(11) NOT NULL,
  `jumlah` double NOT NULL,
  `keterangan` text NOT NULL,
  PRIMARY KEY (`id_penyesuaian_kas`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



DROP TABLE IF EXISTS `akt_penyesuaian_stok`;

CREATE TABLE `akt_penyesuaian_stok` (
  `id_penyesuaian_stok` int(11) NOT NULL AUTO_INCREMENT,
  `no_transaksi` varchar(200) NOT NULL,
  `tanggal_penyesuaian` date NOT NULL,
  `tipe_penyesuaian` int(11) NOT NULL,
  `keterangan_penyesuaian` text,
  PRIMARY KEY (`id_penyesuaian_stok`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `akt_penyesuaian_stok_detail`;

CREATE TABLE `akt_penyesuaian_stok_detail` (
  `id_penyesuaian_stok_detail` int(11) NOT NULL AUTO_INCREMENT,
  `id_penyesuaian_stok` int(11) NOT NULL,
  `id_item_stok` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  PRIMARY KEY (`id_penyesuaian_stok_detail`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `akt_produksi_bom`;

CREATE TABLE `akt_produksi_bom` (
  `id_produksi_bom` int(11) NOT NULL AUTO_INCREMENT,
  `no_produksi_bom` varchar(11) NOT NULL,
  `tanggal` date NOT NULL,
  `id_pegawai` int(11) DEFAULT NULL,
  `id_customer` int(11) DEFAULT NULL,
  `id_bom` int(11) NOT NULL,
  `tipe` varchar(20) NOT NULL,
  `id_akun` int(11) DEFAULT NULL,
  `tanggal_approve` date DEFAULT NULL,
  `id_login` int(11) DEFAULT NULL,
  `status_produksi` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_produksi_bom`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



DROP TABLE IF EXISTS `akt_produksi_bom_detail_bb`;

CREATE TABLE `akt_produksi_bom_detail_bb` (
  `id_produksi_bom_detail_bb` int(11) NOT NULL AUTO_INCREMENT,
  `id_produksi_bom` int(11) NOT NULL,
  `id_item_stok` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `keterangan` text NOT NULL,
  PRIMARY KEY (`id_produksi_bom_detail_bb`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



DROP TABLE IF EXISTS `akt_produksi_bom_detail_hp`;

CREATE TABLE `akt_produksi_bom_detail_hp` (
  `id_produksi_bom_detail_hp` int(11) NOT NULL AUTO_INCREMENT,
  `id_produksi_bom` int(11) NOT NULL,
  `id_item_stok` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `keterangan` text NOT NULL,
  PRIMARY KEY (`id_produksi_bom_detail_hp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



DROP TABLE IF EXISTS `akt_produksi_manual`;

CREATE TABLE `akt_produksi_manual` (
  `id_produksi_manual` int(11) NOT NULL AUTO_INCREMENT,
  `no_produksi_manual` varchar(11) NOT NULL,
  `tanggal` date NOT NULL,
  `id_pegawai` int(11) DEFAULT NULL,
  `id_customer` int(11) NOT NULL,
  `id_akun` int(11) DEFAULT NULL,
  `status_produksi` int(2) DEFAULT '0',
  PRIMARY KEY (`id_produksi_manual`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



DROP TABLE IF EXISTS `akt_produksi_manual_detail_bb`;

CREATE TABLE `akt_produksi_manual_detail_bb` (
  `id_produksi_manual_detail_bb` int(11) NOT NULL AUTO_INCREMENT,
  `id_produksi_manual` int(11) NOT NULL,
  `id_item_stok` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `keterangan` text NOT NULL,
  PRIMARY KEY (`id_produksi_manual_detail_bb`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



DROP TABLE IF EXISTS `akt_produksi_manual_detail_hp`;

CREATE TABLE `akt_produksi_manual_detail_hp` (
  `id_produksi_manual_detail_hp` int(11) NOT NULL AUTO_INCREMENT,
  `id_produksi_manual` int(11) NOT NULL,
  `id_item_stok` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `keterangan` text NOT NULL,
  PRIMARY KEY (`id_produksi_manual_detail_hp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



DROP TABLE IF EXISTS `akt_retur_pembelian`;

CREATE TABLE `akt_retur_pembelian` (
  `id_retur_pembelian` int(11) NOT NULL AUTO_INCREMENT,
  `no_retur_pembelian` varchar(255) NOT NULL,
  `tanggal_retur_pembelian` date NOT NULL,
  `id_pembelian` int(11) NOT NULL,
  `status_retur` int(11) NOT NULL,
  `id_login` int(11) DEFAULT NULL,
  `tanggal_approve` datetime DEFAULT NULL,
  PRIMARY KEY (`id_retur_pembelian`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



DROP TABLE IF EXISTS `akt_retur_pembelian_detail`;

CREATE TABLE `akt_retur_pembelian_detail` (
  `id_retur_pembelian_detail` int(11) NOT NULL AUTO_INCREMENT,
  `id_retur_pembelian` int(11) NOT NULL,
  `id_pembelian_detail` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `retur` int(11) NOT NULL,
  `keterangan` text,
  PRIMARY KEY (`id_retur_pembelian_detail`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



DROP TABLE IF EXISTS `akt_retur_penjualan`;

CREATE TABLE `akt_retur_penjualan` (
  `id_retur_penjualan` int(11) NOT NULL AUTO_INCREMENT,
  `no_retur_penjualan` varchar(200) NOT NULL,
  `tanggal_retur_penjualan` date NOT NULL,
  `id_penjualan_pengiriman` int(11) NOT NULL,
  `status_retur` int(11) NOT NULL,
  `id_login` int(11) NOT NULL DEFAULT '0',
  `tanggal_approve` datetime DEFAULT NULL,
  PRIMARY KEY (`id_retur_penjualan`),
  KEY `id_penjualan` (`id_penjualan_pengiriman`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



DROP TABLE IF EXISTS `akt_retur_penjualan_detail`;

CREATE TABLE `akt_retur_penjualan_detail` (
  `id_retur_penjualan_detail` int(11) NOT NULL AUTO_INCREMENT,
  `id_retur_penjualan` int(11) NOT NULL,
  `id_penjualan_pengiriman_detail` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `retur` int(11) NOT NULL,
  `keterangan` text,
  PRIMARY KEY (`id_retur_penjualan_detail`),
  KEY `id_retur_penjualan` (`id_retur_penjualan`),
  KEY `id_item` (`id_penjualan_pengiriman_detail`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



DROP TABLE IF EXISTS `akt_saldo_awal_akun`;

CREATE TABLE `akt_saldo_awal_akun` (
  `id_saldo_awal_akun` int(11) NOT NULL AUTO_INCREMENT,
  `no_jurnal` varchar(25) NOT NULL,
  `tanggal` date NOT NULL,
  `tipe` int(11) NOT NULL,
  PRIMARY KEY (`id_saldo_awal_akun`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



DROP TABLE IF EXISTS `akt_saldo_awal_akun_detail`;

CREATE TABLE `akt_saldo_awal_akun_detail` (
  `id_saldo_awal_akun_detail` int(11) NOT NULL AUTO_INCREMENT,
  `id_saldo_awal_akun` int(11) NOT NULL,
  `id_akun` int(11) NOT NULL,
  `debet` double DEFAULT '0',
  `kredit` double DEFAULT '0',
  PRIMARY KEY (`id_saldo_awal_akun_detail`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



DROP TABLE IF EXISTS `akt_saldo_awal_kas`;

CREATE TABLE `akt_saldo_awal_kas` (
  `id_saldo_awal_kas` int(11) NOT NULL AUTO_INCREMENT,
  `no_transaksi` varchar(200) NOT NULL,
  `tanggal_transaksi` date NOT NULL,
  `id_kas_bank` int(11) NOT NULL,
  `jumlah` int(11) NOT NULL,
  `keterangan` text,
  PRIMARY KEY (`id_saldo_awal_kas`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO `akt_saldo_awal_kas` VALUES (1,"SW2010001","2020-10-15",1,50000000,""),
(2,"SW2010002","2020-10-15",2,50000000,""),
(3,"SW2010003","2020-09-01",2,100000000,""),
(4,"SW2010004","2020-09-01",1,200000000,"");


DROP TABLE IF EXISTS `akt_saldo_awal_stok`;

CREATE TABLE `akt_saldo_awal_stok` (
  `id_saldo_awal_stok` int(11) NOT NULL AUTO_INCREMENT,
  `no_transaksi` varchar(20) NOT NULL,
  `tanggal` date NOT NULL,
  `tipe` int(11) NOT NULL,
  PRIMARY KEY (`id_saldo_awal_stok`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



DROP TABLE IF EXISTS `akt_saldo_awal_stok_detail`;

CREATE TABLE `akt_saldo_awal_stok_detail` (
  `id_saldo_awal_stok_detail` int(11) NOT NULL AUTO_INCREMENT,
  `id_saldo_awal_stok` int(11) NOT NULL,
  `id_item` int(11) NOT NULL,
  `id_item_stok` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  PRIMARY KEY (`id_saldo_awal_stok_detail`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



DROP TABLE IF EXISTS `akt_sales`;

CREATE TABLE `akt_sales` (
  `id_sales` int(11) NOT NULL AUTO_INCREMENT,
  `kode_sales` varchar(20) NOT NULL,
  `nama_sales` varchar(100) NOT NULL,
  `alamat` text NOT NULL,
  `id_kota` int(11) NOT NULL,
  `kode_pos` varchar(20) DEFAULT NULL,
  `telepon` varchar(20) DEFAULT NULL,
  `handphone` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `status_aktif` int(11) DEFAULT '1',
  PRIMARY KEY (`id_sales`),
  KEY `id_kota` (`id_kota`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;

INSERT INTO `akt_sales` VALUES (1,"SL001","ADITYA","temanggung",0,NULL,081999999999,NULL,"",1),
(3,"SL002","KANTOR","SEMARANG",0,NULL,081999993455,NULL,"",1),
(4,"SL003","REDI","YOGYAKARTA",0,NULL,081578907800,NULL,"",1);


DROP TABLE IF EXISTS `akt_satuan`;

CREATE TABLE `akt_satuan` (
  `id_satuan` int(11) NOT NULL AUTO_INCREMENT,
  `nama_satuan` varchar(200) NOT NULL,
  PRIMARY KEY (`id_satuan`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

INSERT INTO `akt_satuan` VALUES (2,"PCS"),
(3,"LUSIN"),
(5,"PAK");


DROP TABLE IF EXISTS `akt_stok_keluar`;

CREATE TABLE `akt_stok_keluar` (
  `id_stok_keluar` int(11) NOT NULL AUTO_INCREMENT,
  `nomor_transaksi` varchar(200) NOT NULL,
  `tanggal_keluar` date NOT NULL,
  `tipe` int(11) NOT NULL,
  `keterangan` text,
  PRIMARY KEY (`id_stok_keluar`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `akt_stok_keluar_detail`;

CREATE TABLE `akt_stok_keluar_detail` (
  `id_stok_keluar_detail` int(11) NOT NULL AUTO_INCREMENT,
  `id_stok_keluar` int(11) NOT NULL,
  `id_item_stok` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  PRIMARY KEY (`id_stok_keluar_detail`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `akt_stok_masuk`;

CREATE TABLE `akt_stok_masuk` (
  `id_stok_masuk` int(11) NOT NULL AUTO_INCREMENT,
  `nomor_transaksi` varchar(200) NOT NULL,
  `tanggal_masuk` date NOT NULL,
  `tipe` int(11) NOT NULL,
  `keterangan` text,
  PRIMARY KEY (`id_stok_masuk`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `akt_stok_masuk_detail`;

CREATE TABLE `akt_stok_masuk_detail` (
  `id_stok_masuk_detail` int(11) NOT NULL AUTO_INCREMENT,
  `id_stok_masuk` int(11) NOT NULL,
  `id_item_stok` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  PRIMARY KEY (`id_stok_masuk_detail`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `akt_stok_opname`;

CREATE TABLE `akt_stok_opname` (
  `id_stok_opname` int(11) NOT NULL AUTO_INCREMENT,
  `no_transaksi` varchar(200) NOT NULL,
  `tanggal_opname` date NOT NULL,
  `keterangan` text,
  PRIMARY KEY (`id_stok_opname`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `akt_stok_opname_detail`;

CREATE TABLE `akt_stok_opname_detail` (
  `id_stok_opname_detail` int(11) NOT NULL AUTO_INCREMENT,
  `id_stok_opname` int(11) NOT NULL,
  `id_item_stok` int(11) NOT NULL,
  `qty_opname` int(11) NOT NULL,
  `qty_program` int(11) NOT NULL,
  `qty_selisih` int(11) NOT NULL,
  PRIMARY KEY (`id_stok_opname_detail`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `akt_transfer_kas`;

CREATE TABLE `akt_transfer_kas` (
  `id_transfer_kas` int(11) NOT NULL AUTO_INCREMENT,
  `no_transfer_kas` varchar(11) NOT NULL,
  `tanggal` date NOT NULL,
  `id_asal_kas` int(11) NOT NULL,
  `id_tujuan_kas` int(11) NOT NULL,
  `jumlah1` double NOT NULL,
  `jumlah2` double NOT NULL DEFAULT '0',
  `keterangan` text NOT NULL,
  PRIMARY KEY (`id_transfer_kas`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



DROP TABLE IF EXISTS `akt_transfer_stok`;

CREATE TABLE `akt_transfer_stok` (
  `id_transfer_stok` int(11) NOT NULL AUTO_INCREMENT,
  `no_transfer` varchar(200) NOT NULL,
  `tanggal_transfer` date NOT NULL,
  `id_gudang_asal` int(11) NOT NULL,
  `id_gudang_tujuan` int(11) NOT NULL,
  `keterangan` text,
  PRIMARY KEY (`id_transfer_stok`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `akt_transfer_stok_detail`;

CREATE TABLE `akt_transfer_stok_detail` (
  `id_transfer_stok_detail` int(11) NOT NULL AUTO_INCREMENT,
  `id_transfer_stok` int(11) NOT NULL,
  `id_item` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `keterangan` text,
  PRIMARY KEY (`id_transfer_stok_detail`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `foto`;

CREATE TABLE `foto` (
  `id_foto` int(11) NOT NULL AUTO_INCREMENT,
  `nama_tabel` varchar(100) NOT NULL,
  `id_tabel` int(11) NOT NULL,
  `foto` varchar(500) NOT NULL,
  PRIMARY KEY (`id_foto`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;

INSERT INTO `foto` VALUES (1,"pembelian",1,"1602743290_Capture.png");


DROP TABLE IF EXISTS `item_pembelian_harta_tetap`;

CREATE TABLE `item_pembelian_harta_tetap` (
  `id_item_pembelian_harta_tetap` int(11) NOT NULL AUTO_INCREMENT,
  `id_pembelian_harta_tetap` int(11) NOT NULL,
  `id_harta_tetap` int(11) NOT NULL,
  `harga` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `diskon` int(11) NOT NULL,
  `keterangan` text,
  PRIMARY KEY (`id_item_pembelian_harta_tetap`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `jurnal_transaksi`;

CREATE TABLE `jurnal_transaksi` (
  `id_jurnal_transaksi` int(11) NOT NULL AUTO_INCREMENT,
  `nama_transaksi` varchar(100) NOT NULL,
  PRIMARY KEY (`id_jurnal_transaksi`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4;

INSERT INTO `jurnal_transaksi` VALUES (2,"Pembelian Kredit"),
(3,"Pembayaran Transaksi Kredit"),
(4,"Pembelian Cash"),
(6,"Pembayaran Transaksi Cash"),
(7,"Penjualan Kredit"),
(8,"Penerimaan Transaksi Kredit"),
(9,"Penjualan Cash"),
(10,"Penerimaan Transaksi Cash"),
(11,"Stok Masuk"),
(12,"Stok Keluar"),
(13,"Stok Opname"),
(14,"Penyesuaian Stok"),
(15,"Set Saldo Awal Kas"),
(16,"Set Saldo Awal Akun"),
(17,"Retur Pembelian"),
(18,"Retur Penjualan"),
(19,"Pembelian Harta Tetap Kredit"),
(20,"Pembayaran Harta Tetap Transaksi Kredit"),
(21,"Pembelian Harta Tetap Cash"),
(22,"Pembayaran Harta Tetap Transaksi Cash"),
(23,"Penjualan Harta Tetap Kredit"),
(24,"Penerimaan Harta Tetap Transaksi Kredit"),
(25,"Penjualan Harta Tetap Cash"),
(26,"Penerimaan Harta Tetap Transaksi Cash");


DROP TABLE IF EXISTS `jurnal_transaksi_detail`;

CREATE TABLE `jurnal_transaksi_detail` (
  `id_jurnal_transaksi_detail` int(11) NOT NULL AUTO_INCREMENT,
  `id_jurnal_transaksi` int(11) NOT NULL,
  `tipe` varchar(2) NOT NULL,
  `id_akun` int(11) NOT NULL,
  PRIMARY KEY (`id_jurnal_transaksi_detail`)
) ENGINE=InnoDB AUTO_INCREMENT=113 DEFAULT CHARSET=utf8mb4;

INSERT INTO `jurnal_transaksi_detail` VALUES (5,2,"D",117),
(6,2,"K",64),
(7,4,"D",117),
(8,4,"K",64),
(10,7,"K",117),
(11,7,"D",2),
(12,7,"K",73),
(13,6,"D",64),
(14,6,"K",1),
(16,8,"D",1),
(17,8,"K",2),
(18,5,"D",1),
(19,5,"K",90),
(20,5,"D",114),
(22,9,"K",117),
(23,9,"D",2),
(24,10,"D",1),
(25,10,"K",2),
(26,2,"D",53),
(27,2,"D",122),
(28,3,"D",64),
(31,3,"K",1),
(32,7,"K",47),
(33,11,"D",117),
(34,12,"K",117),
(35,13,"K",117),
(36,14,"D",117),
(38,12,"K",78),
(40,12,"D",114),
(41,11,"K",114),
(42,11,"D",78),
(43,11,"K",130),
(45,2,"D",115),
(48,7,"D",115),
(49,7,"K",131),
(50,2,"D",38),
(53,2,"K",1),
(54,4,"D",53),
(55,4,"D",122),
(56,4,"D",115),
(57,4,"D",38),
(58,4,"K",1),
(59,12,"D",130),
(60,7,"D",1),
(61,9,"K",73),
(62,9,"K",47),
(63,9,"D",115),
(64,9,"K",131),
(65,9,"D",1),
(66,15,"D",1),
(67,15,"K",119),
(68,16,"D",119),
(69,16,"K",120),
(70,17,"D",64),
(71,17,"K",117),
(72,18,"D",117),
(74,18,"D",91),
(75,18,"K",114),
(76,18,"K",2),
(77,19,"D",133),
(78,19,"K",64),
(79,19,"D",53),
(80,19,"D",122),
(81,19,"D",115),
(82,19,"D",38),
(83,19,"K",1),
(84,20,"D",64),
(85,20,"K",1),
(86,21,"D",133),
(87,21,"K",64),
(88,21,"D",53),
(89,21,"D",122),
(90,21,"D",115),
(91,21,"D",38),
(92,21,"K",1),
(93,22,"D",64),
(94,22,"K",1),
(95,23,"K",133),
(96,23,"D",2),
(97,23,"K",73),
(98,23,"K",47),
(99,23,"D",115),
(100,23,"K",131),
(101,23,"D",1),
(102,24,"D",1),
(103,24,"K",2),
(104,25,"K",133),
(105,25,"D",2),
(106,25,"K",73),
(107,25,"K",47),
(108,25,"D",115),
(109,25,"K",131),
(110,25,"D",1),
(111,26,"D",1),
(112,26,"K",2);


DROP TABLE IF EXISTS `log`;

CREATE TABLE `log` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `level` int(11) DEFAULT NULL,
  `category` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `log_time` double DEFAULT NULL,
  `prefix` text COLLATE utf8_unicode_ci,
  `message` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1401 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `log` VALUES (1,0,"Login","1602730223.3213","User GSS","Login"),
(2,4,"yii\\db\\Command::execute","1602730223.3215","User GSS","INSERT INTO `log` (`level`, `category`, `log_time`, `prefix`, `message`) VALUES (0, \'Login\', 1602730223.3213, \'User GSS\', \'Login\')"),
(3,4,"yii\\db\\Command::execute","1602730248.9568","User GSS","INSERT INTO `akt_saldo_awal_kas` (`tanggal_transaksi`, `no_transaksi`, `id_kas_bank`, `jumlah`, `keterangan`) VALUES (\'2020-10-15\', \'SW2010001\', 1, 50000000, \'\')"),
(4,4,"yii\\db\\Command::execute","1602730248.9641","User GSS","INSERT INTO `akt_jurnal_umum` (`no_jurnal_umum`, `tanggal`, `keterangan`, `tipe`) VALUES (\'JU2010001\', \'2020-10-15\', \'Set saldo awal kas : SW2010001\', 1)"),
(5,4,"yii\\db\\Command::execute","1602730248.9747","User GSS","UPDATE `akt_kas_bank` SET `saldo`=50000000 WHERE `id_kas_bank`=1"),
(6,4,"yii\\db\\Command::execute","1602730248.976","User GSS","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`) VALUES (1, 1, 50000000)"),
(7,4,"yii\\db\\Command::execute","1602730248.9796","User GSS","INSERT INTO `akt_history_transaksi` (`nama_tabel`, `id_tabel`, `id_jurnal_umum`) VALUES (\'akt_kas_bank\', 1, 1)"),
(8,4,"yii\\db\\Command::execute","1602730248.9823","User GSS","UPDATE `akt_akun` SET `saldo_akun`=50000000 WHERE `id_akun`=119"),
(9,4,"yii\\db\\Command::execute","1602730248.9836","User GSS","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `kredit`) VALUES (1, 119, 50000000)"),
(10,4,"yii\\db\\Command::execute","1602730248.9859","User GSS","INSERT INTO `akt_history_transaksi` (`nama_tabel`, `id_tabel`, `id_jurnal_umum`) VALUES (\'akt_saldo_awal_kas\', 1, 1)"),
(11,4,"yii\\db\\Command::execute","1602730257.8944","User GSS","INSERT INTO `akt_saldo_awal_kas` (`tanggal_transaksi`, `no_transaksi`, `id_kas_bank`, `jumlah`, `keterangan`) VALUES (\'2020-10-15\', \'SW2010002\', 2, 50000000, \'\')"),
(12,4,"yii\\db\\Command::execute","1602730257.898","User GSS","INSERT INTO `akt_jurnal_umum` (`no_jurnal_umum`, `tanggal`, `keterangan`, `tipe`) VALUES (\'JU2010002\', \'2020-10-15\', \'Set saldo awal kas : SW2010002\', 1)"),
(13,4,"yii\\db\\Command::execute","1602730257.9063","User GSS","UPDATE `akt_kas_bank` SET `saldo`=50000000 WHERE `id_kas_bank`=2"),
(14,4,"yii\\db\\Command::execute","1602730257.9075","User GSS","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`) VALUES (2, 1, 50000000)"),
(15,4,"yii\\db\\Command::execute","1602730257.9102","User GSS","INSERT INTO `akt_history_transaksi` (`nama_tabel`, `id_tabel`, `id_jurnal_umum`) VALUES (\'akt_kas_bank\', 2, 3)"),
(16,4,"yii\\db\\Command::execute","1602730257.9124","User GSS","UPDATE `akt_akun` SET `saldo_akun`=100000000 WHERE `id_akun`=119"),
(17,4,"yii\\db\\Command::execute","1602730257.9135","User GSS","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `kredit`) VALUES (2, 119, 50000000)"),
(18,4,"yii\\db\\Command::execute","1602730257.9145","User GSS","INSERT INTO `akt_history_transaksi` (`nama_tabel`, `id_tabel`, `id_jurnal_umum`) VALUES (\'akt_saldo_awal_kas\', 2, 2)"),
(19,0,"Login","1602731213.4285","User GSS","Login"),
(20,4,"yii\\db\\Command::execute","1602731213.4286","User GSS","INSERT INTO `log` (`level`, `category`, `log_time`, `prefix`, `message`) VALUES (0, \'Login\', 1602731213.4285, \'User GSS\', \'Login\')"),
(21,4,"yii\\db\\Command::execute","1602731262.0065","User GSS","INSERT INTO `akt_mitra_bisnis` (`kode_mitra_bisnis`, `nama_mitra_bisnis`, `deskripsi_mitra_bisnis`, `tipe_mitra_bisnis`, `status_mitra_bisnis`) VALUES (\'MB001\', \'PT. MEGAPRINT\', \'SEMARANG- KERTAS PUYER\', 2, 1)"),
(22,4,"yii\\db\\Command::execute","1602731319.6137","User GSS","INSERT INTO `akt_pembelian` (`no_order_pembelian`, `no_pembelian`, `no_penerimaan`, `tanggal_order_pembelian`, `id_customer`, `id_mata_uang`, `status`) VALUES (\'PO2010001\', \'PE2010001\', \'PQ2010001\', \'2020-10-15\', 1, 1, 1)"),
(23,4,"yii\\db\\Command::execute","1602733249.9103","User GSS","INSERT INTO `akt_merk` (`kode_merk`, `nama_merk`) VALUES (\'MI001\', \'SAKAMED\')"),
(24,4,"yii\\db\\Command::execute","1602733310.4682","User GSS","INSERT INTO `akt_item` (`kode_item`, `barcode_item`, `nama_item`, `nama_alias_item`, `id_tipe_item`, `id_merk`, `id_satuan`, `id_mitra_bisnis`, `keterangan_item`, `status_aktif_item`) VALUES (\'AI001\', \'\', \'KERTAS PUYER\', \'\', 1, 1, 2, 1, \'\', 1)"),
(25,4,"yii\\db\\Command::execute","1602733367.9211","User GSS","INSERT INTO `akt_gudang` (`kode_gudang`, `nama_gudang`, `status_aktif_gudang`) VALUES (\'GD001\', \'SAKAMED 01\', 1)"),
(26,4,"yii\\db\\Command::execute","1602733386.9298","User GSS","INSERT INTO `akt_item_stok` (`id_item`, `qty`, `hpp`, `min`, `id_gudang`, `location`) VALUES (1, 0, 27, 0, 1, \'KIRI A2\')"),
(27,4,"yii\\db\\Command::execute","1602733404.8761","User GSS","INSERT INTO `akt_item_harga_jual` (`id_item`, `harga_satuan`, `id_mata_uang`, `id_level_harga`) VALUES (1, 40, 1, 1)"),
(28,4,"yii\\db\\Command::execute","1602733438.0156","User GSS","INSERT INTO `akt_pembelian_detail` (`id_pembelian`, `id_item_stok`, `qty`, `harga`, `diskon`, `total`, `keterangan`) VALUES (1, 1, 300000, 27, 0, 8181000, \'\')"),
(29,4,"yii\\db\\Command::execute","1602733480.3819","User GSS","UPDATE `akt_pembelian_detail` SET `id_pembelian`=1, `id_item_stok`=1, `qty`=300000, `diskon`=0, `total`=8100000 WHERE `id_pembelian_detail`=1"),
(30,4,"yii\\db\\Command::execute","1602733650.686","User GSS","UPDATE `akt_pembelian` SET `id_customer`=1, `id_mata_uang`=1, `ongkir`=35000, `diskon`=0, `pajak`=1, `total`=8945000, `jenis_bayar`=2, `jatuh_tempo`=30, `tanggal_tempo`=NULL, `materai`=0, `uang_muka`=0, `id_kas_bank`=NULL, `tanggal_estimasi`=\'2020-10-29\' WHERE `id_pembelian`=1"),
(31,0,"Login","1602734180.4115","User GSS","Login"),
(32,4,"yii\\db\\Command::execute","1602734180.4116","User GSS","INSERT INTO `log` (`level`, `category`, `log_time`, `prefix`, `message`) VALUES (0, \'Login\', 1602734180.4115, \'User GSS\', \'Login\')"),
(33,4,"yii\\db\\Command::execute","1602734781.8844","User GSS","UPDATE `akt_approver` SET `id_login`=17, `tingkat_approver`=1 WHERE `id_approver`=51"),
(34,4,"yii\\db\\Command::execute","1602734799.505","User GSS","INSERT INTO `akt_jurnal_umum` (`no_jurnal_umum`, `tipe`, `tanggal`, `keterangan`) VALUES (\'JU2010003\', 1, \'2020-10-15\', \'Order Pembelian : PO2010001\')"),
(35,4,"yii\\db\\Command::execute","1602734799.5249","User GSS","UPDATE `akt_akun` SET `saldo_akun`=8100000 WHERE `id_akun`=117"),
(36,4,"yii\\db\\Command::execute","1602734799.534","User GSS","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (3, 117, 8100000, \'Order Pembelian : PO2010001\')"),
(37,4,"yii\\db\\Command::execute","1602734799.5359","User GSS","UPDATE `akt_akun` SET `saldo_akun`=8945000 WHERE `id_akun`=64"),
(38,4,"yii\\db\\Command::execute","1602734799.5368","User GSS","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `kredit`, `keterangan`) VALUES (3, 64, 8945000, \'Order Pembelian : PO2010001\')"),
(39,4,"yii\\db\\Command::execute","1602734799.5383","User GSS","UPDATE `akt_akun` SET `saldo_akun`=810000 WHERE `id_akun`=53"),
(40,4,"yii\\db\\Command::execute","1602734799.54","User GSS","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (3, 53, 810000, \'Order Pembelian : PO2010001\')"),
(41,4,"yii\\db\\Command::execute","1602734799.5416","User GSS","UPDATE `akt_akun` SET `saldo_akun`=35000 WHERE `id_akun`=122"),
(42,4,"yii\\db\\Command::execute","1602734799.5429","User GSS","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (3, 122, 35000, \'Order Pembelian : PO2010001\')"),
(43,4,"yii\\db\\Command::execute","1602734799.545","User GSS","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (3, 115, 0, \'Order Pembelian : PO2010001\')"),
(44,4,"yii\\db\\Command::execute","1602734799.548","User GSS","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (3, 38, 0, \'Order Pembelian : PO2010001\')"),
(45,4,"yii\\db\\Command::execute","1602734799.5499","User GSS","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `keterangan`) VALUES (3, 1, \'Order Pembelian : PO2010001\')"),
(46,4,"yii\\db\\Command::execute","1602734799.555","User GSS","INSERT INTO `akt_history_transaksi` (`nama_tabel`, `id_tabel`, `id_jurnal_umum`) VALUES (\'akt_kas_bank\', NULL, 11)"),
(47,4,"yii\\db\\Command::execute","1602734799.5562","User GSS","UPDATE `akt_pembelian` SET `tanggal_pembelian`=\'2020-10-15\', `tanggal_tempo`=\'2020-11-14\', `status`=2, `tanggal_approve`=\'2020-10-15 11:06:39\', `id_login`=17 WHERE `id_pembelian`=1"),
(48,4,"yii\\db\\Command::execute","1602734799.558","User GSS","INSERT INTO `akt_history_transaksi` (`nama_tabel`, `id_tabel`, `id_jurnal_umum`) VALUES (\'akt_pembelian\', 1, 3)"),
(49,4,"yii\\db\\Command::execute","1602734816.2922","User GSS","UPDATE `akt_pembelian` SET `status`=5 WHERE `id_pembelian`=1"),
(50,4,"yii\\db\\Command::execute","1602734837.3436","User GSS","INSERT INTO `akt_pembelian_penerimaan` (`no_penerimaan`, `tanggal_penerimaan`, `penerima`, `foto_resi`, `pengantar`, `keterangan_pengantar`, `id_pembelian`) VALUES (\'PQ2010001\', \'2020-10-29\', \'IBNU\', \' \', \'HERNI\', \'\', 1)"),
(51,4,"yii\\db\\Command::execute","1602734848.7811","User GSS","UPDATE `akt_pembelian_penerimaan` SET `tanggal_penerimaan`=\'2020-10-15\', `id_pembelian`=1 WHERE `id_pembelian_penerimaan`=1"),
(52,0,"Login","1602735643.9392","User GSS","Login"),
(53,4,"yii\\db\\Command::execute","1602735643.9394","User GSS","INSERT INTO `log` (`level`, `category`, `log_time`, `prefix`, `message`) VALUES (0, \'Login\', 1602735643.9392, \'User GSS\', \'Login\')"),
(54,4,"yii\\db\\Command::execute","1602736999.0708","User GSS","UPDATE `akt_pembelian_penerimaan` SET `id_pembelian`=1 WHERE `id_pembelian_penerimaan`=1"),
(55,4,"yii\\db\\Command::execute","1602737173.6751","User GSS","INSERT INTO `akt_mitra_bisnis` (`kode_mitra_bisnis`, `nama_mitra_bisnis`, `deskripsi_mitra_bisnis`, `tipe_mitra_bisnis`, `status_mitra_bisnis`) VALUES (\'MB002\', \'CV. KOMPUTER JAYA\', \'\', 2, 1)"),
(56,4,"yii\\db\\Command::execute","1602737183.7996","User GSS","INSERT INTO `akt_pembelian_harta_tetap` (`tanggal`, `id_mata_uang`, `no_pembelian_harta_tetap`, `id_supplier`, `keterangan`, `status`) VALUES (\'2020-10-15\', 1, \'BT2010001\', 2, \'\', 1)"),
(57,0,"Login","1602738228.5143","User GSS","Login"),
(58,4,"yii\\db\\Command::execute","1602738228.5144","User GSS","INSERT INTO `log` (`level`, `category`, `log_time`, `prefix`, `message`) VALUES (0, \'Login\', 1602738228.5143, \'User GSS\', \'Login\')"),
(59,0,"Login","1602739097.9402","User GSS","Login"),
(60,4,"yii\\db\\Command::execute","1602739097.9403","User GSS","INSERT INTO `log` (`level`, `category`, `log_time`, `prefix`, `message`) VALUES (0, \'Login\', 1602739097.9402, \'User GSS\', \'Login\')"),
(61,0,"Login","1602739098.166","User GSS","Login"),
(62,4,"yii\\db\\Command::execute","1602739098.1662","User GSS","INSERT INTO `log` (`level`, `category`, `log_time`, `prefix`, `message`) VALUES (0, \'Login\', 1602739098.166, \'User GSS\', \'Login\')"),
(63,0,"Login","1602740967.7706","User GSS","Login"),
(64,4,"yii\\db\\Command::execute","1602740967.7707","User GSS","INSERT INTO `log` (`level`, `category`, `log_time`, `prefix`, `message`) VALUES (0, \'Login\', 1602740967.7706, \'User GSS\', \'Login\')"),
(65,0,"Login","1602741999.175","User GSS","Login"),
(66,4,"yii\\db\\Command::execute","1602741999.1752","User GSS","INSERT INTO `log` (`level`, `category`, `log_time`, `prefix`, `message`) VALUES (0, \'Login\', 1602741999.175, \'User GSS\', \'Login\')"),
(67,4,"yii\\db\\Command::execute","1602742820.0157","User GSS","UPDATE `akt_pembelian_harta_tetap` SET `id_kas_bank`=NULL, `jatuh_tempo`=NULL, `tanggal_tempo`=NULL, `id_supplier`=2, `id_mata_uang`=1, `pajak`=1, `diskon`=0, `materai`=0, `ongkir`=120000, `jenis_bayar`=1, `uang_muka`=0 WHERE `id_pembelian_harta_tetap`=1"),
(68,4,"yii\\db\\Command::execute","1602742894.3211","User GSS","INSERT INTO `akt_pembelian_harta_tetap_detail` (`id_pembelian_harta_tetap`, `nama_barang`, `harga`, `residu`, `diskon`, `keterangan`, `total`, `kode_pembelian`, `qty`) VALUES (1, \'KOMPUTER\', 3000000, 0, 0, \'KOMPUTER HP\', 3000000, \'HT2010001\', 1)"),
(69,4,"yii\\db\\Command::execute","1602743246.4622","User GSS","UPDATE `akt_approver` SET `id_login`=4, `tingkat_approver`=1 WHERE `id_approver`=58"),
(70,4,"yii\\db\\Command::execute","1602743290.0673","User GSS","INSERT INTO `foto` (`nama_tabel`, `id_tabel`, `foto`) VALUES (\'pembelian\', 1, \'1602743290_Capture.png\')"),
(71,4,"yii\\db\\Command::execute","1602743425.93","User GSS","INSERT INTO `akt_pembelian_penerimaan` (`no_penerimaan`, `tanggal_penerimaan`, `penerima`, `foto_resi`, `pengantar`, `keterangan_pengantar`, `id_pembelian`) VALUES (\'PQ2010002\', \'2020-10-15\', \'IBNU\', \'1602743425_Capture.png\', \'HERNI\', \'\', 1)"),
(72,4,"yii\\db\\Command::execute","1602743543.9131","User GSS","INSERT INTO `akt_pembelian_penerimaan` (`no_penerimaan`, `tanggal_penerimaan`, `penerima`, `foto_resi`, `pengantar`, `keterangan_pengantar`, `id_pembelian`) VALUES (\'PQ2010003\', \'2020-10-15\', \'IBNU\', \'1602743543_kop_surat_sriyatno.png\', \'HERNI\', \'\', 1)"),
(73,4,"yii\\db\\Command::execute","1602743619.0439","User GSS","UPDATE `akt_approver` SET `id_login`=11, `tingkat_approver`=1 WHERE `id_approver`=58"),
(74,4,"yii\\db\\Command::execute","1602745591.1924","User GSS","DELETE FROM `akt_pembelian_penerimaan_detail` WHERE `akt_pembelian_penerimaan_detail`.`id_pembelian_penerimaan` = 2"),
(75,4,"yii\\db\\Command::execute","1602745591.1928","User GSS","DELETE FROM `akt_pembelian_penerimaan` WHERE `id_pembelian_penerimaan`=2"),
(76,4,"yii\\db\\Command::execute","1602745596.6164","User GSS","DELETE FROM `akt_pembelian_penerimaan_detail` WHERE `akt_pembelian_penerimaan_detail`.`id_pembelian_penerimaan` = 3"),
(77,4,"yii\\db\\Command::execute","1602745596.6166","User GSS","DELETE FROM `akt_pembelian_penerimaan` WHERE `id_pembelian_penerimaan`=3"),
(78,4,"yii\\db\\Command::execute","1602745628.7346","User GSS","INSERT INTO `akt_pembelian_penerimaan_detail` (`id_pembelian_detail`, `qty_diterima`, `id_pembelian_penerimaan`, `keterangan`) VALUES (1, 300000, 1, \'\')"),
(79,4,"yii\\db\\Command::execute","1602745628.736","User GSS","UPDATE `akt_item_stok` SET `qty`=300000 WHERE `id_item_stok`=1"),
(80,4,"yii\\db\\Command::execute","1602745628.916","User GSS","UPDATE `akt_pembelian` SET `status`=4 WHERE `id_pembelian`=1"),
(81,4,"yii\\db\\Command::execute","1602745869.6465","User GSS","UPDATE `akt_approver` SET `id_login`=NULL, `tingkat_approver`=1 WHERE `id_approver`=69"),
(82,4,"yii\\db\\Command::execute","1602745871.9911","User GSS","UPDATE `akt_approver` SET `id_login`=6, `tingkat_approver`=1 WHERE `id_approver`=69"),
(83,4,"yii\\db\\Command::execute","1602745928.6217","User GSS","INSERT INTO `akt_mitra_bisnis` (`nama_mitra_bisnis`, `deskripsi_mitra_bisnis`, `kode_mitra_bisnis`, `status_mitra_bisnis`) VALUES (\'CV. GARUDA SARANA SEJAHTERA\', \'\', \'MB003\', 1)"),
(84,4,"yii\\db\\Command::execute","1602745998.4442","User GSS","INSERT INTO `akt_sales` (`kode_sales`, `nama_sales`, `telepon`, `email`, `alamat`, `status_aktif`) VALUES (\'SL001\', \'ADITYA\', \'081999999999\', \'\', \'temanggung\', 1)"),
(85,4,"yii\\db\\Command::execute","1602746000.8074","User GSS","INSERT INTO `akt_sales` (`kode_sales`, `nama_sales`, `telepon`, `email`, `alamat`, `status_aktif`) VALUES (\'SL002\', \'ADITYA\', \'081999999999\', \'\', \'temanggung\', 1)"),
(86,4,"yii\\db\\Command::execute","1602746015.6098","User GSS","DELETE FROM `akt_sales` WHERE `id_sales`=2"),
(87,4,"yii\\db\\Command::execute","1602746030.6026","User GSS","INSERT INTO `akt_penjualan` (`tanggal_order_penjualan`, `id_mata_uang`, `no_order_penjualan`, `id_customer`, `id_sales`, `status`) VALUES (\'2020-10-15\', 1, \'OP2010001\', 3, 1, 1)"),
(88,4,"yii\\db\\Command::execute","1602746059.1709","User GSS","INSERT INTO `akt_penjualan_detail` (`id_penjualan`, `id_item_stok`, `qty`, `harga`, `diskon`, `total`, `id_item_harga_jual`, `keterangan`) VALUES (1, 1, 90000, 40, 0, 3600000, 1, \'\')"),
(89,4,"yii\\db\\Command::execute","1602746059.1775","User GSS","UPDATE `akt_penjualan` SET `total`=3600000 WHERE `id_penjualan`=1"),
(90,4,"yii\\db\\Command::execute","1602746073.9076","User GSS","UPDATE `akt_penjualan_detail` SET `id_item_stok`=1, `qty`=90000, `harga`=40, `diskon`=0 WHERE `id_penjualan_detail`=1"),
(91,4,"yii\\db\\Command::execute","1602746092.1805","User GSS","UPDATE `akt_penjualan` SET `id_customer`=3, `id_sales`=1, `id_mata_uang`=1, `ongkir`=40000, `pajak`=1, `uang_muka`=0, `id_kas_bank`=NULL, `total`=4000000, `diskon`=0, `jenis_bayar`=2, `jumlah_tempo`=NULL, `materai`=0, `tanggal_estimasi`=NULL WHERE `id_penjualan`=1"),
(92,0,"Login","1602746150.3527","User GSS","Login"),
(93,4,"yii\\db\\Command::execute","1602746150.3528","User GSS","INSERT INTO `log` (`level`, `category`, `log_time`, `prefix`, `message`) VALUES (0, \'Login\', 1602746150.3527, \'User GSS\', \'Login\')"),
(94,4,"yii\\db\\Command::execute","1602746164.9334","User GSS","INSERT INTO `akt_mitra_bisnis` (`nama_mitra_bisnis`, `deskripsi_mitra_bisnis`, `kode_mitra_bisnis`, `status_mitra_bisnis`) VALUES (\'PT. MANDIRI PRIMA MULTIALKESINDO\', \'\', \'MB004\', 1)"),
(95,4,"yii\\db\\Command::execute","1602746184.311","User GSS","INSERT INTO `akt_sales` (`kode_sales`, `nama_sales`, `telepon`, `email`, `alamat`, `status_aktif`) VALUES (\'SL002\', \'KANTOR\', \'081999993455\', \'\', \'SEMARANG\', 1)"),
(96,4,"yii\\db\\Command::execute","1602746195.2876","User GSS","INSERT INTO `akt_penjualan` (`tanggal_order_penjualan`, `id_mata_uang`, `no_order_penjualan`, `id_customer`, `id_sales`, `status`) VALUES (\'2020-10-15\', 1, \'OP2010002\', 4, 3, 1)"),
(97,4,"yii\\db\\Command::execute","1602746253.0223","User GSS","UPDATE `akt_penjualan` SET `id_customer`=4, `id_sales`=3, `id_mata_uang`=1, `ongkir`=25000, `pajak`=1, `uang_muka`=0, `id_kas_bank`=NULL, `total`=31000, `diskon`=5, `jenis_bayar`=1, `materai`=6000, `tanggal_estimasi`=\'2020-10-19\' WHERE `id_penjualan`=2"),
(98,4,"yii\\db\\Command::execute","1602746278.4389","User GSS","INSERT INTO `akt_penjualan_detail` (`id_penjualan`, `id_item_stok`, `qty`, `harga`, `diskon`, `total`, `id_item_harga_jual`, `keterangan`) VALUES (2, 1, 120000, 40, 0, 4800000, 1, \'\')"),
(99,4,"yii\\db\\Command::execute","1602746278.446","User GSS","UPDATE `akt_penjualan` SET `total`=5047000 WHERE `id_penjualan`=2"),
(100,4,"yii\\db\\Command::execute","1602746336.6511","User GSS","INSERT INTO `akt_mitra_bisnis` (`nama_mitra_bisnis`, `deskripsi_mitra_bisnis`, `kode_mitra_bisnis`, `status_mitra_bisnis`) VALUES (\'UD. MITRA JAYA\', \'TRENGGALEK\', \'MB005\', 1)"),
(101,4,"yii\\db\\Command::execute","1602746375.0256","User GSS","INSERT INTO `akt_sales` (`kode_sales`, `nama_sales`, `telepon`, `email`, `alamat`, `status_aktif`) VALUES (\'SL003\', \'REDI\', \'081578907800\', \'\', \'YOGYAKARTA\', 1)"),
(102,4,"yii\\db\\Command::execute","1602746382.5836","User GSS","INSERT INTO `akt_penjualan` (`tanggal_order_penjualan`, `id_mata_uang`, `no_order_penjualan`, `id_customer`, `id_sales`, `status`) VALUES (\'2020-10-15\', 1, \'OP2010003\', 5, 4, 1)"),
(103,4,"yii\\db\\Command::execute","1602746411.4323","User GSS","INSERT INTO `akt_penjualan_detail` (`id_penjualan`, `id_item_stok`, `qty`, `harga`, `diskon`, `total`, `id_item_harga_jual`, `keterangan`) VALUES (3, 1, 90000, 40, 0, 3600000, 1, \'\')"),
(104,4,"yii\\db\\Command::execute","1602746411.4374","User GSS","UPDATE `akt_penjualan` SET `total`=3600000 WHERE `id_penjualan`=3"),
(105,4,"yii\\db\\Command::execute","1602746431.7704","User GSS","UPDATE `akt_penjualan_detail` SET `id_item_stok`=1, `qty`=90000, `harga`=40, `diskon`=0 WHERE `id_penjualan_detail`=3"),
(106,4,"yii\\db\\Command::execute","1602746457.7221","User GSS","UPDATE `akt_penjualan` SET `id_customer`=5, `id_sales`=4, `id_mata_uang`=1, `ongkir`=0, `pajak`=1, `uang_muka`=0, `id_kas_bank`=NULL, `total`=3966000, `diskon`=0, `jenis_bayar`=2, `jumlah_tempo`=15, `materai`=6000, `tanggal_estimasi`=\'2020-10-21\' WHERE `id_penjualan`=3"),
(107,4,"yii\\db\\Command::execute","1602746473.1568","User GSS","UPDATE `akt_penjualan_detail` SET `id_item_stok`=1, `qty`=90000, `harga`=40, `diskon`=0 WHERE `id_penjualan_detail`=3"),
(108,4,"yii\\db\\Command::execute","1602746546.9018","User GSS","UPDATE `akt_penjualan` SET `id_customer`=5, `id_sales`=4, `id_mata_uang`=1, `ongkir`=0, `pajak`=1, `uang_muka`=200, `id_kas_bank`=2, `total`=3965800, `diskon`=0, `jumlah_tempo`=15, `materai`=6000 WHERE `id_penjualan`=3"),
(109,4,"yii\\db\\Command::execute","1602746563.3216","User GSS","UPDATE `akt_penjualan` SET `id_customer`=5, `id_sales`=4, `id_mata_uang`=1, `ongkir`=0, `pajak`=1, `uang_muka`=200, `id_kas_bank`=2, `total`=3965800, `diskon`=0, `jumlah_tempo`=15, `materai`=6000 WHERE `id_penjualan`=3"),
(110,4,"yii\\db\\Command::execute","1602746575.262","User GSS","UPDATE `akt_penjualan_detail` SET `id_item_stok`=1, `qty`=90000, `harga`=40, `diskon`=0 WHERE `id_penjualan_detail`=3"),
(111,4,"yii\\db\\Command::execute","1602746591.1866","User GSS","UPDATE `akt_penjualan` SET `id_customer`=5, `id_sales`=4, `id_mata_uang`=1, `ongkir`=0, `pajak`=1, `uang_muka`=200, `id_kas_bank`=2, `total`=3965800, `diskon`=0, `jumlah_tempo`=15, `materai`=6000 WHERE `id_penjualan`=3"),
(112,4,"yii\\db\\Command::execute","1602746636.4276","User GSS","UPDATE `akt_penjualan` SET `id_customer`=5, `id_sales`=4, `id_mata_uang`=1, `ongkir`=0, `pajak`=1, `uang_muka`=200, `id_kas_bank`=2, `total`=3965800, `diskon`=0, `jumlah_tempo`=15, `materai`=6000 WHERE `id_penjualan`=3"),
(113,4,"yii\\db\\Command::execute","1602746675.373","User GSS","UPDATE `akt_penjualan` SET `id_customer`=5, `id_sales`=4, `id_mata_uang`=1, `ongkir`=0, `pajak`=1, `uang_muka`=200, `id_kas_bank`=2, `total`=3965800, `diskon`=0, `jumlah_tempo`=15, `materai`=6000 WHERE `id_penjualan`=3"),
(114,4,"yii\\db\\Command::execute","1602746687.6599","User GSS","UPDATE `akt_penjualan` SET `id_customer`=5, `id_sales`=4, `id_mata_uang`=1, `ongkir`=0, `pajak`=1, `uang_muka`=200, `id_kas_bank`=2, `total`=3965800, `diskon`=0, `jumlah_tempo`=15, `materai`=6000 WHERE `id_penjualan`=3"),
(115,0,"Login","1602746755.2772","GSS Developer","Login"),
(116,4,"yii\\db\\Command::execute","1602746755.2773","GSS Developer","INSERT INTO `log` (`level`, `category`, `log_time`, `prefix`, `message`) VALUES (0, \'Login\', 1602746755.2772, \'GSS Developer\', \'Login\')"),
(117,4,"yii\\db\\Command::execute","1602747173.6721","GSS Developer","UPDATE `akt_penjualan` SET `id_customer`=4, `id_sales`=3, `id_mata_uang`=1, `ongkir`=25000, `pajak`=1, `uang_muka`=200, `id_kas_bank`=1, `total`=5046800, `diskon`=5, `materai`=6000 WHERE `id_penjualan`=2"),
(118,4,"yii\\db\\Command::execute","1602747415.7813","GSS Developer","UPDATE `akt_penjualan` SET `id_customer`=4, `id_sales`=3, `id_mata_uang`=1, `ongkir`=25000, `pajak`=1, `uang_muka`=2000000, `id_kas_bank`=1, `total`=3047000, `diskon`=5, `materai`=6000 WHERE `id_penjualan`=2"),
(119,4,"yii\\db\\Command::execute","1602748925.1085","User GSS","UPDATE `akt_approver` SET `id_login`=17, `tingkat_approver`=1 WHERE `id_approver`=69"),
(120,4,"yii\\db\\Command::execute","1602748946.7767","User GSS","UPDATE `akt_penjualan` SET `the_approver`=17, `the_approver_date`=\'2020-10-15 15:02:26\', `no_penjualan`=\'PJ2010001\', `tanggal_penjualan`=\'2020-10-15\', `tanggal_tempo`=\'2020-10-30\', `status`=2 WHERE `id_penjualan`=3"),
(121,4,"yii\\db\\Command::execute","1602748946.8002","User GSS","INSERT INTO `akt_jurnal_umum` (`no_jurnal_umum`, `tipe`, `tanggal`, `keterangan`) VALUES (\'JU2010004\', 1, \'2020-10-15\', \'Order Penjualan : OP2010003\')"),
(122,4,"yii\\db\\Command::execute","1602748946.8236","User GSS","UPDATE `akt_akun` SET `saldo_akun`=4500000 WHERE `id_akun`=117"),
(123,4,"yii\\db\\Command::execute","1602748946.8249","User GSS","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `kredit`, `keterangan`) VALUES (4, 117, 3600000, \'Order Penjualan : OP2010003\')"),
(124,4,"yii\\db\\Command::execute","1602748946.8261","User GSS","UPDATE `akt_akun` SET `saldo_akun`=3972000 WHERE `id_akun`=2"),
(125,4,"yii\\db\\Command::execute","1602748946.8269","User GSS","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (4, 2, 3972000, \'Order Penjualan : OP2010003\')"),
(126,4,"yii\\db\\Command::execute","1602748946.8283","User GSS","UPDATE `akt_akun` SET `saldo_akun`=360000 WHERE `id_akun`=73"),
(127,4,"yii\\db\\Command::execute","1602748946.8291","User GSS","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `kredit`, `keterangan`) VALUES (4, 73, 360000, \'Order Penjualan : OP2010003\')"),
(128,4,"yii\\db\\Command::execute","1602748946.8315","User GSS","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `kredit`, `keterangan`) VALUES (4, 47, 0, \'Order Penjualan : OP2010003\')"),
(129,4,"yii\\db\\Command::execute","1602748946.8326","User GSS","UPDATE `akt_akun` SET `saldo_akun`=6000 WHERE `id_akun`=115"),
(130,4,"yii\\db\\Command::execute","1602748946.8334","User GSS","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (4, 115, 6000, \'Order Penjualan : OP2010003\')"),
(131,4,"yii\\db\\Command::execute","1602748946.8342","User GSS","UPDATE `akt_akun` SET `saldo_akun`=200 WHERE `id_akun`=131"),
(132,4,"yii\\db\\Command::execute","1602748946.8349","User GSS","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `kredit`, `keterangan`) VALUES (4, 131, 200, \'Order Penjualan : OP2010003\')"),
(133,4,"yii\\db\\Command::execute","1602748946.8376","User GSS","UPDATE `akt_kas_bank` SET `saldo`=50000200 WHERE `id_kas_bank`=2"),
(134,4,"yii\\db\\Command::execute","1602748946.8387","User GSS","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (4, 1, 200, \'Order Penjualan : OP2010003\')"),
(135,4,"yii\\db\\Command::execute","1602748946.8424","User GSS","INSERT INTO `akt_history_transaksi` (`nama_tabel`, `id_tabel`, `id_jurnal_umum`) VALUES (\'akt_kas_bank\', 2, 18)"),
(136,4,"yii\\db\\Command::execute","1602748946.8435","User GSS","INSERT INTO `akt_history_transaksi` (`nama_tabel`, `id_tabel`, `id_jurnal_umum`) VALUES (\'akt_penjualan\', 3, 4)"),
(137,4,"yii\\db\\Command::execute","1602748953.244","User GSS","UPDATE `akt_penjualan` SET `the_approver`=NULL, `the_approver_date`=NULL, `no_penjualan`=NULL, `tanggal_penjualan`=NULL, `tanggal_tempo`=NULL, `status`=1 WHERE `id_penjualan`=3"),
(138,4,"yii\\db\\Command::execute","1602748953.2541","User GSS","UPDATE `akt_akun` SET `saldo_akun`=8100000 WHERE `id_akun`=117"),
(139,4,"yii\\db\\Command::execute","1602748953.2551","User GSS","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=12"),
(140,4,"yii\\db\\Command::execute","1602748953.2562","User GSS","UPDATE `akt_akun` SET `saldo_akun`=0 WHERE `id_akun`=2"),
(141,4,"yii\\db\\Command::execute","1602748953.2569","User GSS","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=13"),
(142,4,"yii\\db\\Command::execute","1602748953.2582","User GSS","UPDATE `akt_akun` SET `saldo_akun`=0 WHERE `id_akun`=73"),
(143,4,"yii\\db\\Command::execute","1602748953.259","User GSS","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=14"),
(144,4,"yii\\db\\Command::execute","1602748953.2603","User GSS","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=15"),
(145,4,"yii\\db\\Command::execute","1602748953.2615","User GSS","UPDATE `akt_akun` SET `saldo_akun`=0 WHERE `id_akun`=115"),
(146,4,"yii\\db\\Command::execute","1602748953.2623","User GSS","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=16"),
(147,4,"yii\\db\\Command::execute","1602748953.2632","User GSS","UPDATE `akt_akun` SET `saldo_akun`=0 WHERE `id_akun`=131"),
(148,4,"yii\\db\\Command::execute","1602748953.2639","User GSS","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=17"),
(149,4,"yii\\db\\Command::execute","1602748953.2671","User GSS","UPDATE `akt_kas_bank` SET `saldo`=50000000 WHERE `id_kas_bank`=2"),
(150,4,"yii\\db\\Command::execute","1602748953.268","User GSS","DELETE FROM `akt_history_transaksi` WHERE `id_history_transaksi`=7"),
(151,4,"yii\\db\\Command::execute","1602748953.2689","User GSS","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=18"),
(152,4,"yii\\db\\Command::execute","1602748953.2697","User GSS","DELETE FROM `akt_jurnal_umum` WHERE `id_jurnal_umum`=4"),
(153,4,"yii\\db\\Command::execute","1602748953.2706","User GSS","DELETE FROM `akt_history_transaksi` WHERE `id_history_transaksi`=8"),
(154,4,"yii\\db\\Command::execute","1602749031.4958","User GSS","UPDATE `akt_approver` SET `id_login`=NULL, `tingkat_approver`=1 WHERE `id_approver`=69"),
(155,4,"yii\\db\\Command::execute","1602751850.3463","User GSS","UPDATE `akt_approver` SET `id_login`=17, `tingkat_approver`=1 WHERE `id_approver`=69"),
(156,0,"Login","1602765986.7536","GSS Developer","Login"),
(157,4,"yii\\db\\Command::execute","1602765986.7537","GSS Developer","INSERT INTO `log` (`level`, `category`, `log_time`, `prefix`, `message`) VALUES (0, \'Login\', 1602765986.7536, \'GSS Developer\', \'Login\')"),
(158,4,"yii\\db\\Command::execute","1602766062.6183","GSS Developer","UPDATE `akt_approver` SET `id_login`=11, `tingkat_approver`=1 WHERE `id_approver`=70"),
(159,4,"yii\\db\\Command::execute","1602767138.7916","GSS Developer","UPDATE `akt_penjualan` SET `the_approver`=11, `the_approver_date`=\'2020-10-15 20:05:38\', `no_penjualan`=\'PJ2010001\', `tanggal_penjualan`=\'2020-10-15\', `tanggal_tempo`=\'1970-01-01\', `status`=2 WHERE `id_penjualan`=1"),
(160,4,"yii\\db\\Command::execute","1602767138.7976","GSS Developer","INSERT INTO `akt_jurnal_umum` (`no_jurnal_umum`, `tipe`, `tanggal`, `keterangan`) VALUES (\'JU2010004\', 1, \'2020-10-15\', \'Order Penjualan : OP2010001\')"),
(161,4,"yii\\db\\Command::execute","1602767138.8125","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=4500000 WHERE `id_akun`=117"),
(162,4,"yii\\db\\Command::execute","1602767138.8135","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `kredit`, `keterangan`) VALUES (5, 117, 3600000, \'Order Penjualan : OP2010001\')"),
(163,4,"yii\\db\\Command::execute","1602767138.8144","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=4000000 WHERE `id_akun`=2"),
(164,4,"yii\\db\\Command::execute","1602767138.8151","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (5, 2, 4000000, \'Order Penjualan : OP2010001\')"),
(165,4,"yii\\db\\Command::execute","1602767138.8163","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=360000 WHERE `id_akun`=73"),
(166,4,"yii\\db\\Command::execute","1602767138.817","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `kredit`, `keterangan`) VALUES (5, 73, 360000, \'Order Penjualan : OP2010001\')"),
(167,4,"yii\\db\\Command::execute","1602767138.8182","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=40000 WHERE `id_akun`=47"),
(168,4,"yii\\db\\Command::execute","1602767138.8213","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `kredit`, `keterangan`) VALUES (5, 47, 40000, \'Order Penjualan : OP2010001\')"),
(169,4,"yii\\db\\Command::execute","1602767138.8227","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (5, 115, 0, \'Order Penjualan : OP2010001\')"),
(170,4,"yii\\db\\Command::execute","1602767138.824","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `kredit`, `keterangan`) VALUES (5, 131, 0, \'Order Penjualan : OP2010001\')"),
(171,4,"yii\\db\\Command::execute","1602767138.8251","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `keterangan`) VALUES (5, 1, \'Order Penjualan : OP2010001\')"),
(172,4,"yii\\db\\Command::execute","1602767138.8287","GSS Developer","INSERT INTO `akt_history_transaksi` (`nama_tabel`, `id_tabel`, `id_jurnal_umum`) VALUES (\'akt_kas_bank\', NULL, 25)"),
(173,4,"yii\\db\\Command::execute","1602767138.8296","GSS Developer","INSERT INTO `akt_history_transaksi` (`nama_tabel`, `id_tabel`, `id_jurnal_umum`) VALUES (\'akt_penjualan\', 1, 5)"),
(174,4,"yii\\db\\Command::execute","1602767173.6528","GSS Developer","UPDATE `akt_penjualan` SET `the_approver`=NULL, `the_approver_date`=NULL, `no_penjualan`=NULL, `tanggal_penjualan`=NULL, `tanggal_tempo`=NULL, `status`=1 WHERE `id_penjualan`=1"),
(175,4,"yii\\db\\Command::execute","1602767173.6605","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=8100000 WHERE `id_akun`=117"),
(176,4,"yii\\db\\Command::execute","1602767173.6617","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=19"),
(177,4,"yii\\db\\Command::execute","1602767173.6632","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=0 WHERE `id_akun`=2"),
(178,4,"yii\\db\\Command::execute","1602767173.6641","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=20"),
(179,4,"yii\\db\\Command::execute","1602767173.6652","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=0 WHERE `id_akun`=73"),
(180,4,"yii\\db\\Command::execute","1602767173.6665","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=21"),
(181,4,"yii\\db\\Command::execute","1602767173.6696","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=0 WHERE `id_akun`=47"),
(182,4,"yii\\db\\Command::execute","1602767173.6706","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=22"),
(183,4,"yii\\db\\Command::execute","1602767173.6723","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=23"),
(184,4,"yii\\db\\Command::execute","1602767173.6735","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=24"),
(185,4,"yii\\db\\Command::execute","1602767173.6748","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=25"),
(186,4,"yii\\db\\Command::execute","1602767173.6755","GSS Developer","DELETE FROM `akt_jurnal_umum` WHERE `id_jurnal_umum`=5"),
(187,4,"yii\\db\\Command::execute","1602767173.6766","GSS Developer","DELETE FROM `akt_history_transaksi` WHERE `id_history_transaksi`=10"),
(188,4,"yii\\db\\Command::execute","1602767187.7658","GSS Developer","UPDATE `akt_penjualan` SET `the_approver`=11, `the_approver_date`=\'2020-10-15 20:06:27\', `status`=5 WHERE `id_penjualan`=1"),
(189,4,"yii\\db\\Command::execute","1602767343.4763","GSS Developer","UPDATE `akt_penjualan` SET `the_approver`=NULL, `the_approver_date`=NULL, `status`=1 WHERE `id_penjualan`=1"),
(190,4,"yii\\db\\Command::execute","1602767499.3374","GSS Developer","UPDATE `akt_approver` SET `id_login`=NULL, `tingkat_approver`=1 WHERE `id_approver`=70"),
(191,4,"yii\\db\\Command::execute","1602767626.3721","GSS Developer","INSERT INTO `akt_penjualan` (`tanggal_order_penjualan`, `id_mata_uang`, `no_order_penjualan`, `id_customer`, `id_sales`, `status`) VALUES (\'2020-10-15\', 1, \'OP2010004\', 3, 1, 1)"),
(192,4,"yii\\db\\Command::execute","1602767670.4991","GSS Developer","UPDATE `akt_approver` SET `id_login`=11, `tingkat_approver`=1 WHERE `id_approver`=70"),
(193,4,"yii\\db\\Command::execute","1602767853.6319","GSS Developer","UPDATE `akt_approver` SET `id_login`=NULL, `tingkat_approver`=1 WHERE `id_approver`=70"),
(194,4,"yii\\db\\Command::execute","1602767868.5424","GSS Developer","INSERT INTO `akt_penjualan_detail` (`id_penjualan`, `id_item_stok`, `qty`, `harga`, `diskon`, `total`, `id_item_harga_jual`, `keterangan`) VALUES (4, 1, 1, 40, 0, 40, 1, \'\')"),
(195,4,"yii\\db\\Command::execute","1602767868.546","GSS Developer","UPDATE `akt_penjualan` SET `total`=40 WHERE `id_penjualan`=4"),
(196,4,"yii\\db\\Command::execute","1602767874.894","GSS Developer","UPDATE `akt_approver` SET `id_login`=11, `tingkat_approver`=1 WHERE `id_approver`=70"),
(197,4,"yii\\db\\Command::execute","1602813612.8568","User GSS","UPDATE `akt_penjualan` SET `the_approver`=17, `the_approver_date`=\'2020-10-16 09:00:12\', `no_penjualan`=\'PJ2010001\', `tanggal_penjualan`=\'2020-10-16\', `tanggal_tempo`=\'1970-01-01\', `status`=2 WHERE `id_penjualan`=1"),
(198,4,"yii\\db\\Command::execute","1602813612.8675","User GSS","INSERT INTO `akt_jurnal_umum` (`no_jurnal_umum`, `tipe`, `tanggal`, `keterangan`) VALUES (\'JU2010004\', 1, \'2020-10-16\', \'Order Penjualan : OP2010001\')"),
(199,4,"yii\\db\\Command::execute","1602813612.901","User GSS","UPDATE `akt_akun` SET `saldo_akun`=4500000 WHERE `id_akun`=117"),
(200,4,"yii\\db\\Command::execute","1602813612.9025","User GSS","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `kredit`, `keterangan`) VALUES (6, 117, 3600000, \'Order Penjualan : OP2010001\')"),
(201,4,"yii\\db\\Command::execute","1602813612.9042","User GSS","UPDATE `akt_akun` SET `saldo_akun`=4000000 WHERE `id_akun`=2"),
(202,4,"yii\\db\\Command::execute","1602813612.9051","User GSS","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (6, 2, 4000000, \'Order Penjualan : OP2010001\')"),
(203,4,"yii\\db\\Command::execute","1602813612.9065","User GSS","UPDATE `akt_akun` SET `saldo_akun`=360000 WHERE `id_akun`=73"),
(204,4,"yii\\db\\Command::execute","1602813612.9073","User GSS","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `kredit`, `keterangan`) VALUES (6, 73, 360000, \'Order Penjualan : OP2010001\')"),
(205,4,"yii\\db\\Command::execute","1602813612.9102","User GSS","UPDATE `akt_akun` SET `saldo_akun`=40000 WHERE `id_akun`=47"),
(206,4,"yii\\db\\Command::execute","1602813612.911","User GSS","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `kredit`, `keterangan`) VALUES (6, 47, 40000, \'Order Penjualan : OP2010001\')"),
(207,4,"yii\\db\\Command::execute","1602813612.9124","User GSS","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (6, 115, 0, \'Order Penjualan : OP2010001\')"),
(208,4,"yii\\db\\Command::execute","1602813612.9138","User GSS","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `kredit`, `keterangan`) VALUES (6, 131, 0, \'Order Penjualan : OP2010001\')"),
(209,4,"yii\\db\\Command::execute","1602813612.9152","User GSS","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `keterangan`) VALUES (6, 1, \'Order Penjualan : OP2010001\')"),
(210,4,"yii\\db\\Command::execute","1602813612.9206","User GSS","INSERT INTO `akt_history_transaksi` (`nama_tabel`, `id_tabel`, `id_jurnal_umum`) VALUES (\'akt_kas_bank\', NULL, 32)"),
(211,4,"yii\\db\\Command::execute","1602813612.9221","User GSS","INSERT INTO `akt_history_transaksi` (`nama_tabel`, `id_tabel`, `id_jurnal_umum`) VALUES (\'akt_penjualan\', 1, 6)"),
(212,4,"yii\\db\\Command::execute","1602813616.5964","User GSS","UPDATE `akt_penjualan` SET `the_approver`=NULL, `the_approver_date`=NULL, `no_penjualan`=NULL, `tanggal_penjualan`=NULL, `tanggal_tempo`=NULL, `status`=1 WHERE `id_penjualan`=1"),
(213,4,"yii\\db\\Command::execute","1602813616.6106","User GSS","UPDATE `akt_akun` SET `saldo_akun`=8100000 WHERE `id_akun`=117"),
(214,4,"yii\\db\\Command::execute","1602813616.6121","User GSS","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=26"),
(215,4,"yii\\db\\Command::execute","1602813616.614","User GSS","UPDATE `akt_akun` SET `saldo_akun`=0 WHERE `id_akun`=2"),
(216,4,"yii\\db\\Command::execute","1602813616.6148","User GSS","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=27"),
(217,4,"yii\\db\\Command::execute","1602813616.6164","User GSS","UPDATE `akt_akun` SET `saldo_akun`=0 WHERE `id_akun`=73"),
(218,4,"yii\\db\\Command::execute","1602813616.6176","User GSS","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=28"),
(219,4,"yii\\db\\Command::execute","1602813616.6195","User GSS","UPDATE `akt_akun` SET `saldo_akun`=0 WHERE `id_akun`=47"),
(220,4,"yii\\db\\Command::execute","1602813616.6205","User GSS","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=29"),
(221,4,"yii\\db\\Command::execute","1602813616.6219","User GSS","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=30"),
(222,4,"yii\\db\\Command::execute","1602813616.6236","User GSS","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=31"),
(223,4,"yii\\db\\Command::execute","1602813616.6251","User GSS","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=32"),
(224,4,"yii\\db\\Command::execute","1602813616.6261","User GSS","DELETE FROM `akt_jurnal_umum` WHERE `id_jurnal_umum`=6"),
(225,4,"yii\\db\\Command::execute","1602813616.6271","User GSS","DELETE FROM `akt_history_transaksi` WHERE `id_history_transaksi`=12"),
(226,4,"yii\\db\\Command::execute","1602813624.4575","User GSS","UPDATE `akt_penjualan` SET `the_approver`=17, `the_approver_date`=\'2020-10-16 09:00:24\', `no_penjualan`=\'PJ2010001\', `tanggal_penjualan`=\'2020-10-16\', `status`=2 WHERE `id_penjualan`=2"),
(227,4,"yii\\db\\Command::execute","1602813624.4621","User GSS","INSERT INTO `akt_jurnal_umum` (`no_jurnal_umum`, `tipe`, `tanggal`, `keterangan`) VALUES (\'JU2010004\', 1, \'2020-10-16\', \'Order Penjualan : OP2010002\')"),
(228,4,"yii\\db\\Command::execute","1602813624.4743","User GSS","UPDATE `akt_akun` SET `saldo_akun`=3540000 WHERE `id_akun`=117"),
(229,4,"yii\\db\\Command::execute","1602813624.4769","User GSS","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `kredit`, `keterangan`) VALUES (7, 117, 4560000, \'Order Penjualan : OP2010002\')"),
(230,4,"yii\\db\\Command::execute","1602813624.4791","User GSS","UPDATE `akt_akun` SET `saldo_akun`=5053000 WHERE `id_akun`=2"),
(231,4,"yii\\db\\Command::execute","1602813624.4804","User GSS","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (7, 2, 5053000, \'Order Penjualan : OP2010002\')"),
(232,4,"yii\\db\\Command::execute","1602813624.4828","User GSS","UPDATE `akt_akun` SET `saldo_akun`=456000 WHERE `id_akun`=73"),
(233,4,"yii\\db\\Command::execute","1602813624.484","User GSS","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `kredit`, `keterangan`) VALUES (7, 73, 456000, \'Order Penjualan : OP2010002\')"),
(234,4,"yii\\db\\Command::execute","1602813624.4856","User GSS","UPDATE `akt_akun` SET `saldo_akun`=25000 WHERE `id_akun`=47"),
(235,4,"yii\\db\\Command::execute","1602813624.4866","User GSS","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `kredit`, `keterangan`) VALUES (7, 47, 25000, \'Order Penjualan : OP2010002\')"),
(236,4,"yii\\db\\Command::execute","1602813624.4885","User GSS","UPDATE `akt_akun` SET `saldo_akun`=6000 WHERE `id_akun`=115"),
(237,4,"yii\\db\\Command::execute","1602813624.4893","User GSS","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (7, 115, 6000, \'Order Penjualan : OP2010002\')"),
(238,4,"yii\\db\\Command::execute","1602813624.4908","User GSS","UPDATE `akt_akun` SET `saldo_akun`=2000000 WHERE `id_akun`=131"),
(239,4,"yii\\db\\Command::execute","1602813624.4918","User GSS","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `kredit`, `keterangan`) VALUES (7, 131, 2000000, \'Order Penjualan : OP2010002\')"),
(240,4,"yii\\db\\Command::execute","1602813624.4962","User GSS","UPDATE `akt_kas_bank` SET `saldo`=52000000 WHERE `id_kas_bank`=1"),
(241,4,"yii\\db\\Command::execute","1602813624.4976","User GSS","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (7, 1, 2000000, \'Order Penjualan : OP2010002\')"),
(242,4,"yii\\db\\Command::execute","1602813624.5005","User GSS","INSERT INTO `akt_history_transaksi` (`nama_tabel`, `id_tabel`, `id_jurnal_umum`) VALUES (\'akt_kas_bank\', 1, 39)"),
(243,4,"yii\\db\\Command::execute","1602813624.5022","User GSS","INSERT INTO `akt_history_transaksi` (`nama_tabel`, `id_tabel`, `id_jurnal_umum`) VALUES (\'akt_penjualan\', 2, 7)"),
(244,4,"yii\\db\\Command::execute","1602813627.1638","User GSS","UPDATE `akt_penjualan` SET `the_approver`=NULL, `the_approver_date`=NULL, `no_penjualan`=NULL, `tanggal_penjualan`=NULL, `status`=1 WHERE `id_penjualan`=2"),
(245,4,"yii\\db\\Command::execute","1602813627.1766","User GSS","UPDATE `akt_akun` SET `saldo_akun`=8100000 WHERE `id_akun`=117"),
(246,4,"yii\\db\\Command::execute","1602813627.1778","User GSS","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=33"),
(247,4,"yii\\db\\Command::execute","1602813627.1793","User GSS","UPDATE `akt_akun` SET `saldo_akun`=0 WHERE `id_akun`=2"),
(248,4,"yii\\db\\Command::execute","1602813627.18","User GSS","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=34"),
(249,4,"yii\\db\\Command::execute","1602813627.1814","User GSS","UPDATE `akt_akun` SET `saldo_akun`=0 WHERE `id_akun`=73"),
(250,4,"yii\\db\\Command::execute","1602813627.1821","User GSS","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=35"),
(251,4,"yii\\db\\Command::execute","1602813627.1833","User GSS","UPDATE `akt_akun` SET `saldo_akun`=0 WHERE `id_akun`=47"),
(252,4,"yii\\db\\Command::execute","1602813627.1841","User GSS","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=36"),
(253,4,"yii\\db\\Command::execute","1602813627.1856","User GSS","UPDATE `akt_akun` SET `saldo_akun`=0 WHERE `id_akun`=115"),
(254,4,"yii\\db\\Command::execute","1602813627.1866","User GSS","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=37"),
(255,4,"yii\\db\\Command::execute","1602813627.1882","User GSS","UPDATE `akt_akun` SET `saldo_akun`=0 WHERE `id_akun`=131"),
(256,4,"yii\\db\\Command::execute","1602813627.1891","User GSS","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=38"),
(257,4,"yii\\db\\Command::execute","1602813627.1933","User GSS","UPDATE `akt_kas_bank` SET `saldo`=50000000 WHERE `id_kas_bank`=1"),
(258,4,"yii\\db\\Command::execute","1602813627.1946","User GSS","DELETE FROM `akt_history_transaksi` WHERE `id_history_transaksi`=13"),
(259,4,"yii\\db\\Command::execute","1602813627.196","User GSS","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=39"),
(260,4,"yii\\db\\Command::execute","1602813627.1973","User GSS","DELETE FROM `akt_jurnal_umum` WHERE `id_jurnal_umum`=7"),
(261,4,"yii\\db\\Command::execute","1602813627.1985","User GSS","DELETE FROM `akt_history_transaksi` WHERE `id_history_transaksi`=14"),
(262,0,"Login","1602814056.0613","User GSS","Login"),
(263,4,"yii\\db\\Command::execute","1602814056.0615","User GSS","INSERT INTO `log` (`level`, `category`, `log_time`, `prefix`, `message`) VALUES (0, \'Login\', 1602814056.0613, \'User GSS\', \'Login\')"),
(264,0,"Login","1602820295.8347","GSS Developer","Login"),
(265,4,"yii\\db\\Command::execute","1602820295.8349","GSS Developer","INSERT INTO `log` (`level`, `category`, `log_time`, `prefix`, `message`) VALUES (0, \'Login\', 1602820295.8347, \'GSS Developer\', \'Login\')"),
(266,4,"yii\\db\\Command::execute","1602820667.1309","GSS Developer","INSERT INTO `akt_pembelian` (`no_order_pembelian`, `no_pembelian`, `no_penerimaan`, `tanggal_order_pembelian`, `id_customer`, `id_mata_uang`, `status`) VALUES (\'PO2010002\', \'PE2010002\', \'PQ2010002\', \'2020-10-16\', 1, 1, 1)"),
(267,4,"yii\\db\\Command::execute","1602820709.2072","GSS Developer","INSERT INTO `akt_pembelian_detail` (`id_pembelian`, `id_item_stok`, `qty`, `harga`, `diskon`, `total`, `keterangan`) VALUES (2, 1, 10, 10000, 0, 100000, \'\')"),
(268,4,"yii\\db\\Command::execute","1602820721.5904","GSS Developer","UPDATE `akt_approver` SET `id_login`=11, `tingkat_approver`=1 WHERE `id_approver`=52"),
(269,4,"yii\\db\\Command::execute","1602820735.3918","GSS Developer","UPDATE `akt_approver` SET `id_login`=NULL, `tingkat_approver`=1 WHERE `id_approver`=52"),
(270,4,"yii\\db\\Command::execute","1602820744.9705","GSS Developer","UPDATE `akt_pembelian` SET `id_customer`=1, `id_mata_uang`=1, `ongkir`=0, `diskon`=0, `pajak`=0, `total`=100000, `jenis_bayar`=1, `materai`=0, `uang_muka`=0, `id_kas_bank`=NULL, `tanggal_estimasi`=\'2020-10-16\' WHERE `id_pembelian`=2"),
(271,4,"yii\\db\\Command::execute","1602820748.5274","GSS Developer","UPDATE `akt_approver` SET `id_login`=11, `tingkat_approver`=1 WHERE `id_approver`=52"),
(272,4,"yii\\db\\Command::execute","1602820757.84","GSS Developer","INSERT INTO `akt_jurnal_umum` (`no_jurnal_umum`, `tipe`, `tanggal`, `keterangan`) VALUES (\'JU2010004\', 1, \'2020-10-16\', \'Order Pembelian : PO2010002\')"),
(273,4,"yii\\db\\Command::execute","1602820757.8539","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=8200000 WHERE `id_akun`=117"),
(274,4,"yii\\db\\Command::execute","1602820757.8551","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (8, 117, 100000, \'Order Pembelian : PO2010002\')"),
(275,4,"yii\\db\\Command::execute","1602820757.8585","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=9045000 WHERE `id_akun`=64"),
(276,4,"yii\\db\\Command::execute","1602820757.8596","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `kredit`, `keterangan`) VALUES (8, 64, 100000, \'Order Pembelian : PO2010002\')"),
(277,4,"yii\\db\\Command::execute","1602820757.8618","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (8, 53, 0, \'Order Pembelian : PO2010002\')"),
(278,4,"yii\\db\\Command::execute","1602820757.8638","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (8, 122, 0, \'Order Pembelian : PO2010002\')"),
(279,4,"yii\\db\\Command::execute","1602820757.8657","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (8, 115, 0, \'Order Pembelian : PO2010002\')"),
(280,4,"yii\\db\\Command::execute","1602820757.8688","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (8, 38, 0, \'Order Pembelian : PO2010002\')"),
(281,4,"yii\\db\\Command::execute","1602820757.8701","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `keterangan`) VALUES (8, 1, \'Order Pembelian : PO2010002\')"),
(282,4,"yii\\db\\Command::execute","1602820757.8709","GSS Developer","UPDATE `akt_pembelian` SET `tanggal_pembelian`=\'2020-10-16\', `tanggal_tempo`=\'1970-01-01\', `status`=2, `tanggal_approve`=\'2020-10-16 10:59:17\', `id_login`=11 WHERE `id_pembelian`=2"),
(283,4,"yii\\db\\Command::execute","1602820757.8732","GSS Developer","INSERT INTO `akt_history_transaksi` (`nama_tabel`, `id_tabel`, `id_jurnal_umum`) VALUES (\'akt_pembelian\', 2, 8)"),
(284,0,"Login","1602829863.0737","GSS Developer","Login"),
(285,4,"yii\\db\\Command::execute","1602829863.074","GSS Developer","INSERT INTO `log` (`level`, `category`, `log_time`, `prefix`, `message`) VALUES (0, \'Login\', 1602829863.0737, \'GSS Developer\', \'Login\')"),
(286,0,"Login","1602848377.9855","GSS Developer","Login"),
(287,4,"yii\\db\\Command::execute","1602848377.9857","GSS Developer","INSERT INTO `log` (`level`, `category`, `log_time`, `prefix`, `message`) VALUES (0, \'Login\', 1602848377.9855, \'GSS Developer\', \'Login\')"),
(288,4,"yii\\db\\Command::execute","1602848414.2558","GSS Developer","INSERT INTO `menu_navigasi` (`nama_menu`, `url`, `id_parent`, `icon`, `status`, `no_urut`) VALUES (\'Pengaturan\', \'pengaturan\', 37, \'cog\', 0, 7)"),
(289,4,"yii\\db\\Command::execute","1602848417.0751","GSS Developer","DELETE FROM `menu_navigasi_role` WHERE `id_menu`=\'99\'"),
(290,4,"yii\\db\\Command::execute","1602848417.0777","GSS Developer","INSERT INTO `menu_navigasi_role` (`id_system_role`, `id_menu`) VALUES (9, 99)"),
(291,4,"yii\\db\\Command::execute","1602848417.0908","GSS Developer","INSERT INTO `menu_navigasi_role` (`id_system_role`, `id_menu`) VALUES (6, 99)"),
(292,4,"yii\\db\\Command::execute","1602848417.0936","GSS Developer","INSERT INTO `menu_navigasi_role` (`id_system_role`, `id_menu`) VALUES (1, 99)"),
(293,4,"yii\\db\\Command::execute","1602848447.6367","GSS Developer","UPDATE `akt_pembelian` SET `jenis_bayar`=NULL WHERE `id_pembelian`=2"),
(294,4,"yii\\db\\Command::execute","1602848447.6564","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=8100000 WHERE `id_akun`=117"),
(295,4,"yii\\db\\Command::execute","1602848447.6579","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=40"),
(296,4,"yii\\db\\Command::execute","1602848447.6633","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=8945000 WHERE `id_akun`=64"),
(297,4,"yii\\db\\Command::execute","1602848447.6646","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=41"),
(298,4,"yii\\db\\Command::execute","1602848447.6662","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=42"),
(299,4,"yii\\db\\Command::execute","1602848447.6695","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=43"),
(300,4,"yii\\db\\Command::execute","1602848447.6711","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=44"),
(301,4,"yii\\db\\Command::execute","1602848447.6733","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=45"),
(302,4,"yii\\db\\Command::execute","1602848447.6755","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=46"),
(303,4,"yii\\db\\Command::execute","1602848447.6783","GSS Developer","DELETE FROM `akt_jurnal_umum` WHERE `id_jurnal_umum`=8"),
(304,4,"yii\\db\\Command::execute","1602848447.6796","GSS Developer","DELETE FROM `akt_history_transaksi` WHERE `id_history_transaksi`=15"),
(305,4,"yii\\db\\Command::execute","1602848470.9344","GSS Developer","UPDATE `akt_pembelian` SET `id_customer`=1, `id_mata_uang`=1, `ongkir`=100000, `diskon`=0, `pajak`=0, `total`=200000, `jenis_bayar`=1, `tanggal_tempo`=NULL, `materai`=0, `uang_muka`=0, `id_kas_bank`=NULL WHERE `id_pembelian`=2"),
(306,4,"yii\\db\\Command::execute","1602848470.9456","GSS Developer","INSERT INTO `akt_jurnal_umum` (`no_jurnal_umum`, `tipe`, `tanggal`, `keterangan`) VALUES (\'JU2010004\', 1, \'2020-10-16\', \'Pembelian : PE2010002\')"),
(307,4,"yii\\db\\Command::execute","1602848470.9573","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=8200000 WHERE `id_akun`=117"),
(308,4,"yii\\db\\Command::execute","1602848470.9587","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (9, 117, 100000, \'Pembelian : PE2010002\')"),
(309,4,"yii\\db\\Command::execute","1602848470.9605","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=9145000 WHERE `id_akun`=64"),
(310,4,"yii\\db\\Command::execute","1602848470.9616","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `kredit`, `keterangan`) VALUES (9, 64, 200000, \'Pembelian : PE2010002\')"),
(311,4,"yii\\db\\Command::execute","1602848470.9636","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (9, 53, 0, \'Pembelian : PE2010002\')"),
(312,4,"yii\\db\\Command::execute","1602848470.9672","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=135000 WHERE `id_akun`=122"),
(313,4,"yii\\db\\Command::execute","1602848470.9683","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (9, 122, 100000, \'Pembelian : PE2010002\')"),
(314,4,"yii\\db\\Command::execute","1602848470.9715","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (9, 115, 0, \'Pembelian : PE2010002\')"),
(315,4,"yii\\db\\Command::execute","1602848470.979","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (9, 38, 0, \'Pembelian : PE2010002\')"),
(316,4,"yii\\db\\Command::execute","1602848470.9837","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `keterangan`) VALUES (9, 1, \'Pembelian : PE2010002\')"),
(317,4,"yii\\db\\Command::execute","1602848470.9969","GSS Developer","INSERT INTO `akt_history_transaksi` (`nama_tabel`, `id_tabel`, `id_jurnal_umum`) VALUES (\'akt_pembelian\', 2, 9)"),
(318,4,"yii\\db\\Command::execute","1602850473.9323","GSS Developer","INSERT INTO `akt_pembelian` (`no_pembelian`, `no_penerimaan`, `tanggal_pembelian`, `id_customer`, `id_mata_uang`, `status`) VALUES (\'PE2010003\', \'PQ2010003\', \'2020-10-16\', 1, 1, 2)"),
(319,4,"yii\\db\\Command::execute","1602850500.0944","GSS Developer","INSERT INTO `akt_pembelian_detail` (`id_pembelian`, `id_item_stok`, `qty`, `harga`, `diskon`, `total`, `keterangan`) VALUES (3, 1, 1, 2000, 0, 2000, \'\')"),
(320,4,"yii\\db\\Command::execute","1602850546.4161","GSS Developer","UPDATE `akt_pembelian` SET `id_customer`=1, `id_mata_uang`=1, `ongkir`=0, `diskon`=0, `pajak`=1, `total`=1200, `jenis_bayar`=1, `materai`=0, `uang_muka`=1000, `id_kas_bank`=1 WHERE `id_pembelian`=3"),
(321,4,"yii\\db\\Command::execute","1602850546.4282","GSS Developer","INSERT INTO `akt_jurnal_umum` (`no_jurnal_umum`, `tipe`, `tanggal`, `keterangan`) VALUES (\'JU2010005\', 1, \'2020-10-16\', \'Pembelian : PE2010003\')"),
(322,4,"yii\\db\\Command::execute","1602850546.4406","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=8202000 WHERE `id_akun`=117"),
(323,4,"yii\\db\\Command::execute","1602850546.4449","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (10, 117, 2000, \'Pembelian : PE2010003\')"),
(324,4,"yii\\db\\Command::execute","1602850546.4469","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=9147200 WHERE `id_akun`=64"),
(325,4,"yii\\db\\Command::execute","1602850546.448","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `kredit`, `keterangan`) VALUES (10, 64, 2200, \'Pembelian : PE2010003\')"),
(326,4,"yii\\db\\Command::execute","1602850546.4495","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=810200 WHERE `id_akun`=53"),
(327,4,"yii\\db\\Command::execute","1602850546.4505","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (10, 53, 200, \'Pembelian : PE2010003\')"),
(328,4,"yii\\db\\Command::execute","1602850546.4518","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (10, 122, 0, \'Pembelian : PE2010003\')"),
(329,4,"yii\\db\\Command::execute","1602850546.455","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (10, 115, 0, \'Pembelian : PE2010003\')"),
(330,4,"yii\\db\\Command::execute","1602850546.4565","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=1000 WHERE `id_akun`=38"),
(331,4,"yii\\db\\Command::execute","1602850546.4575","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (10, 38, 1000, \'Pembelian : PE2010003\')"),
(332,4,"yii\\db\\Command::execute","1602850546.4652","GSS Developer","UPDATE `akt_kas_bank` SET `saldo`=49999000 WHERE `id_kas_bank`=1"),
(333,4,"yii\\db\\Command::execute","1602850546.4666","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `kredit`, `keterangan`) VALUES (10, 1, 1000, \'Pembelian : PE2010003\')"),
(334,4,"yii\\db\\Command::execute","1602850546.4696","GSS Developer","INSERT INTO `akt_history_transaksi` (`nama_tabel`, `id_tabel`, `id_jurnal_umum`) VALUES (\'akt_kas_bank\', 1, 60)"),
(335,4,"yii\\db\\Command::execute","1602850546.471","GSS Developer","INSERT INTO `akt_history_transaksi` (`nama_tabel`, `id_tabel`, `id_jurnal_umum`) VALUES (\'akt_pembelian\', 3, 10)"),
(336,4,"yii\\db\\Command::execute","1602850582.3763","GSS Developer","UPDATE `akt_pembelian` SET `pajak`=0, `jenis_bayar`=NULL, `uang_muka`=0, `id_kas_bank`=NULL WHERE `id_pembelian`=3"),
(337,4,"yii\\db\\Command::execute","1602850582.4012","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=8200000 WHERE `id_akun`=117"),
(338,4,"yii\\db\\Command::execute","1602850582.4068","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=54"),
(339,4,"yii\\db\\Command::execute","1602850582.4179","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=9145000 WHERE `id_akun`=64"),
(340,4,"yii\\db\\Command::execute","1602850582.4216","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=55"),
(341,4,"yii\\db\\Command::execute","1602850582.4273","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=810000 WHERE `id_akun`=53"),
(342,4,"yii\\db\\Command::execute","1602850582.432","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=56"),
(343,4,"yii\\db\\Command::execute","1602850582.4416","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=57"),
(344,4,"yii\\db\\Command::execute","1602850582.4474","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=58"),
(345,4,"yii\\db\\Command::execute","1602850582.4527","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=0 WHERE `id_akun`=38"),
(346,4,"yii\\db\\Command::execute","1602850582.4574","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=59"),
(347,4,"yii\\db\\Command::execute","1602850582.4622","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=60"),
(348,4,"yii\\db\\Command::execute","1602850582.4663","GSS Developer","DELETE FROM `akt_jurnal_umum` WHERE `id_jurnal_umum`=10"),
(349,4,"yii\\db\\Command::execute","1602850582.472","GSS Developer","DELETE FROM `akt_history_transaksi` WHERE `id_history_transaksi`=18"),
(350,4,"yii\\db\\Command::execute","1602850639.657","GSS Developer","UPDATE `akt_pembelian` SET `id_customer`=1, `id_mata_uang`=1, `ongkir`=0, `diskon`=0, `pajak`=0, `total`=1000, `jenis_bayar`=1, `materai`=0, `uang_muka`=1000, `id_kas_bank`=1 WHERE `id_pembelian`=3"),
(351,4,"yii\\db\\Command::execute","1602850639.6796","GSS Developer","INSERT INTO `akt_jurnal_umum` (`no_jurnal_umum`, `tipe`, `tanggal`, `keterangan`) VALUES (\'JU2010005\', 1, \'2020-10-16\', \'Pembelian : PE2010003\')"),
(352,4,"yii\\db\\Command::execute","1602850639.7067","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=8202000 WHERE `id_akun`=117"),
(353,4,"yii\\db\\Command::execute","1602850639.7101","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (11, 117, 2000, \'Pembelian : PE2010003\')"),
(354,4,"yii\\db\\Command::execute","1602850639.7223","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=9147000 WHERE `id_akun`=64"),
(355,4,"yii\\db\\Command::execute","1602850639.7236","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `kredit`, `keterangan`) VALUES (11, 64, 2000, \'Pembelian : PE2010003\')"),
(356,4,"yii\\db\\Command::execute","1602850639.7251","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (11, 53, 0, \'Pembelian : PE2010003\')"),
(357,4,"yii\\db\\Command::execute","1602850639.7264","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (11, 122, 0, \'Pembelian : PE2010003\')"),
(358,4,"yii\\db\\Command::execute","1602850639.7278","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (11, 115, 0, \'Pembelian : PE2010003\')"),
(359,4,"yii\\db\\Command::execute","1602850639.7291","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=1000 WHERE `id_akun`=38"),
(360,4,"yii\\db\\Command::execute","1602850639.7301","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (11, 38, 1000, \'Pembelian : PE2010003\')"),
(361,4,"yii\\db\\Command::execute","1602850639.7517","GSS Developer","UPDATE `akt_kas_bank` SET `saldo`=49998000 WHERE `id_kas_bank`=1"),
(362,4,"yii\\db\\Command::execute","1602850639.7586","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `kredit`, `keterangan`) VALUES (11, 1, 1000, \'Pembelian : PE2010003\')"),
(363,4,"yii\\db\\Command::execute","1602850639.7666","GSS Developer","INSERT INTO `akt_history_transaksi` (`nama_tabel`, `id_tabel`, `id_jurnal_umum`) VALUES (\'akt_kas_bank\', 1, 67)"),
(364,4,"yii\\db\\Command::execute","1602850639.7719","GSS Developer","INSERT INTO `akt_history_transaksi` (`nama_tabel`, `id_tabel`, `id_jurnal_umum`) VALUES (\'akt_pembelian\', 3, 11)"),
(365,4,"yii\\db\\Command::execute","1602850642.866","GSS Developer","UPDATE `akt_pembelian` SET `status`=5 WHERE `id_pembelian`=3"),
(366,0,"Login","1602850959.5223","GSS Developer","Login"),
(367,4,"yii\\db\\Command::execute","1602850959.5225","GSS Developer","INSERT INTO `log` (`level`, `category`, `log_time`, `prefix`, `message`) VALUES (0, \'Login\', 1602850959.5223, \'GSS Developer\', \'Login\')"),
(368,4,"yii\\db\\Command::execute","1602851374.1502","GSS Developer","INSERT INTO `akt_pembelian` (`no_pembelian`, `no_penerimaan`, `tanggal_pembelian`, `id_customer`, `id_mata_uang`, `status`) VALUES (\'PE2010004\', \'PQ2010004\', \'2020-10-16\', 2, 1, 2)"),
(369,4,"yii\\db\\Command::execute","1602851383.4486","GSS Developer","INSERT INTO `akt_pembelian_detail` (`id_pembelian`, `id_item_stok`, `qty`, `harga`, `diskon`, `total`, `keterangan`) VALUES (4, 1, 3, 2000, 0, 6000, \'\')"),
(370,4,"yii\\db\\Command::execute","1602851861.406","GSS Developer","INSERT INTO `akt_mitra_bisnis` (`kode_mitra_bisnis`, `nama_mitra_bisnis`, `deskripsi_mitra_bisnis`, `tipe_mitra_bisnis`, `status_mitra_bisnis`, `id_level_harga`) VALUES (\'MB006\', \'Wisnu\', \'qwe\', 2, 1, 1)"),
(371,4,"yii\\db\\Command::execute","1602853201.4027","GSS Developer","UPDATE `pengaturan` SET `status`=0 WHERE `id_pengaturan`=1"),
(372,4,"yii\\db\\Command::execute","1602853226.7131","GSS Developer","UPDATE `pengaturan` SET `status`=1 WHERE `id_pengaturan`=1"),
(373,4,"yii\\db\\Command::execute","1602853266.2747","GSS Developer","UPDATE `pengaturan` SET `status`=0 WHERE `id_pengaturan`=1"),
(374,4,"yii\\db\\Command::execute","1602863257.8511","GSS Developer","UPDATE `pengaturan` SET `status`=1 WHERE `id_pengaturan`=2"),
(375,4,"yii\\db\\Command::execute","1602863281.5784","GSS Developer","INSERT INTO `akt_penjualan` (`no_penjualan`, `tanggal_penjualan`, `id_customer`, `id_sales`, `id_mata_uang`, `status`) VALUES (\'PJ2010001\', \'2020-10-16\', 3, 1, 1, 2)"),
(376,4,"yii\\db\\Command::execute","1602863403.5169","GSS Developer","INSERT INTO `akt_penjualan_detail` (`id_penjualan`, `id_item_stok`, `qty`, `harga`, `diskon`, `total`, `id_item_harga_jual`, `keterangan`) VALUES (5, 1, 1, 4000, 0, 4000, 1, \'\')"),
(377,4,"yii\\db\\Command::execute","1602863403.5518","GSS Developer","UPDATE `akt_penjualan` SET `total`=4000 WHERE `id_penjualan`=5"),
(378,4,"yii\\db\\Command::execute","1602863462.9294","GSS Developer","UPDATE `akt_penjualan` SET `id_customer`=3, `id_sales`=1, `id_mata_uang`=1, `pajak`=1, `uang_muka`=100, `id_kas_bank`=1, `total`=3860, `diskon`=10, `jenis_bayar`=1, `tanggal_estimasi`=\'2020-10-16\' WHERE `id_penjualan`=5"),
(379,4,"yii\\db\\Command::execute","1602863462.9342","GSS Developer","INSERT INTO `akt_jurnal_umum` (`no_jurnal_umum`, `tipe`, `tanggal`, `keterangan`) VALUES (\'JU2010006\', 1, \'2020-10-16\', \'Penjualan : PJ2010001\')"),
(380,4,"yii\\db\\Command::execute","1602863462.97","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=8198400 WHERE `id_akun`=117"),
(381,4,"yii\\db\\Command::execute","1602863462.9715","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `kredit`, `keterangan`) VALUES (12, 117, 3600, \'Penjualan : PJ2010001\')"),
(382,4,"yii\\db\\Command::execute","1602863462.9733","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=3960 WHERE `id_akun`=2"),
(383,4,"yii\\db\\Command::execute","1602863462.9753","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (12, 2, 3960, \'Penjualan : PJ2010001\')"),
(384,4,"yii\\db\\Command::execute","1602863462.9769","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=360 WHERE `id_akun`=73"),
(385,4,"yii\\db\\Command::execute","1602863462.9783","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `kredit`, `keterangan`) VALUES (12, 73, 360, \'Penjualan : PJ2010001\')"),
(386,4,"yii\\db\\Command::execute","1602863462.9814","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `kredit`, `keterangan`) VALUES (12, 47, NULL, \'Penjualan : PJ2010001\')"),
(387,4,"yii\\db\\Command::execute","1602863462.9831","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (12, 115, NULL, \'Penjualan : PJ2010001\')"),
(388,4,"yii\\db\\Command::execute","1602863462.9865","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=100 WHERE `id_akun`=131"),
(389,4,"yii\\db\\Command::execute","1602863462.9874","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `kredit`, `keterangan`) VALUES (12, 131, 100, \'Penjualan : PJ2010001\')"),
(390,4,"yii\\db\\Command::execute","1602863462.9915","GSS Developer","UPDATE `akt_kas_bank` SET `saldo`=49998100 WHERE `id_kas_bank`=1"),
(391,4,"yii\\db\\Command::execute","1602863462.9932","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (12, 1, 100, \'Penjualan : PJ2010001\')"),
(392,4,"yii\\db\\Command::execute","1602863463.0068","GSS Developer","INSERT INTO `akt_history_transaksi` (`nama_tabel`, `id_tabel`, `id_jurnal_umum`) VALUES (\'akt_kas_bank\', 1, 74)"),
(393,4,"yii\\db\\Command::execute","1602863463.008","GSS Developer","INSERT INTO `akt_history_transaksi` (`nama_tabel`, `id_tabel`, `id_jurnal_umum`) VALUES (\'akt_penjualan\', 5, 12)"),
(394,4,"yii\\db\\Command::execute","1602863490.0815","GSS Developer","UPDATE `akt_penjualan` SET `tanggal_penjualan`=NULL, `ongkir`=0, `pajak`=0, `uang_muka`=0, `id_kas_bank`=NULL, `diskon`=0, `jenis_bayar`=NULL WHERE `id_penjualan`=5"),
(395,4,"yii\\db\\Command::execute","1602863490.0946","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=8202000 WHERE `id_akun`=117"),
(396,4,"yii\\db\\Command::execute","1602863490.0964","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=68"),
(397,4,"yii\\db\\Command::execute","1602863490.0985","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=0 WHERE `id_akun`=2"),
(398,4,"yii\\db\\Command::execute","1602863490.0996","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=69"),
(399,4,"yii\\db\\Command::execute","1602863490.1016","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=0 WHERE `id_akun`=73"),
(400,4,"yii\\db\\Command::execute","1602863490.1031","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=70"),
(401,4,"yii\\db\\Command::execute","1602863490.108","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=71"),
(402,4,"yii\\db\\Command::execute","1602863490.1101","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=72"),
(403,4,"yii\\db\\Command::execute","1602863490.1119","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=0 WHERE `id_akun`=131"),
(404,4,"yii\\db\\Command::execute","1602863490.1132","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=73"),
(405,4,"yii\\db\\Command::execute","1602863490.1156","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=74"),
(406,4,"yii\\db\\Command::execute","1602863490.1167","GSS Developer","DELETE FROM `akt_jurnal_umum` WHERE `id_jurnal_umum`=12"),
(407,4,"yii\\db\\Command::execute","1602863490.1179","GSS Developer","DELETE FROM `akt_history_transaksi` WHERE `id_history_transaksi`=22"),
(408,4,"yii\\db\\Command::execute","1602863515.5699","GSS Developer","UPDATE `pengaturan` SET `status`=0 WHERE `id_pengaturan`=2"),
(409,4,"yii\\db\\Command::execute","1602864872.1899","GSS Developer","UPDATE `pengaturan` SET `status`=1 WHERE `id_pengaturan`=1"),
(410,4,"yii\\db\\Command::execute","1602865202.8236","GSS Developer","UPDATE `akt_pembelian` SET `id_customer`=2, `id_mata_uang`=1, `ongkir`=1000, `diskon`=5, `pajak`=1, `total`=7270, `jenis_bayar`=1, `materai`=0, `uang_muka`=0, `id_kas_bank`=NULL WHERE `id_pembelian`=4"),
(411,4,"yii\\db\\Command::execute","1602865202.8776","GSS Developer","INSERT INTO `akt_jurnal_umum` (`no_jurnal_umum`, `tipe`, `tanggal`, `keterangan`) VALUES (\'JU2010006\', 1, \'2020-10-16\', \'Pembelian : PE2010004\')"),
(412,4,"yii\\db\\Command::execute","1602865202.9089","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=8207700 WHERE `id_akun`=117"),
(413,4,"yii\\db\\Command::execute","1602865202.9152","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (13, 117, 5700, \'Pembelian : PE2010004\')"),
(414,4,"yii\\db\\Command::execute","1602865202.9235","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=9154270 WHERE `id_akun`=64"),
(415,4,"yii\\db\\Command::execute","1602865202.9251","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `kredit`, `keterangan`) VALUES (13, 64, 7270, \'Pembelian : PE2010004\')"),
(416,4,"yii\\db\\Command::execute","1602865202.9311","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=810570 WHERE `id_akun`=53"),
(417,4,"yii\\db\\Command::execute","1602865202.9346","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (13, 53, 570, \'Pembelian : PE2010004\')"),
(418,4,"yii\\db\\Command::execute","1602865202.942","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=136000 WHERE `id_akun`=122"),
(419,4,"yii\\db\\Command::execute","1602865202.9475","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (13, 122, 1000, \'Pembelian : PE2010004\')"),
(420,4,"yii\\db\\Command::execute","1602865202.9535","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (13, 115, 0, \'Pembelian : PE2010004\')"),
(421,4,"yii\\db\\Command::execute","1602865202.9605","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (13, 38, 0, \'Pembelian : PE2010004\')"),
(422,4,"yii\\db\\Command::execute","1602865202.9684","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `keterangan`) VALUES (13, 1, \'Pembelian : PE2010004\')"),
(423,4,"yii\\db\\Command::execute","1602865202.9739","GSS Developer","INSERT INTO `akt_history_transaksi` (`nama_tabel`, `id_tabel`, `id_jurnal_umum`) VALUES (\'akt_pembelian\', 4, 13)"),
(424,4,"yii\\db\\Command::execute","1602865307.5452","GSS Developer","UPDATE `akt_pembelian` SET `ongkir`=0, `diskon`=0, `pajak`=0, `jenis_bayar`=NULL WHERE `id_pembelian`=4"),
(425,4,"yii\\db\\Command::execute","1602865307.5549","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=8202000 WHERE `id_akun`=117"),
(426,4,"yii\\db\\Command::execute","1602865307.556","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=75"),
(427,4,"yii\\db\\Command::execute","1602865307.559","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=9147000 WHERE `id_akun`=64"),
(428,4,"yii\\db\\Command::execute","1602865307.561","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=76"),
(429,4,"yii\\db\\Command::execute","1602865307.5627","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=810000 WHERE `id_akun`=53"),
(430,4,"yii\\db\\Command::execute","1602865307.5652","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=77"),
(431,4,"yii\\db\\Command::execute","1602865307.5669","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=135000 WHERE `id_akun`=122"),
(432,4,"yii\\db\\Command::execute","1602865307.568","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=78"),
(433,4,"yii\\db\\Command::execute","1602865307.5709","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=79"),
(434,4,"yii\\db\\Command::execute","1602865307.5723","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=80"),
(435,4,"yii\\db\\Command::execute","1602865307.5739","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=81"),
(436,4,"yii\\db\\Command::execute","1602865307.5749","GSS Developer","DELETE FROM `akt_jurnal_umum` WHERE `id_jurnal_umum`=13"),
(437,4,"yii\\db\\Command::execute","1602865307.5757","GSS Developer","DELETE FROM `akt_history_transaksi` WHERE `id_history_transaksi`=23"),
(438,4,"yii\\db\\Command::execute","1602865318.8054","GSS Developer","UPDATE `akt_pembelian` SET `id_customer`=2, `id_mata_uang`=1, `ongkir`=0, `diskon`=0, `pajak`=0, `total`=6000, `jenis_bayar`=1, `materai`=0, `uang_muka`=0, `id_kas_bank`=NULL WHERE `id_pembelian`=4"),
(439,4,"yii\\db\\Command::execute","1602865318.8125","GSS Developer","INSERT INTO `akt_jurnal_umum` (`no_jurnal_umum`, `tipe`, `tanggal`, `keterangan`) VALUES (\'JU2010006\', 1, \'2020-10-16\', \'Pembelian : PE2010004\')"),
(440,4,"yii\\db\\Command::execute","1602865318.8218","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=8208000 WHERE `id_akun`=117"),
(441,4,"yii\\db\\Command::execute","1602865318.8229","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (14, 117, 6000, \'Pembelian : PE2010004\')"),
(442,4,"yii\\db\\Command::execute","1602865318.8258","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=9153000 WHERE `id_akun`=64"),
(443,4,"yii\\db\\Command::execute","1602865318.8267","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `kredit`, `keterangan`) VALUES (14, 64, 6000, \'Pembelian : PE2010004\')"),
(444,4,"yii\\db\\Command::execute","1602865318.8281","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (14, 53, 0, \'Pembelian : PE2010004\')"),
(445,4,"yii\\db\\Command::execute","1602865318.8296","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (14, 122, 0, \'Pembelian : PE2010004\')"),
(446,4,"yii\\db\\Command::execute","1602865318.831","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (14, 115, 0, \'Pembelian : PE2010004\')"),
(447,4,"yii\\db\\Command::execute","1602865318.8325","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (14, 38, 0, \'Pembelian : PE2010004\')"),
(448,4,"yii\\db\\Command::execute","1602865318.8339","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `keterangan`) VALUES (14, 1, \'Pembelian : PE2010004\')"),
(449,4,"yii\\db\\Command::execute","1602865318.8366","GSS Developer","INSERT INTO `akt_history_transaksi` (`nama_tabel`, `id_tabel`, `id_jurnal_umum`) VALUES (\'akt_pembelian\', 4, 14)"),
(450,4,"yii\\db\\Command::execute","1602865424.2992","GSS Developer","UPDATE `akt_penjualan` SET `id_customer`=3, `id_sales`=1, `id_mata_uang`=1, `tanggal_penjualan`=NULL, `pajak`=0, `uang_muka`=0, `id_kas_bank`=NULL, `total`=4000, `diskon`=0, `jenis_bayar`=1 WHERE `id_penjualan`=5"),
(451,4,"yii\\db\\Command::execute","1602865424.304","GSS Developer","INSERT INTO `akt_jurnal_umum` (`no_jurnal_umum`, `tipe`, `tanggal`, `keterangan`) VALUES (\'JU2010007\', 1, \'2020-10-16\', \'Penjualan : PJ2010001\')"),
(452,4,"yii\\db\\Command::execute","1602865424.3158","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=8204000 WHERE `id_akun`=117"),
(453,4,"yii\\db\\Command::execute","1602865424.3168","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `kredit`, `keterangan`) VALUES (15, 117, 4000, \'Penjualan : PJ2010001\')"),
(454,4,"yii\\db\\Command::execute","1602865424.3178","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=4000 WHERE `id_akun`=2"),
(455,4,"yii\\db\\Command::execute","1602865424.3186","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (15, 2, 4000, \'Penjualan : PJ2010001\')"),
(456,4,"yii\\db\\Command::execute","1602865424.3199","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `kredit`, `keterangan`) VALUES (15, 73, 0, \'Penjualan : PJ2010001\')"),
(457,4,"yii\\db\\Command::execute","1602865424.321","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `kredit`, `keterangan`) VALUES (15, 47, 0, \'Penjualan : PJ2010001\')"),
(458,4,"yii\\db\\Command::execute","1602865424.3221","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (15, 115, NULL, \'Penjualan : PJ2010001\')"),
(459,4,"yii\\db\\Command::execute","1602865424.3244","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `kredit`, `keterangan`) VALUES (15, 131, 0, \'Penjualan : PJ2010001\')"),
(460,4,"yii\\db\\Command::execute","1602865424.3255","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `keterangan`) VALUES (15, 1, \'Penjualan : PJ2010001\')"),
(461,4,"yii\\db\\Command::execute","1602865424.3273","GSS Developer","INSERT INTO `akt_history_transaksi` (`nama_tabel`, `id_tabel`, `id_jurnal_umum`) VALUES (\'akt_penjualan\', 5, 15)"),
(462,4,"yii\\db\\Command::execute","1602865460.7718","GSS Developer","UPDATE `akt_penjualan` SET `jenis_bayar`=NULL WHERE `id_penjualan`=5"),
(463,4,"yii\\db\\Command::execute","1602865460.7918","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=8208000 WHERE `id_akun`=117"),
(464,4,"yii\\db\\Command::execute","1602865460.7971","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=89"),
(465,4,"yii\\db\\Command::execute","1602865460.7988","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=0 WHERE `id_akun`=2"),
(466,4,"yii\\db\\Command::execute","1602865460.7997","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=90"),
(467,4,"yii\\db\\Command::execute","1602865460.8011","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=91"),
(468,4,"yii\\db\\Command::execute","1602865460.8042","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=92"),
(469,4,"yii\\db\\Command::execute","1602865460.8055","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=93"),
(470,4,"yii\\db\\Command::execute","1602865460.8067","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=94"),
(471,4,"yii\\db\\Command::execute","1602865460.8082","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=95"),
(472,4,"yii\\db\\Command::execute","1602865460.809","GSS Developer","DELETE FROM `akt_jurnal_umum` WHERE `id_jurnal_umum`=15"),
(473,4,"yii\\db\\Command::execute","1602865460.8098","GSS Developer","DELETE FROM `akt_history_transaksi` WHERE `id_history_transaksi`=25"),
(474,4,"yii\\db\\Command::execute","1602865469.6562","GSS Developer","UPDATE `akt_penjualan` SET `id_customer`=3, `id_sales`=1, `id_mata_uang`=1, `tanggal_penjualan`=NULL, `pajak`=0, `uang_muka`=0, `id_kas_bank`=NULL, `diskon`=0, `jenis_bayar`=1 WHERE `id_penjualan`=5"),
(475,4,"yii\\db\\Command::execute","1602865469.6602","GSS Developer","INSERT INTO `akt_jurnal_umum` (`no_jurnal_umum`, `tipe`, `tanggal`, `keterangan`) VALUES (\'JU2010007\', 1, \'2020-10-16\', \'Penjualan : PJ2010001\')"),
(476,4,"yii\\db\\Command::execute","1602865469.673","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=8204000 WHERE `id_akun`=117"),
(477,4,"yii\\db\\Command::execute","1602865469.6742","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `kredit`, `keterangan`) VALUES (16, 117, 4000, \'Penjualan : PJ2010001\')"),
(478,4,"yii\\db\\Command::execute","1602865469.6757","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=4000 WHERE `id_akun`=2"),
(479,4,"yii\\db\\Command::execute","1602865469.6766","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (16, 2, 4000, \'Penjualan : PJ2010001\')"),
(480,4,"yii\\db\\Command::execute","1602865469.6781","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `kredit`, `keterangan`) VALUES (16, 73, 0, \'Penjualan : PJ2010001\')"),
(481,4,"yii\\db\\Command::execute","1602865469.6796","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `kredit`, `keterangan`) VALUES (16, 47, 0, \'Penjualan : PJ2010001\')"),
(482,4,"yii\\db\\Command::execute","1602865469.6811","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (16, 115, NULL, \'Penjualan : PJ2010001\')"),
(483,4,"yii\\db\\Command::execute","1602865469.6825","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `kredit`, `keterangan`) VALUES (16, 131, 0, \'Penjualan : PJ2010001\')"),
(484,4,"yii\\db\\Command::execute","1602865469.6839","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `keterangan`) VALUES (16, 1, \'Penjualan : PJ2010001\')"),
(485,4,"yii\\db\\Command::execute","1602865469.6866","GSS Developer","INSERT INTO `akt_history_transaksi` (`nama_tabel`, `id_tabel`, `id_jurnal_umum`) VALUES (\'akt_penjualan\', 5, 16)"),
(486,4,"yii\\db\\Command::execute","1602865485.2562","GSS Developer","UPDATE `akt_pembelian` SET `jenis_bayar`=NULL WHERE `id_pembelian`=4"),
(487,4,"yii\\db\\Command::execute","1602865485.2669","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=8198000 WHERE `id_akun`=117"),
(488,4,"yii\\db\\Command::execute","1602865485.2681","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=82"),
(489,4,"yii\\db\\Command::execute","1602865485.2695","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=9147000 WHERE `id_akun`=64"),
(490,4,"yii\\db\\Command::execute","1602865485.2705","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=83"),
(491,4,"yii\\db\\Command::execute","1602865485.2716","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=84"),
(492,4,"yii\\db\\Command::execute","1602865485.2731","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=85"),
(493,4,"yii\\db\\Command::execute","1602865485.2744","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=86"),
(494,4,"yii\\db\\Command::execute","1602865485.2757","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=87"),
(495,4,"yii\\db\\Command::execute","1602865485.2771","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=88"),
(496,4,"yii\\db\\Command::execute","1602865485.2779","GSS Developer","DELETE FROM `akt_jurnal_umum` WHERE `id_jurnal_umum`=14"),
(497,4,"yii\\db\\Command::execute","1602865485.2787","GSS Developer","DELETE FROM `akt_history_transaksi` WHERE `id_history_transaksi`=24"),
(498,4,"yii\\db\\Command::execute","1602865495.0079","GSS Developer","UPDATE `akt_pembelian` SET `id_customer`=2, `id_mata_uang`=1, `ongkir`=0, `diskon`=0, `pajak`=0, `jenis_bayar`=1, `materai`=0, `uang_muka`=0, `id_kas_bank`=NULL WHERE `id_pembelian`=4"),
(499,4,"yii\\db\\Command::execute","1602865495.0153","GSS Developer","INSERT INTO `akt_jurnal_umum` (`no_jurnal_umum`, `tipe`, `tanggal`, `keterangan`) VALUES (\'JU2010008\', 1, \'2020-10-16\', \'Pembelian : PE2010004\')"),
(500,4,"yii\\db\\Command::execute","1602865495.0247","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=8204000 WHERE `id_akun`=117"),
(501,4,"yii\\db\\Command::execute","1602865495.0258","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (17, 117, 6000, \'Pembelian : PE2010004\')"),
(502,4,"yii\\db\\Command::execute","1602865495.0272","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=9153000 WHERE `id_akun`=64"),
(503,4,"yii\\db\\Command::execute","1602865495.0282","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `kredit`, `keterangan`) VALUES (17, 64, 6000, \'Pembelian : PE2010004\')"),
(504,4,"yii\\db\\Command::execute","1602865495.0296","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (17, 53, 0, \'Pembelian : PE2010004\')"),
(505,4,"yii\\db\\Command::execute","1602865495.031","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (17, 122, 0, \'Pembelian : PE2010004\')"),
(506,4,"yii\\db\\Command::execute","1602865495.0325","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (17, 115, 0, \'Pembelian : PE2010004\')"),
(507,4,"yii\\db\\Command::execute","1602865495.034","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (17, 38, 0, \'Pembelian : PE2010004\')"),
(508,4,"yii\\db\\Command::execute","1602865495.0354","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `keterangan`) VALUES (17, 1, \'Pembelian : PE2010004\')"),
(509,4,"yii\\db\\Command::execute","1602865495.0382","GSS Developer","INSERT INTO `akt_history_transaksi` (`nama_tabel`, `id_tabel`, `id_jurnal_umum`) VALUES (\'akt_pembelian\', 4, 17)"),
(510,4,"yii\\db\\Command::execute","1602865501.3987","GSS Developer","UPDATE `akt_pembelian` SET `jenis_bayar`=NULL WHERE `id_pembelian`=4"),
(511,4,"yii\\db\\Command::execute","1602865501.437","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=8198000 WHERE `id_akun`=117"),
(512,4,"yii\\db\\Command::execute","1602865501.4695","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=103"),
(513,4,"yii\\db\\Command::execute","1602865501.5093","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=9147000 WHERE `id_akun`=64"),
(514,4,"yii\\db\\Command::execute","1602865501.5135","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=104"),
(515,4,"yii\\db\\Command::execute","1602865501.5193","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=105"),
(516,4,"yii\\db\\Command::execute","1602865501.523","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=106"),
(517,4,"yii\\db\\Command::execute","1602865501.5305","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=107"),
(518,4,"yii\\db\\Command::execute","1602865501.5425","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=108"),
(519,4,"yii\\db\\Command::execute","1602865501.547","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=109"),
(520,4,"yii\\db\\Command::execute","1602865501.5531","GSS Developer","DELETE FROM `akt_jurnal_umum` WHERE `id_jurnal_umum`=17"),
(521,4,"yii\\db\\Command::execute","1602865501.5566","GSS Developer","DELETE FROM `akt_history_transaksi` WHERE `id_history_transaksi`=27"),
(522,4,"yii\\db\\Command::execute","1602865527.2075","GSS Developer","UPDATE `akt_pembelian` SET `id_customer`=2, `id_mata_uang`=1, `ongkir`=10, `diskon`=0, `pajak`=0, `total`=6010, `jenis_bayar`=1, `materai`=0, `uang_muka`=0, `id_kas_bank`=NULL WHERE `id_pembelian`=4"),
(523,4,"yii\\db\\Command::execute","1602865527.2147","GSS Developer","INSERT INTO `akt_jurnal_umum` (`no_jurnal_umum`, `tipe`, `tanggal`, `keterangan`) VALUES (\'JU2010008\', 1, \'2020-10-16\', \'Pembelian : PE2010004\')"),
(524,4,"yii\\db\\Command::execute","1602865527.229","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=8204000 WHERE `id_akun`=117"),
(525,4,"yii\\db\\Command::execute","1602865527.2311","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (18, 117, 6000, \'Pembelian : PE2010004\')"),
(526,4,"yii\\db\\Command::execute","1602865527.2348","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=9153010 WHERE `id_akun`=64"),
(527,4,"yii\\db\\Command::execute","1602865527.2358","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `kredit`, `keterangan`) VALUES (18, 64, 6010, \'Pembelian : PE2010004\')"),
(528,4,"yii\\db\\Command::execute","1602865527.2371","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (18, 53, 0, \'Pembelian : PE2010004\')"),
(529,4,"yii\\db\\Command::execute","1602865527.2383","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=135010 WHERE `id_akun`=122"),
(530,4,"yii\\db\\Command::execute","1602865527.239","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (18, 122, 10, \'Pembelian : PE2010004\')"),
(531,4,"yii\\db\\Command::execute","1602865527.2402","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (18, 115, 0, \'Pembelian : PE2010004\')"),
(532,4,"yii\\db\\Command::execute","1602865527.2429","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (18, 38, 0, \'Pembelian : PE2010004\')"),
(533,4,"yii\\db\\Command::execute","1602865527.2442","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `keterangan`) VALUES (18, 1, \'Pembelian : PE2010004\')"),
(534,4,"yii\\db\\Command::execute","1602865527.2465","GSS Developer","INSERT INTO `akt_history_transaksi` (`nama_tabel`, `id_tabel`, `id_jurnal_umum`) VALUES (\'akt_pembelian\', 4, 18)"),
(535,4,"yii\\db\\Command::execute","1602865534.817","GSS Developer","UPDATE `akt_pembelian` SET `ongkir`=0, `jenis_bayar`=NULL WHERE `id_pembelian`=4"),
(536,4,"yii\\db\\Command::execute","1602865534.8249","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=8198000 WHERE `id_akun`=117"),
(537,4,"yii\\db\\Command::execute","1602865534.8257","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=110"),
(538,4,"yii\\db\\Command::execute","1602865534.8268","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=9147000 WHERE `id_akun`=64"),
(539,4,"yii\\db\\Command::execute","1602865534.8277","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=111"),
(540,4,"yii\\db\\Command::execute","1602865534.8289","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=112"),
(541,4,"yii\\db\\Command::execute","1602865534.83","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=135000 WHERE `id_akun`=122"),
(542,4,"yii\\db\\Command::execute","1602865534.8307","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=113"),
(543,4,"yii\\db\\Command::execute","1602865534.8318","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=114"),
(544,4,"yii\\db\\Command::execute","1602865534.833","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=115"),
(545,4,"yii\\db\\Command::execute","1602865534.8344","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=116"),
(546,4,"yii\\db\\Command::execute","1602865534.835","GSS Developer","DELETE FROM `akt_jurnal_umum` WHERE `id_jurnal_umum`=18"),
(547,4,"yii\\db\\Command::execute","1602865534.8358","GSS Developer","DELETE FROM `akt_history_transaksi` WHERE `id_history_transaksi`=28"),
(548,4,"yii\\db\\Command::execute","1602865548.902","GSS Developer","UPDATE `akt_pembelian` SET `id_customer`=2, `id_mata_uang`=1, `ongkir`=10000, `diskon`=5, `pajak`=1, `total`=16270, `jenis_bayar`=1, `materai`=0, `uang_muka`=0, `id_kas_bank`=NULL WHERE `id_pembelian`=4"),
(549,4,"yii\\db\\Command::execute","1602865548.9131","GSS Developer","INSERT INTO `akt_jurnal_umum` (`no_jurnal_umum`, `tipe`, `tanggal`, `keterangan`) VALUES (\'JU2010008\', 1, \'2020-10-16\', \'Pembelian : PE2010004\')"),
(550,4,"yii\\db\\Command::execute","1602865548.9232","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=8203700 WHERE `id_akun`=117"),
(551,4,"yii\\db\\Command::execute","1602865548.9243","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (19, 117, 5700, \'Pembelian : PE2010004\')"),
(552,4,"yii\\db\\Command::execute","1602865548.9257","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=9163270 WHERE `id_akun`=64"),
(553,4,"yii\\db\\Command::execute","1602865548.9265","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `kredit`, `keterangan`) VALUES (19, 64, 16270, \'Pembelian : PE2010004\')"),
(554,4,"yii\\db\\Command::execute","1602865548.9277","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=810570 WHERE `id_akun`=53"),
(555,4,"yii\\db\\Command::execute","1602865548.9286","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (19, 53, 570, \'Pembelian : PE2010004\')"),
(556,4,"yii\\db\\Command::execute","1602865548.93","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=145000 WHERE `id_akun`=122"),
(557,4,"yii\\db\\Command::execute","1602865548.9309","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (19, 122, 10000, \'Pembelian : PE2010004\')"),
(558,4,"yii\\db\\Command::execute","1602865548.9325","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (19, 115, 0, \'Pembelian : PE2010004\')"),
(559,4,"yii\\db\\Command::execute","1602865548.9339","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (19, 38, 0, \'Pembelian : PE2010004\')"),
(560,4,"yii\\db\\Command::execute","1602865548.9351","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `keterangan`) VALUES (19, 1, \'Pembelian : PE2010004\')"),
(561,4,"yii\\db\\Command::execute","1602865548.9378","GSS Developer","INSERT INTO `akt_history_transaksi` (`nama_tabel`, `id_tabel`, `id_jurnal_umum`) VALUES (\'akt_pembelian\', 4, 19)"),
(562,4,"yii\\db\\Command::execute","1602865826.7489","GSS Developer","UPDATE `akt_pembelian` SET `ongkir`=0, `diskon`=0, `pajak`=0, `jenis_bayar`=NULL WHERE `id_pembelian`=4"),
(563,4,"yii\\db\\Command::execute","1602865826.8262","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=8198000 WHERE `id_akun`=117"),
(564,4,"yii\\db\\Command::execute","1602865826.828","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=117"),
(565,4,"yii\\db\\Command::execute","1602865826.8301","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=9147000 WHERE `id_akun`=64"),
(566,4,"yii\\db\\Command::execute","1602865826.8319","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=118"),
(567,4,"yii\\db\\Command::execute","1602865826.8337","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=810000 WHERE `id_akun`=53"),
(568,4,"yii\\db\\Command::execute","1602865826.8348","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=119"),
(569,4,"yii\\db\\Command::execute","1602865826.8368","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=135000 WHERE `id_akun`=122"),
(570,4,"yii\\db\\Command::execute","1602865826.8379","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=120"),
(571,4,"yii\\db\\Command::execute","1602865826.8399","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=121"),
(572,4,"yii\\db\\Command::execute","1602865826.8417","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=122"),
(573,4,"yii\\db\\Command::execute","1602865826.8435","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=123"),
(574,4,"yii\\db\\Command::execute","1602865826.8446","GSS Developer","DELETE FROM `akt_jurnal_umum` WHERE `id_jurnal_umum`=19"),
(575,4,"yii\\db\\Command::execute","1602865826.8457","GSS Developer","DELETE FROM `akt_history_transaksi` WHERE `id_history_transaksi`=29"),
(576,4,"yii\\db\\Command::execute","1602865840.5864","GSS Developer","UPDATE `akt_pembelian` SET `id_customer`=2, `id_mata_uang`=1, `ongkir`=10000, `diskon`=0, `pajak`=0, `total`=16000, `jenis_bayar`=1, `materai`=0, `uang_muka`=0, `id_kas_bank`=NULL WHERE `id_pembelian`=4"),
(577,4,"yii\\db\\Command::execute","1602865840.6049","GSS Developer","INSERT INTO `akt_jurnal_umum` (`no_jurnal_umum`, `tipe`, `tanggal`, `keterangan`) VALUES (\'JU2010008\', 1, \'2020-10-16\', \'Pembelian : PE2010004\')"),
(578,4,"yii\\db\\Command::execute","1602865840.6273","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=8204000 WHERE `id_akun`=117"),
(579,4,"yii\\db\\Command::execute","1602865840.6298","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (20, 117, 6000, \'Pembelian : PE2010004\')"),
(580,4,"yii\\db\\Command::execute","1602865840.6324","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=9163000 WHERE `id_akun`=64"),
(581,4,"yii\\db\\Command::execute","1602865840.6337","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `kredit`, `keterangan`) VALUES (20, 64, 16000, \'Pembelian : PE2010004\')"),
(582,4,"yii\\db\\Command::execute","1602865840.6358","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (20, 53, 0, \'Pembelian : PE2010004\')"),
(583,4,"yii\\db\\Command::execute","1602865840.6438","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=145000 WHERE `id_akun`=122"),
(584,4,"yii\\db\\Command::execute","1602865840.6471","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (20, 122, 10000, \'Pembelian : PE2010004\')"),
(585,4,"yii\\db\\Command::execute","1602865840.6511","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (20, 115, 0, \'Pembelian : PE2010004\')"),
(586,4,"yii\\db\\Command::execute","1602865840.6554","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (20, 38, 0, \'Pembelian : PE2010004\')"),
(587,4,"yii\\db\\Command::execute","1602865840.6587","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `keterangan`) VALUES (20, 1, \'Pembelian : PE2010004\')"),
(588,4,"yii\\db\\Command::execute","1602865840.6642","GSS Developer","INSERT INTO `akt_history_transaksi` (`nama_tabel`, `id_tabel`, `id_jurnal_umum`) VALUES (\'akt_pembelian\', 4, 20)"),
(589,4,"yii\\db\\Command::execute","1602865856.2964","GSS Developer","UPDATE `akt_penjualan` SET `jenis_bayar`=NULL WHERE `id_penjualan`=5"),
(590,4,"yii\\db\\Command::execute","1602865856.3068","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=8208000 WHERE `id_akun`=117"),
(591,4,"yii\\db\\Command::execute","1602865856.3079","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=96"),
(592,4,"yii\\db\\Command::execute","1602865856.3091","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=0 WHERE `id_akun`=2"),
(593,4,"yii\\db\\Command::execute","1602865856.3108","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=97"),
(594,4,"yii\\db\\Command::execute","1602865856.3121","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=98"),
(595,4,"yii\\db\\Command::execute","1602865856.3157","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=99"),
(596,4,"yii\\db\\Command::execute","1602865856.3171","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=100"),
(597,4,"yii\\db\\Command::execute","1602865856.3184","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=101"),
(598,4,"yii\\db\\Command::execute","1602865856.3196","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=102"),
(599,4,"yii\\db\\Command::execute","1602865856.3203","GSS Developer","DELETE FROM `akt_jurnal_umum` WHERE `id_jurnal_umum`=16"),
(600,4,"yii\\db\\Command::execute","1602865856.3209","GSS Developer","DELETE FROM `akt_history_transaksi` WHERE `id_history_transaksi`=26"),
(601,4,"yii\\db\\Command::execute","1602865866.8194","GSS Developer","UPDATE `akt_penjualan` SET `id_customer`=3, `id_sales`=1, `id_mata_uang`=1, `tanggal_penjualan`=NULL, `pajak`=0, `uang_muka`=0, `id_kas_bank`=NULL, `diskon`=0, `jenis_bayar`=1 WHERE `id_penjualan`=5"),
(602,4,"yii\\db\\Command::execute","1602865866.8391","GSS Developer","INSERT INTO `akt_jurnal_umum` (`no_jurnal_umum`, `tipe`, `tanggal`, `keterangan`) VALUES (\'JU2010009\', 1, \'2020-10-16\', \'Penjualan : PJ2010001\')"),
(603,4,"yii\\db\\Command::execute","1602865866.8782","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=8204000 WHERE `id_akun`=117"),
(604,4,"yii\\db\\Command::execute","1602865866.8882","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `kredit`, `keterangan`) VALUES (21, 117, 4000, \'Penjualan : PJ2010001\')"),
(605,4,"yii\\db\\Command::execute","1602865866.8987","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=4000 WHERE `id_akun`=2"),
(606,4,"yii\\db\\Command::execute","1602865866.8998","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (21, 2, 4000, \'Penjualan : PJ2010001\')"),
(607,4,"yii\\db\\Command::execute","1602865866.9017","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `kredit`, `keterangan`) VALUES (21, 73, 0, \'Penjualan : PJ2010001\')"),
(608,4,"yii\\db\\Command::execute","1602865866.9033","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `kredit`, `keterangan`) VALUES (21, 47, 0, \'Penjualan : PJ2010001\')"),
(609,4,"yii\\db\\Command::execute","1602865866.9048","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (21, 115, NULL, \'Penjualan : PJ2010001\')"),
(610,4,"yii\\db\\Command::execute","1602865866.9062","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `kredit`, `keterangan`) VALUES (21, 131, 0, \'Penjualan : PJ2010001\')"),
(611,4,"yii\\db\\Command::execute","1602865866.9076","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `keterangan`) VALUES (21, 1, \'Penjualan : PJ2010001\')"),
(612,4,"yii\\db\\Command::execute","1602865866.9105","GSS Developer","INSERT INTO `akt_history_transaksi` (`nama_tabel`, `id_tabel`, `id_jurnal_umum`) VALUES (\'akt_penjualan\', 5, 21)"),
(613,4,"yii\\db\\Command::execute","1602865873.7474","GSS Developer","UPDATE `akt_penjualan` SET `jenis_bayar`=NULL WHERE `id_penjualan`=5"),
(614,4,"yii\\db\\Command::execute","1602865873.7685","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=8208000 WHERE `id_akun`=117"),
(615,4,"yii\\db\\Command::execute","1602865873.7745","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=131"),
(616,4,"yii\\db\\Command::execute","1602865873.7915","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=0 WHERE `id_akun`=2"),
(617,4,"yii\\db\\Command::execute","1602865873.8112","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=132"),
(618,4,"yii\\db\\Command::execute","1602865873.8286","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=133"),
(619,4,"yii\\db\\Command::execute","1602865873.8354","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=134"),
(620,4,"yii\\db\\Command::execute","1602865873.8447","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=135"),
(621,4,"yii\\db\\Command::execute","1602865873.8543","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=136"),
(622,4,"yii\\db\\Command::execute","1602865873.8616","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=137"),
(623,4,"yii\\db\\Command::execute","1602865873.8653","GSS Developer","DELETE FROM `akt_jurnal_umum` WHERE `id_jurnal_umum`=21"),
(624,4,"yii\\db\\Command::execute","1602865873.8664","GSS Developer","DELETE FROM `akt_history_transaksi` WHERE `id_history_transaksi`=31"),
(625,4,"yii\\db\\Command::execute","1602865888.2383","GSS Developer","UPDATE `akt_penjualan` SET `id_customer`=3, `id_sales`=1, `id_mata_uang`=1, `tanggal_penjualan`=\'2020-10-16\', `pajak`=0, `uang_muka`=0, `id_kas_bank`=NULL, `total`=3600, `diskon`=10, `jenis_bayar`=1 WHERE `id_penjualan`=5"),
(626,4,"yii\\db\\Command::execute","1602865888.243","GSS Developer","INSERT INTO `akt_jurnal_umum` (`no_jurnal_umum`, `tipe`, `tanggal`, `keterangan`) VALUES (\'JU2010009\', 1, \'2020-10-16\', \'Penjualan : PJ2010001\')"),
(627,4,"yii\\db\\Command::execute","1602865888.2717","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=8204400 WHERE `id_akun`=117"),
(628,4,"yii\\db\\Command::execute","1602865888.2737","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `kredit`, `keterangan`) VALUES (22, 117, 3600, \'Penjualan : PJ2010001\')"),
(629,4,"yii\\db\\Command::execute","1602865888.2759","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=3600 WHERE `id_akun`=2"),
(630,4,"yii\\db\\Command::execute","1602865888.2772","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (22, 2, 3600, \'Penjualan : PJ2010001\')"),
(631,4,"yii\\db\\Command::execute","1602865888.2805","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `kredit`, `keterangan`) VALUES (22, 73, 0, \'Penjualan : PJ2010001\')"),
(632,4,"yii\\db\\Command::execute","1602865888.2821","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `kredit`, `keterangan`) VALUES (22, 47, 0, \'Penjualan : PJ2010001\')"),
(633,4,"yii\\db\\Command::execute","1602865888.2835","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (22, 115, NULL, \'Penjualan : PJ2010001\')"),
(634,4,"yii\\db\\Command::execute","1602865888.296","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `kredit`, `keterangan`) VALUES (22, 131, 0, \'Penjualan : PJ2010001\')"),
(635,4,"yii\\db\\Command::execute","1602865888.2978","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `keterangan`) VALUES (22, 1, \'Penjualan : PJ2010001\')"),
(636,4,"yii\\db\\Command::execute","1602865888.3025","GSS Developer","INSERT INTO `akt_history_transaksi` (`nama_tabel`, `id_tabel`, `id_jurnal_umum`) VALUES (\'akt_penjualan\', 5, 22)"),
(637,4,"yii\\db\\Command::execute","1602865894.1496","GSS Developer","UPDATE `akt_penjualan` SET `tanggal_penjualan`=NULL, `diskon`=0, `jenis_bayar`=NULL WHERE `id_penjualan`=5"),
(638,4,"yii\\db\\Command::execute","1602865894.1711","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=8208000 WHERE `id_akun`=117"),
(639,4,"yii\\db\\Command::execute","1602865894.1751","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=138"),
(640,4,"yii\\db\\Command::execute","1602865894.1773","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=0 WHERE `id_akun`=2"),
(641,4,"yii\\db\\Command::execute","1602865894.1785","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=139"),
(642,4,"yii\\db\\Command::execute","1602865894.1807","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=140"),
(643,4,"yii\\db\\Command::execute","1602865894.184","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=141"),
(644,4,"yii\\db\\Command::execute","1602865894.187","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=142"),
(645,4,"yii\\db\\Command::execute","1602865894.1889","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=143"),
(646,4,"yii\\db\\Command::execute","1602865894.1928","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=144"),
(647,4,"yii\\db\\Command::execute","1602865894.1946","GSS Developer","DELETE FROM `akt_jurnal_umum` WHERE `id_jurnal_umum`=22"),
(648,4,"yii\\db\\Command::execute","1602865894.1958","GSS Developer","DELETE FROM `akt_history_transaksi` WHERE `id_history_transaksi`=32"),
(649,4,"yii\\db\\Command::execute","1602867679.8063","GSS Developer","UPDATE `akt_pembelian` SET `ongkir`=0, `jenis_bayar`=NULL WHERE `id_pembelian`=4"),
(650,4,"yii\\db\\Command::execute","1602867679.9006","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=8202000 WHERE `id_akun`=117"),
(651,4,"yii\\db\\Command::execute","1602867679.9222","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=124"),
(652,4,"yii\\db\\Command::execute","1602867679.9259","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=9147000 WHERE `id_akun`=64"),
(653,4,"yii\\db\\Command::execute","1602867679.9371","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=125"),
(654,4,"yii\\db\\Command::execute","1602867679.9491","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=126"),
(655,4,"yii\\db\\Command::execute","1602867679.9575","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=135000 WHERE `id_akun`=122"),
(656,4,"yii\\db\\Command::execute","1602867679.9587","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=127"),
(657,4,"yii\\db\\Command::execute","1602867679.9685","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=128"),
(658,4,"yii\\db\\Command::execute","1602867679.976","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=129"),
(659,4,"yii\\db\\Command::execute","1602867679.9826","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=130"),
(660,4,"yii\\db\\Command::execute","1602867679.9885","GSS Developer","DELETE FROM `akt_jurnal_umum` WHERE `id_jurnal_umum`=20"),
(661,4,"yii\\db\\Command::execute","1602867679.9962","GSS Developer","DELETE FROM `akt_history_transaksi` WHERE `id_history_transaksi`=30"),
(662,4,"yii\\db\\Command::execute","1602867699.3548","GSS Developer","UPDATE `akt_pembelian` SET `id_customer`=2, `id_mata_uang`=1, `ongkir`=10, `diskon`=0, `pajak`=0, `total`=6010, `jenis_bayar`=1, `materai`=0, `uang_muka`=0, `id_kas_bank`=NULL WHERE `id_pembelian`=4"),
(663,4,"yii\\db\\Command::execute","1602867699.3744","GSS Developer","INSERT INTO `akt_jurnal_umum` (`no_jurnal_umum`, `tipe`, `tanggal`, `keterangan`) VALUES (\'JU2010006\', 1, \'2020-10-17\', \'Pembelian : PE2010004\')"),
(664,4,"yii\\db\\Command::execute","1602867699.4027","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=8208000 WHERE `id_akun`=117"),
(665,4,"yii\\db\\Command::execute","1602867699.4056","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (23, 117, 6000, \'Pembelian : PE2010004\')"),
(666,4,"yii\\db\\Command::execute","1602867699.4084","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=9153010 WHERE `id_akun`=64"),
(667,4,"yii\\db\\Command::execute","1602867699.4099","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `kredit`, `keterangan`) VALUES (23, 64, 6010, \'Pembelian : PE2010004\')"),
(668,4,"yii\\db\\Command::execute","1602867699.4215","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (23, 53, 0, \'Pembelian : PE2010004\')"),
(669,4,"yii\\db\\Command::execute","1602867699.4297","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=135010 WHERE `id_akun`=122"),
(670,4,"yii\\db\\Command::execute","1602867699.4433","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (23, 122, 10, \'Pembelian : PE2010004\')"),
(671,4,"yii\\db\\Command::execute","1602867699.4585","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (23, 115, 0, \'Pembelian : PE2010004\')"),
(672,4,"yii\\db\\Command::execute","1602867699.4674","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (23, 38, 0, \'Pembelian : PE2010004\')"),
(673,4,"yii\\db\\Command::execute","1602867699.4751","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `keterangan`) VALUES (23, 1, \'Pembelian : PE2010004\')"),
(674,4,"yii\\db\\Command::execute","1602867699.4792","GSS Developer","INSERT INTO `akt_history_transaksi` (`nama_tabel`, `id_tabel`, `id_jurnal_umum`) VALUES (\'akt_pembelian\', 4, 23)"),
(675,4,"yii\\db\\Command::execute","1602867707.0186","GSS Developer","UPDATE `akt_pembelian` SET `ongkir`=0, `jenis_bayar`=NULL WHERE `id_pembelian`=4"),
(676,4,"yii\\db\\Command::execute","1602867707.062","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=8202000 WHERE `id_akun`=117"),
(677,4,"yii\\db\\Command::execute","1602867707.0726","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=145"),
(678,4,"yii\\db\\Command::execute","1602867707.0895","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=9147000 WHERE `id_akun`=64"),
(679,4,"yii\\db\\Command::execute","1602867707.0988","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=146"),
(680,4,"yii\\db\\Command::execute","1602867707.1106","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=147"),
(681,4,"yii\\db\\Command::execute","1602867707.1202","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=135000 WHERE `id_akun`=122"),
(682,4,"yii\\db\\Command::execute","1602867707.1301","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=148"),
(683,4,"yii\\db\\Command::execute","1602867707.1423","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=149"),
(684,4,"yii\\db\\Command::execute","1602867707.1543","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=150"),
(685,4,"yii\\db\\Command::execute","1602867707.1623","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=151"),
(686,4,"yii\\db\\Command::execute","1602867707.1712","GSS Developer","DELETE FROM `akt_jurnal_umum` WHERE `id_jurnal_umum`=23"),
(687,4,"yii\\db\\Command::execute","1602867707.1768","GSS Developer","DELETE FROM `akt_history_transaksi` WHERE `id_history_transaksi`=33"),
(688,4,"yii\\db\\Command::execute","1602867718.3826","GSS Developer","UPDATE `akt_pembelian` SET `id_customer`=2, `id_mata_uang`=1, `ongkir`=0, `diskon`=0, `pajak`=1, `total`=7600, `jenis_bayar`=1, `materai`=1000, `uang_muka`=0, `id_kas_bank`=NULL WHERE `id_pembelian`=4"),
(689,4,"yii\\db\\Command::execute","1602867718.3946","GSS Developer","INSERT INTO `akt_jurnal_umum` (`no_jurnal_umum`, `tipe`, `tanggal`, `keterangan`) VALUES (\'JU2010006\', 1, \'2020-10-17\', \'Pembelian : PE2010004\')"),
(690,4,"yii\\db\\Command::execute","1602867718.4063","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=8208000 WHERE `id_akun`=117"),
(691,4,"yii\\db\\Command::execute","1602867718.4076","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (24, 117, 6000, \'Pembelian : PE2010004\')"),
(692,4,"yii\\db\\Command::execute","1602867718.4091","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=9154600 WHERE `id_akun`=64"),
(693,4,"yii\\db\\Command::execute","1602867718.4101","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `kredit`, `keterangan`) VALUES (24, 64, 7600, \'Pembelian : PE2010004\')"),
(694,4,"yii\\db\\Command::execute","1602867718.4116","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=810600 WHERE `id_akun`=53"),
(695,4,"yii\\db\\Command::execute","1602867718.4125","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (24, 53, 600, \'Pembelian : PE2010004\')"),
(696,4,"yii\\db\\Command::execute","1602867718.4137","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (24, 122, 0, \'Pembelian : PE2010004\')"),
(697,4,"yii\\db\\Command::execute","1602867718.4157","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=1000 WHERE `id_akun`=115"),
(698,4,"yii\\db\\Command::execute","1602867718.4166","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (24, 115, 1000, \'Pembelian : PE2010004\')"),
(699,4,"yii\\db\\Command::execute","1602867718.418","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (24, 38, 0, \'Pembelian : PE2010004\')"),
(700,4,"yii\\db\\Command::execute","1602867718.4194","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `keterangan`) VALUES (24, 1, \'Pembelian : PE2010004\')"),
(701,4,"yii\\db\\Command::execute","1602867718.4224","GSS Developer","INSERT INTO `akt_history_transaksi` (`nama_tabel`, `id_tabel`, `id_jurnal_umum`) VALUES (\'akt_pembelian\', 4, 24)"),
(702,4,"yii\\db\\Command::execute","1602867726.7968","GSS Developer","UPDATE `akt_pembelian` SET `pajak`=0, `jenis_bayar`=NULL, `materai`=0 WHERE `id_pembelian`=4"),
(703,4,"yii\\db\\Command::execute","1602867726.8136","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=8202000 WHERE `id_akun`=117"),
(704,4,"yii\\db\\Command::execute","1602867726.8153","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=152"),
(705,4,"yii\\db\\Command::execute","1602867726.8175","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=9147000 WHERE `id_akun`=64"),
(706,4,"yii\\db\\Command::execute","1602867726.8186","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=153"),
(707,4,"yii\\db\\Command::execute","1602867726.8209","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=810000 WHERE `id_akun`=53"),
(708,4,"yii\\db\\Command::execute","1602867726.8219","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=154"),
(709,4,"yii\\db\\Command::execute","1602867726.8241","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=155"),
(710,4,"yii\\db\\Command::execute","1602867726.8258","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=0 WHERE `id_akun`=115"),
(711,4,"yii\\db\\Command::execute","1602867726.8268","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=156"),
(712,4,"yii\\db\\Command::execute","1602867726.8286","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=157"),
(713,4,"yii\\db\\Command::execute","1602867726.8337","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=158"),
(714,4,"yii\\db\\Command::execute","1602867726.835","GSS Developer","DELETE FROM `akt_jurnal_umum` WHERE `id_jurnal_umum`=24"),
(715,4,"yii\\db\\Command::execute","1602867726.8361","GSS Developer","DELETE FROM `akt_history_transaksi` WHERE `id_history_transaksi`=34"),
(716,4,"yii\\db\\Command::execute","1602867751.574","GSS Developer","UPDATE `pengaturan` SET `status`=1 WHERE `id_pengaturan`=2"),
(717,4,"yii\\db\\Command::execute","1602867770.5159","GSS Developer","UPDATE `akt_penjualan` SET `id_customer`=3, `id_sales`=1, `id_mata_uang`=1, `tanggal_penjualan`=NULL, `ongkir`=0, `pajak`=0, `uang_muka`=0, `id_kas_bank`=NULL, `total`=5000, `diskon`=0, `jenis_bayar`=1, `materai`=1000 WHERE `id_penjualan`=5"),
(718,4,"yii\\db\\Command::execute","1602867770.5241","GSS Developer","INSERT INTO `akt_jurnal_umum` (`no_jurnal_umum`, `tipe`, `tanggal`, `keterangan`) VALUES (\'JU2010006\', 1, \'2020-10-17\', \'Penjualan : PJ2010001\')"),
(719,4,"yii\\db\\Command::execute","1602867770.546","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=8198000 WHERE `id_akun`=117"),
(720,4,"yii\\db\\Command::execute","1602867770.5474","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `kredit`, `keterangan`) VALUES (25, 117, 4000, \'Penjualan : PJ2010001\')"),
(721,4,"yii\\db\\Command::execute","1602867770.5494","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=6000 WHERE `id_akun`=2"),
(722,4,"yii\\db\\Command::execute","1602867770.5505","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (25, 2, 6000, \'Penjualan : PJ2010001\')"),
(723,4,"yii\\db\\Command::execute","1602867770.5526","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `kredit`, `keterangan`) VALUES (25, 73, 0, \'Penjualan : PJ2010001\')"),
(724,4,"yii\\db\\Command::execute","1602867770.5543","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `kredit`, `keterangan`) VALUES (25, 47, 0, \'Penjualan : PJ2010001\')"),
(725,4,"yii\\db\\Command::execute","1602867770.5621","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=1000 WHERE `id_akun`=115"),
(726,4,"yii\\db\\Command::execute","1602867770.5632","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (25, 115, 1000, \'Penjualan : PJ2010001\')"),
(727,4,"yii\\db\\Command::execute","1602867770.5649","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `kredit`, `keterangan`) VALUES (25, 131, 0, \'Penjualan : PJ2010001\')"),
(728,4,"yii\\db\\Command::execute","1602867770.5663","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `keterangan`) VALUES (25, 1, \'Penjualan : PJ2010001\')"),
(729,4,"yii\\db\\Command::execute","1602867770.5693","GSS Developer","INSERT INTO `akt_history_transaksi` (`nama_tabel`, `id_tabel`, `id_jurnal_umum`) VALUES (\'akt_penjualan\', 5, 25)"),
(730,4,"yii\\db\\Command::execute","1602867777.1735","GSS Developer","UPDATE `akt_penjualan` SET `jenis_bayar`=NULL, `materai`=0 WHERE `id_penjualan`=5"),
(731,4,"yii\\db\\Command::execute","1602867777.1913","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=8202000 WHERE `id_akun`=117"),
(732,4,"yii\\db\\Command::execute","1602867777.1968","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=159"),
(733,4,"yii\\db\\Command::execute","1602867777.1988","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=0 WHERE `id_akun`=2"),
(734,4,"yii\\db\\Command::execute","1602867777.2015","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=160"),
(735,4,"yii\\db\\Command::execute","1602867777.2079","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=161"),
(736,4,"yii\\db\\Command::execute","1602867777.2109","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=162"),
(737,4,"yii\\db\\Command::execute","1602867777.2167","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=0 WHERE `id_akun`=115"),
(738,4,"yii\\db\\Command::execute","1602867777.2178","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=163"),
(739,4,"yii\\db\\Command::execute","1602867777.2196","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=164"),
(740,4,"yii\\db\\Command::execute","1602867777.2227","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=165"),
(741,4,"yii\\db\\Command::execute","1602867777.2243","GSS Developer","DELETE FROM `akt_jurnal_umum` WHERE `id_jurnal_umum`=25"),
(742,4,"yii\\db\\Command::execute","1602867777.2285","GSS Developer","DELETE FROM `akt_history_transaksi` WHERE `id_history_transaksi`=35"),
(743,4,"yii\\db\\Command::execute","1602867789.1121","GSS Developer","UPDATE `akt_penjualan` SET `id_customer`=3, `id_sales`=1, `id_mata_uang`=1, `tanggal_penjualan`=NULL, `ongkir`=1000, `pajak`=1, `uang_muka`=0, `id_kas_bank`=NULL, `total`=5400, `diskon`=0, `jenis_bayar`=1, `materai`=0 WHERE `id_penjualan`=5"),
(744,4,"yii\\db\\Command::execute","1602867789.1944","GSS Developer","INSERT INTO `akt_jurnal_umum` (`no_jurnal_umum`, `tipe`, `tanggal`, `keterangan`) VALUES (\'JU2010006\', 1, \'2020-10-17\', \'Penjualan : PJ2010001\')"),
(745,4,"yii\\db\\Command::execute","1602867789.2176","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=8198000 WHERE `id_akun`=117"),
(746,4,"yii\\db\\Command::execute","1602867789.2231","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `kredit`, `keterangan`) VALUES (26, 117, 4000, \'Penjualan : PJ2010001\')"),
(747,4,"yii\\db\\Command::execute","1602867789.2253","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=5400 WHERE `id_akun`=2"),
(748,4,"yii\\db\\Command::execute","1602867789.2262","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (26, 2, 5400, \'Penjualan : PJ2010001\')"),
(749,4,"yii\\db\\Command::execute","1602867789.2277","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=400 WHERE `id_akun`=73"),
(750,4,"yii\\db\\Command::execute","1602867789.2286","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `kredit`, `keterangan`) VALUES (26, 73, 400, \'Penjualan : PJ2010001\')"),
(751,4,"yii\\db\\Command::execute","1602867789.2301","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=1000 WHERE `id_akun`=47"),
(752,4,"yii\\db\\Command::execute","1602867789.231","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `kredit`, `keterangan`) VALUES (26, 47, 1000, \'Penjualan : PJ2010001\')"),
(753,4,"yii\\db\\Command::execute","1602867789.2326","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (26, 115, 0, \'Penjualan : PJ2010001\')"),
(754,4,"yii\\db\\Command::execute","1602867789.2344","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `kredit`, `keterangan`) VALUES (26, 131, 0, \'Penjualan : PJ2010001\')"),
(755,4,"yii\\db\\Command::execute","1602867789.2361","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `keterangan`) VALUES (26, 1, \'Penjualan : PJ2010001\')"),
(756,4,"yii\\db\\Command::execute","1602867789.2394","GSS Developer","INSERT INTO `akt_history_transaksi` (`nama_tabel`, `id_tabel`, `id_jurnal_umum`) VALUES (\'akt_penjualan\', 5, 26)"),
(757,4,"yii\\db\\Command::execute","1602867797.6285","GSS Developer","UPDATE `akt_penjualan` SET `ongkir`=0, `pajak`=0, `jenis_bayar`=NULL WHERE `id_penjualan`=5"),
(758,4,"yii\\db\\Command::execute","1602867797.6398","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=8202000 WHERE `id_akun`=117"),
(759,4,"yii\\db\\Command::execute","1602867797.641","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=166"),
(760,4,"yii\\db\\Command::execute","1602867797.6425","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=0 WHERE `id_akun`=2"),
(761,4,"yii\\db\\Command::execute","1602867797.6433","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=167"),
(762,4,"yii\\db\\Command::execute","1602867797.6446","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=0 WHERE `id_akun`=73"),
(763,4,"yii\\db\\Command::execute","1602867797.6453","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=168"),
(764,4,"yii\\db\\Command::execute","1602867797.6463","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=0 WHERE `id_akun`=47"),
(765,4,"yii\\db\\Command::execute","1602867797.6473","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=169"),
(766,4,"yii\\db\\Command::execute","1602867797.6487","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=170"),
(767,4,"yii\\db\\Command::execute","1602867797.6497","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=171"),
(768,4,"yii\\db\\Command::execute","1602867797.6508","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=172"),
(769,4,"yii\\db\\Command::execute","1602867797.6515","GSS Developer","DELETE FROM `akt_jurnal_umum` WHERE `id_jurnal_umum`=26"),
(770,4,"yii\\db\\Command::execute","1602867797.6519","GSS Developer","DELETE FROM `akt_history_transaksi` WHERE `id_history_transaksi`=36"),
(771,0,"Login","1602872236.3534","User GSS","Login"),
(772,4,"yii\\db\\Command::execute","1602872236.3536","User GSS","INSERT INTO `log` (`level`, `category`, `log_time`, `prefix`, `message`) VALUES (0, \'Login\', 1602872236.3534, \'User GSS\', \'Login\')"),
(773,4,"yii\\db\\Command::execute","1602872319.1351","User GSS","UPDATE `akt_pembelian` SET `id_customer`=2, `id_mata_uang`=1, `ongkir`=20000, `diskon`=0, `pajak`=1, `total`=32600, `jenis_bayar`=1, `materai`=6000, `uang_muka`=0, `id_kas_bank`=NULL WHERE `id_pembelian`=4"),
(774,4,"yii\\db\\Command::execute","1602872319.146","User GSS","INSERT INTO `akt_jurnal_umum` (`no_jurnal_umum`, `tipe`, `tanggal`, `keterangan`) VALUES (\'JU2010006\', 1, \'2020-10-17\', \'Pembelian : PE2010004\')"),
(775,4,"yii\\db\\Command::execute","1602872319.1591","User GSS","UPDATE `akt_akun` SET `saldo_akun`=8208000 WHERE `id_akun`=117"),
(776,4,"yii\\db\\Command::execute","1602872319.1606","User GSS","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (27, 117, 6000, \'Pembelian : PE2010004\')"),
(777,4,"yii\\db\\Command::execute","1602872319.1664","User GSS","UPDATE `akt_akun` SET `saldo_akun`=9179600 WHERE `id_akun`=64"),
(778,4,"yii\\db\\Command::execute","1602872319.1675","User GSS","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `kredit`, `keterangan`) VALUES (27, 64, 32600, \'Pembelian : PE2010004\')"),
(779,4,"yii\\db\\Command::execute","1602872319.169","User GSS","UPDATE `akt_akun` SET `saldo_akun`=810600 WHERE `id_akun`=53"),
(780,4,"yii\\db\\Command::execute","1602872319.1699","User GSS","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (27, 53, 600, \'Pembelian : PE2010004\')"),
(781,4,"yii\\db\\Command::execute","1602872319.1714","User GSS","UPDATE `akt_akun` SET `saldo_akun`=155000 WHERE `id_akun`=122"),
(782,4,"yii\\db\\Command::execute","1602872319.1724","User GSS","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (27, 122, 20000, \'Pembelian : PE2010004\')"),
(783,4,"yii\\db\\Command::execute","1602872319.1754","User GSS","UPDATE `akt_akun` SET `saldo_akun`=6000 WHERE `id_akun`=115"),
(784,4,"yii\\db\\Command::execute","1602872319.1767","User GSS","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (27, 115, 6000, \'Pembelian : PE2010004\')"),
(785,4,"yii\\db\\Command::execute","1602872319.1785","User GSS","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (27, 38, 0, \'Pembelian : PE2010004\')"),
(786,4,"yii\\db\\Command::execute","1602872319.1801","User GSS","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `keterangan`) VALUES (27, 1, \'Pembelian : PE2010004\')"),
(787,4,"yii\\db\\Command::execute","1602872319.1833","User GSS","INSERT INTO `akt_history_transaksi` (`nama_tabel`, `id_tabel`, `id_jurnal_umum`) VALUES (\'akt_pembelian\', 4, 27)"),
(788,4,"yii\\db\\Command::execute","1602872465.8485","User GSS","UPDATE `akt_penjualan` SET `id_customer`=3, `id_sales`=1, `id_mata_uang`=1, `tanggal_penjualan`=\'2020-10-17\', `ongkir`=0, `pajak`=1, `uang_muka`=0, `id_kas_bank`=NULL, `total`=4400, `diskon`=0, `jenis_bayar`=1, `materai`=0 WHERE `id_penjualan`=5"),
(789,4,"yii\\db\\Command::execute","1602872465.855","User GSS","INSERT INTO `akt_jurnal_umum` (`no_jurnal_umum`, `tipe`, `tanggal`, `keterangan`) VALUES (\'JU2010007\', 1, \'2020-10-17\', \'Penjualan : PJ2010001\')"),
(790,4,"yii\\db\\Command::execute","1602872465.8649","User GSS","UPDATE `akt_akun` SET `saldo_akun`=8204000 WHERE `id_akun`=117"),
(791,4,"yii\\db\\Command::execute","1602872465.8658","User GSS","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `kredit`, `keterangan`) VALUES (28, 117, 4000, \'Penjualan : PJ2010001\')"),
(792,4,"yii\\db\\Command::execute","1602872465.8669","User GSS","UPDATE `akt_akun` SET `saldo_akun`=4400 WHERE `id_akun`=2"),
(793,4,"yii\\db\\Command::execute","1602872465.8675","User GSS","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (28, 2, 4400, \'Penjualan : PJ2010001\')"),
(794,4,"yii\\db\\Command::execute","1602872465.87","User GSS","UPDATE `akt_akun` SET `saldo_akun`=400 WHERE `id_akun`=73"),
(795,4,"yii\\db\\Command::execute","1602872465.872","User GSS","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `kredit`, `keterangan`) VALUES (28, 73, 400, \'Penjualan : PJ2010001\')"),
(796,4,"yii\\db\\Command::execute","1602872465.8732","User GSS","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `kredit`, `keterangan`) VALUES (28, 47, 0, \'Penjualan : PJ2010001\')"),
(797,4,"yii\\db\\Command::execute","1602872465.8743","User GSS","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (28, 115, 0, \'Penjualan : PJ2010001\')"),
(798,4,"yii\\db\\Command::execute","1602872465.8753","User GSS","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `kredit`, `keterangan`) VALUES (28, 131, 0, \'Penjualan : PJ2010001\')"),
(799,4,"yii\\db\\Command::execute","1602872465.8764","User GSS","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `keterangan`) VALUES (28, 1, \'Penjualan : PJ2010001\')"),
(800,4,"yii\\db\\Command::execute","1602872465.8784","User GSS","INSERT INTO `akt_history_transaksi` (`nama_tabel`, `id_tabel`, `id_jurnal_umum`) VALUES (\'akt_penjualan\', 5, 28)"),
(801,0,"Login","1602896214.4859","User GSS","Login"),
(802,4,"yii\\db\\Command::execute","1602896214.4861","User GSS","INSERT INTO `log` (`level`, `category`, `log_time`, `prefix`, `message`) VALUES (0, \'Login\', 1602896214.4859, \'User GSS\', \'Login\')"),
(803,4,"yii\\db\\Command::execute","1602896337.2521","User GSS","UPDATE `akt_penjualan` SET `tanggal_penjualan`=NULL, `pajak`=0, `jenis_bayar`=NULL WHERE `id_penjualan`=5"),
(804,4,"yii\\db\\Command::execute","1602896337.2793","User GSS","UPDATE `akt_akun` SET `saldo_akun`=8208000 WHERE `id_akun`=117"),
(805,4,"yii\\db\\Command::execute","1602896337.2808","User GSS","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=180"),
(806,4,"yii\\db\\Command::execute","1602896337.2826","User GSS","UPDATE `akt_akun` SET `saldo_akun`=0 WHERE `id_akun`=2"),
(807,4,"yii\\db\\Command::execute","1602896337.2836","User GSS","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=181"),
(808,4,"yii\\db\\Command::execute","1602896337.2854","User GSS","UPDATE `akt_akun` SET `saldo_akun`=0 WHERE `id_akun`=73"),
(809,4,"yii\\db\\Command::execute","1602896337.2865","User GSS","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=182"),
(810,4,"yii\\db\\Command::execute","1602896337.2883","User GSS","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=183"),
(811,4,"yii\\db\\Command::execute","1602896337.29","User GSS","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=184"),
(812,4,"yii\\db\\Command::execute","1602896337.2918","User GSS","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=185"),
(813,4,"yii\\db\\Command::execute","1602896337.2989","User GSS","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=186"),
(814,4,"yii\\db\\Command::execute","1602896337.3001","User GSS","DELETE FROM `akt_jurnal_umum` WHERE `id_jurnal_umum`=28"),
(815,4,"yii\\db\\Command::execute","1602896337.3012","User GSS","DELETE FROM `akt_history_transaksi` WHERE `id_history_transaksi`=38"),
(816,0,"Login","1602900539.6191","User GSS","Login"),
(817,4,"yii\\db\\Command::execute","1602900539.6192","User GSS","INSERT INTO `log` (`level`, `category`, `log_time`, `prefix`, `message`) VALUES (0, \'Login\', 1602900539.6191, \'User GSS\', \'Login\')"),
(818,4,"yii\\db\\Command::execute","1602900650.8546","User GSS","INSERT INTO `akt_penjualan` (`no_penjualan`, `tanggal_penjualan`, `id_customer`, `id_sales`, `id_mata_uang`, `status`) VALUES (\'PJ2010002\', \'2020-10-17\', 4, 3, 1, 2)"),
(819,4,"yii\\db\\Command::execute","1602900667.8297","User GSS","INSERT INTO `akt_penjualan_detail` (`id_penjualan`, `id_item_stok`, `qty`, `harga`, `diskon`, `total`, `id_item_harga_jual`, `keterangan`) VALUES (6, 1, 1, 40, 0, 40, 1, \'\')"),
(820,4,"yii\\db\\Command::execute","1602900667.8392","User GSS","UPDATE `akt_penjualan` SET `total`=40 WHERE `id_penjualan`=6"),
(821,0,"Login","1602903492.4186","GSS Developer","Login"),
(822,4,"yii\\db\\Command::execute","1602903492.4188","GSS Developer","INSERT INTO `log` (`level`, `category`, `log_time`, `prefix`, `message`) VALUES (0, \'Login\', 1602903492.4186, \'GSS Developer\', \'Login\')"),
(823,4,"yii\\db\\Command::execute","1602903626.2485","User GSS","INSERT INTO `akt_pembelian` (`no_pembelian`, `no_penerimaan`, `tanggal_pembelian`, `id_customer`, `id_mata_uang`, `status`) VALUES (\'PE2010001\', \'PQ2010001\', \'2020-10-17\', 1, 1, 2)"),
(824,4,"yii\\db\\Command::execute","1602903647.9323","User GSS","INSERT INTO `akt_pembelian_detail` (`id_pembelian`, `id_item_stok`, `qty`, `harga`, `diskon`, `total`, `keterangan`) VALUES (1, 1, 12, 2000, 0, 24000, \'\')"),
(825,4,"yii\\db\\Command::execute","1602903883.7095","User GSS","INSERT INTO `akt_penjualan` (`tanggal_penjualan`, `no_penjualan`, `id_customer`, `id_sales`, `id_mata_uang`, `status`) VALUES (\'2020-10-17\', \'PJ2010001\', 3, 3, 1, 2)"),
(826,4,"yii\\db\\Command::execute","1602903900.3092","User GSS","INSERT INTO `akt_penjualan_detail` (`id_penjualan`, `id_item_stok`, `qty`, `harga`, `diskon`, `total`, `id_item_harga_jual`, `keterangan`) VALUES (1, 1, 1, 40, 0, 40, 1, \'\')"),
(827,4,"yii\\db\\Command::execute","1602903900.3439","User GSS","UPDATE `akt_penjualan` SET `total`=40 WHERE `id_penjualan`=1"),
(828,4,"yii\\db\\Command::execute","1602904457.0925","User GSS","INSERT INTO `akt_pembelian` (`no_pembelian`, `no_penerimaan`, `tanggal_pembelian`, `id_customer`, `id_mata_uang`, `status`) VALUES (\'PE2010002\', \'PQ2010002\', \'2020-10-17\', 2, 1, 2)"),
(829,4,"yii\\db\\Command::execute","1602904693.2189","GSS Developer","INSERT INTO `akt_pembelian_detail` (`id_pembelian`, `id_item_stok`, `qty`, `harga`, `diskon`, `total`, `keterangan`) VALUES (2, 1, 10, 10000, 0, 100000, \'\')"),
(830,4,"yii\\db\\Command::execute","1602904768.1037","GSS Developer","UPDATE `akt_approver` SET `id_login`=NULL, `tingkat_approver`=1 WHERE `id_approver`=52"),
(831,4,"yii\\db\\Command::execute","1602904786.295","GSS Developer","INSERT INTO `akt_pembelian` (`no_order_pembelian`, `no_pembelian`, `no_penerimaan`, `tanggal_order_pembelian`, `id_customer`, `id_mata_uang`, `status`) VALUES (\'PO2010001\', \'PE2010001\', \'PQ2010001\', \'2020-10-17\', 1, 1, 1)"),
(832,4,"yii\\db\\Command::execute","1602904800.4733","GSS Developer","UPDATE `akt_approver` SET `id_login`=11, `tingkat_approver`=1 WHERE `id_approver`=52"),
(833,4,"yii\\db\\Command::execute","1602904825.1732","GSS Developer","UPDATE `akt_approver` SET `id_login`=NULL, `tingkat_approver`=1 WHERE `id_approver`=52"),
(834,4,"yii\\db\\Command::execute","1602904836.0642","GSS Developer","INSERT INTO `akt_pembelian_detail` (`id_pembelian`, `id_item_stok`, `qty`, `harga`, `diskon`, `total`, `keterangan`) VALUES (3, 1, 10, 10000, 0, 100000, \'\')"),
(835,4,"yii\\db\\Command::execute","1602904839.8669","GSS Developer","UPDATE `akt_approver` SET `id_login`=11, `tingkat_approver`=1 WHERE `id_approver`=52"),
(836,4,"yii\\db\\Command::execute","1602904866.381","GSS Developer","UPDATE `akt_pembelian` SET `id_customer`=2, `id_mata_uang`=1, `ongkir`=1000, `diskon`=0, `pajak`=0, `total`=101000, `jenis_bayar`=1, `materai`=0, `uang_muka`=0, `id_kas_bank`=NULL WHERE `id_pembelian`=2"),
(837,4,"yii\\db\\Command::execute","1602904866.392","GSS Developer","INSERT INTO `akt_jurnal_umum` (`no_jurnal_umum`, `tipe`, `tanggal`, `keterangan`) VALUES (\'JU2010007\', 1, \'2020-10-17\', \'Pembelian : PE2010002\')"),
(838,4,"yii\\db\\Command::execute","1602904866.421","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=8308000 WHERE `id_akun`=117"),
(839,4,"yii\\db\\Command::execute","1602904866.4226","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (29, 117, 100000, \'Pembelian : PE2010002\')"),
(840,4,"yii\\db\\Command::execute","1602904866.4448","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=9280600 WHERE `id_akun`=64"),
(841,4,"yii\\db\\Command::execute","1602904866.4456","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `kredit`, `keterangan`) VALUES (29, 64, 101000, \'Pembelian : PE2010002\')"),
(842,4,"yii\\db\\Command::execute","1602904866.4467","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (29, 53, 0, \'Pembelian : PE2010002\')"),
(843,4,"yii\\db\\Command::execute","1602904866.4478","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=156000 WHERE `id_akun`=122"),
(844,4,"yii\\db\\Command::execute","1602904866.4486","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (29, 122, 1000, \'Pembelian : PE2010002\')"),
(845,4,"yii\\db\\Command::execute","1602904866.4562","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (29, 115, 0, \'Pembelian : PE2010002\')"),
(846,4,"yii\\db\\Command::execute","1602904866.4583","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (29, 38, 0, \'Pembelian : PE2010002\')"),
(847,4,"yii\\db\\Command::execute","1602904866.4597","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `keterangan`) VALUES (29, 1, \'Pembelian : PE2010002\')"),
(848,4,"yii\\db\\Command::execute","1602904866.4628","GSS Developer","INSERT INTO `akt_history_transaksi` (`nama_tabel`, `id_tabel`, `id_jurnal_umum`) VALUES (\'akt_pembelian\', 2, 29)"),
(849,4,"yii\\db\\Command::execute","1602905524.4365","GSS Developer","UPDATE `akt_approver` SET `id_login`=NULL, `tingkat_approver`=1 WHERE `id_approver`=52"),
(850,4,"yii\\db\\Command::execute","1602905664.6499","GSS Developer","UPDATE `akt_approver` SET `id_login`=11, `tingkat_approver`=1 WHERE `id_approver`=52"),
(851,4,"yii\\db\\Command::execute","1602906021.7063","GSS Developer","UPDATE `akt_approver` SET `id_login`=NULL, `tingkat_approver`=1 WHERE `id_approver`=52"),
(852,4,"yii\\db\\Command::execute","1602906253.3634","GSS Developer","UPDATE `akt_pembelian` SET `id_customer`=1, `id_mata_uang`=1, `ongkir`=0, `diskon`=0, `pajak`=0, `total`=100000, `jenis_bayar`=1, `materai`=0, `uang_muka`=0, `id_kas_bank`=NULL, `tanggal_estimasi`=\'2020-10-17\' WHERE `id_pembelian`=3"),
(853,4,"yii\\db\\Command::execute","1602906265.6542","GSS Developer","UPDATE `akt_approver` SET `id_login`=11, `tingkat_approver`=1 WHERE `id_approver`=52"),
(854,4,"yii\\db\\Command::execute","1602906379.6365","GSS Developer","INSERT INTO `akt_jurnal_umum` (`no_jurnal_umum`, `tipe`, `tanggal`, `keterangan`) VALUES (\'JU2010008\', 1, \'2020-10-17\', \'Order Pembelian : PO2010001\')"),
(855,4,"yii\\db\\Command::execute","1602906379.6528","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=8408000 WHERE `id_akun`=117"),
(856,4,"yii\\db\\Command::execute","1602906379.6542","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (30, 117, 100000, \'Order Pembelian : PO2010001\')"),
(857,4,"yii\\db\\Command::execute","1602906379.656","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=9380600 WHERE `id_akun`=64"),
(858,4,"yii\\db\\Command::execute","1602906379.657","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `kredit`, `keterangan`) VALUES (30, 64, 100000, \'Order Pembelian : PO2010001\')"),
(859,4,"yii\\db\\Command::execute","1602906379.6639","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (30, 53, 0, \'Order Pembelian : PO2010001\')"),
(860,4,"yii\\db\\Command::execute","1602906379.6667","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (30, 122, 0, \'Order Pembelian : PO2010001\')"),
(861,4,"yii\\db\\Command::execute","1602906379.6685","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (30, 115, 0, \'Order Pembelian : PO2010001\')"),
(862,4,"yii\\db\\Command::execute","1602906379.6699","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (30, 38, 0, \'Order Pembelian : PO2010001\')"),
(863,4,"yii\\db\\Command::execute","1602906379.6712","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `keterangan`) VALUES (30, 1, \'Order Pembelian : PO2010001\')"),
(864,4,"yii\\db\\Command::execute","1602906379.672","GSS Developer","UPDATE `akt_pembelian` SET `tanggal_pembelian`=\'2020-10-17\', `tanggal_tempo`=\'1970-01-01\', `status`=2, `tanggal_approve`=\'2020-10-17 10:46:19\', `id_login`=11 WHERE `id_pembelian`=3"),
(865,4,"yii\\db\\Command::execute","1602906379.6744","GSS Developer","INSERT INTO `akt_history_transaksi` (`nama_tabel`, `id_tabel`, `id_jurnal_umum`) VALUES (\'akt_pembelian\', 3, 30)"),
(866,4,"yii\\db\\Command::execute","1602906424.6175","GSS Developer","UPDATE `akt_pembelian` SET `status`=1, `tanggal_approve`=\'2020-10-17 10:47:04\' WHERE `id_pembelian`=3"),
(867,4,"yii\\db\\Command::execute","1602906424.6295","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=8308000 WHERE `id_akun`=117"),
(868,4,"yii\\db\\Command::execute","1602906424.6309","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=194"),
(869,4,"yii\\db\\Command::execute","1602906424.6365","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=9280600 WHERE `id_akun`=64"),
(870,4,"yii\\db\\Command::execute","1602906424.6377","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=195"),
(871,4,"yii\\db\\Command::execute","1602906424.6399","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=196"),
(872,4,"yii\\db\\Command::execute","1602906424.6418","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=197"),
(873,4,"yii\\db\\Command::execute","1602906424.6437","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=198"),
(874,4,"yii\\db\\Command::execute","1602906424.6456","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=199"),
(875,4,"yii\\db\\Command::execute","1602906424.6475","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=200"),
(876,4,"yii\\db\\Command::execute","1602906424.6486","GSS Developer","DELETE FROM `akt_jurnal_umum` WHERE `id_jurnal_umum`=30"),
(877,4,"yii\\db\\Command::execute","1602906424.6501","GSS Developer","DELETE FROM `akt_history_transaksi` WHERE `id_history_transaksi`=2"),
(878,4,"yii\\db\\Command::execute","1602906432.7742","GSS Developer","UPDATE `akt_pembelian` SET `status`=6, `tanggal_approve`=\'2020-10-17 10:47:12\' WHERE `id_pembelian`=3"),
(879,4,"yii\\db\\Command::execute","1602906441.9637","GSS Developer","UPDATE `akt_pembelian` SET `status`=1, `tanggal_approve`=\'2020-10-17 10:47:21\' WHERE `id_pembelian`=3"),
(880,4,"yii\\db\\Command::execute","1602906448.2773","GSS Developer","INSERT INTO `akt_jurnal_umum` (`no_jurnal_umum`, `tipe`, `tanggal`, `keterangan`) VALUES (\'JU2010008\', 1, \'2020-10-17\', \'Order Pembelian : PO2010001\')"),
(881,4,"yii\\db\\Command::execute","1602906448.284","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=8408000 WHERE `id_akun`=117"),
(882,4,"yii\\db\\Command::execute","1602906448.285","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (31, 117, 100000, \'Order Pembelian : PO2010001\')"),
(883,4,"yii\\db\\Command::execute","1602906448.2863","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=9380600 WHERE `id_akun`=64"),
(884,4,"yii\\db\\Command::execute","1602906448.2872","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `kredit`, `keterangan`) VALUES (31, 64, 100000, \'Order Pembelian : PO2010001\')"),
(885,4,"yii\\db\\Command::execute","1602906448.2891","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (31, 53, 0, \'Order Pembelian : PO2010001\')"),
(886,4,"yii\\db\\Command::execute","1602906448.2911","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (31, 122, 0, \'Order Pembelian : PO2010001\')"),
(887,4,"yii\\db\\Command::execute","1602906448.2928","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (31, 115, 0, \'Order Pembelian : PO2010001\')"),
(888,4,"yii\\db\\Command::execute","1602906448.2943","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (31, 38, 0, \'Order Pembelian : PO2010001\')"),
(889,4,"yii\\db\\Command::execute","1602906448.296","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `keterangan`) VALUES (31, 1, \'Order Pembelian : PO2010001\')"),
(890,4,"yii\\db\\Command::execute","1602906448.297","GSS Developer","UPDATE `akt_pembelian` SET `status`=2, `tanggal_approve`=\'2020-10-17 10:47:28\' WHERE `id_pembelian`=3"),
(891,4,"yii\\db\\Command::execute","1602906448.3002","GSS Developer","INSERT INTO `akt_history_transaksi` (`nama_tabel`, `id_tabel`, `id_jurnal_umum`) VALUES (\'akt_pembelian\', 3, 31)"),
(892,4,"yii\\db\\Command::execute","1602906457.902","GSS Developer","UPDATE `akt_approver` SET `id_login`=NULL, `tingkat_approver`=1 WHERE `id_approver`=52"),
(893,4,"yii\\db\\Command::execute","1602906856.2851","GSS Developer","UPDATE `akt_approver` SET `id_login`=11, `tingkat_approver`=1 WHERE `id_approver`=52"),
(894,4,"yii\\db\\Command::execute","1602906879.8019","GSS Developer","UPDATE `akt_pembelian` SET `status`=1, `tanggal_approve`=\'2020-10-17 10:54:39\' WHERE `id_pembelian`=3"),
(895,4,"yii\\db\\Command::execute","1602906879.8181","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=8308000 WHERE `id_akun`=117"),
(896,4,"yii\\db\\Command::execute","1602906879.8194","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=201"),
(897,4,"yii\\db\\Command::execute","1602906879.8208","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=9280600 WHERE `id_akun`=64"),
(898,4,"yii\\db\\Command::execute","1602906879.8216","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=202"),
(899,4,"yii\\db\\Command::execute","1602906879.8231","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=203"),
(900,4,"yii\\db\\Command::execute","1602906879.8245","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=204"),
(901,4,"yii\\db\\Command::execute","1602906879.826","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=205"),
(902,4,"yii\\db\\Command::execute","1602906879.8273","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=206"),
(903,4,"yii\\db\\Command::execute","1602906879.8385","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=207"),
(904,4,"yii\\db\\Command::execute","1602906879.8403","GSS Developer","DELETE FROM `akt_jurnal_umum` WHERE `id_jurnal_umum`=31"),
(905,4,"yii\\db\\Command::execute","1602906879.8436","GSS Developer","DELETE FROM `akt_history_transaksi` WHERE `id_history_transaksi`=3"),
(906,4,"yii\\db\\Command::execute","1602906886.5148","GSS Developer","UPDATE `akt_approver` SET `id_login`=NULL, `tingkat_approver`=1 WHERE `id_approver`=52"),
(907,4,"yii\\db\\Command::execute","1602906899.3971","GSS Developer","DELETE FROM `akt_pembelian_detail` WHERE `id_pembelian_detail`=3"),
(908,4,"yii\\db\\Command::execute","1602906911.4992","GSS Developer","DELETE FROM `akt_pembelian` WHERE `id_pembelian`=3"),
(909,4,"yii\\db\\Command::execute","1602907050.6303","GSS Developer","UPDATE `akt_pembelian` SET `ongkir`=0, `jenis_bayar`=NULL WHERE `id_pembelian`=2"),
(910,4,"yii\\db\\Command::execute","1602907050.6393","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=8208000 WHERE `id_akun`=117"),
(911,4,"yii\\db\\Command::execute","1602907050.6402","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=187"),
(912,4,"yii\\db\\Command::execute","1602907050.6419","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=9179600 WHERE `id_akun`=64"),
(913,4,"yii\\db\\Command::execute","1602907050.6428","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=188"),
(914,4,"yii\\db\\Command::execute","1602907050.6445","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=189"),
(915,4,"yii\\db\\Command::execute","1602907050.646","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=155000 WHERE `id_akun`=122"),
(916,4,"yii\\db\\Command::execute","1602907050.6469","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=190"),
(917,4,"yii\\db\\Command::execute","1602907050.6495","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=191"),
(918,4,"yii\\db\\Command::execute","1602907050.6509","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=192"),
(919,4,"yii\\db\\Command::execute","1602907050.6523","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=193"),
(920,4,"yii\\db\\Command::execute","1602907050.6531","GSS Developer","DELETE FROM `akt_jurnal_umum` WHERE `id_jurnal_umum`=29"),
(921,4,"yii\\db\\Command::execute","1602907050.6541","GSS Developer","DELETE FROM `akt_history_transaksi` WHERE `id_history_transaksi`=1"),
(922,4,"yii\\db\\Command::execute","1602907634.2599","GSS Developer","DELETE FROM `akt_pembelian_detail` WHERE `id_pembelian_detail`=2"),
(923,4,"yii\\db\\Command::execute","1602907642.3206","GSS Developer","DELETE FROM `akt_pembelian` WHERE `id_pembelian`=2"),
(924,4,"yii\\db\\Command::execute","1602907753.6143","GSS Developer","UPDATE `pengaturan` SET `status`=0 WHERE `id_pengaturan`=1"),
(925,4,"yii\\db\\Command::execute","1602907834.2047","GSS Developer","UPDATE `pengaturan` SET `status`=1 WHERE `id_pengaturan`=1"),
(926,4,"yii\\db\\Command::execute","1602909140.3027","GSS Developer","UPDATE `akt_penjualan` SET `id_customer`=3, `id_sales`=3, `id_mata_uang`=1, `ongkir`=0, `pajak`=0, `uang_muka`=0, `id_kas_bank`=NULL, `diskon`=0, `jenis_bayar`=1, `materai`=0, `tanggal_estimasi`=NULL WHERE `id_penjualan`=1"),
(927,4,"yii\\db\\Command::execute","1602909140.3102","GSS Developer","INSERT INTO `akt_jurnal_umum` (`no_jurnal_umum`, `tipe`, `tanggal`, `keterangan`) VALUES (\'JU2010007\', 1, \'2020-10-17\', \'Penjualan : PJ2010001\')"),
(928,4,"yii\\db\\Command::execute","1602909140.3507","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=8207960 WHERE `id_akun`=117"),
(929,4,"yii\\db\\Command::execute","1602909140.352","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `kredit`, `keterangan`) VALUES (32, 117, 40, \'Penjualan : PJ2010001\')"),
(930,4,"yii\\db\\Command::execute","1602909140.3548","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=40 WHERE `id_akun`=2"),
(931,4,"yii\\db\\Command::execute","1602909140.356","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (32, 2, 40, \'Penjualan : PJ2010001\')"),
(932,4,"yii\\db\\Command::execute","1602909140.358","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `kredit`, `keterangan`) VALUES (32, 73, 0, \'Penjualan : PJ2010001\')"),
(933,4,"yii\\db\\Command::execute","1602909140.3827","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `kredit`, `keterangan`) VALUES (32, 47, 0, \'Penjualan : PJ2010001\')"),
(934,4,"yii\\db\\Command::execute","1602909140.3846","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (32, 115, 0, \'Penjualan : PJ2010001\')"),
(935,4,"yii\\db\\Command::execute","1602909140.3864","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `kredit`, `keterangan`) VALUES (32, 131, 0, \'Penjualan : PJ2010001\')"),
(936,4,"yii\\db\\Command::execute","1602909140.3915","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `keterangan`) VALUES (32, 1, \'Penjualan : PJ2010001\')"),
(937,4,"yii\\db\\Command::execute","1602909140.3952","GSS Developer","INSERT INTO `akt_history_transaksi` (`nama_tabel`, `id_tabel`, `id_jurnal_umum`) VALUES (\'akt_penjualan\', 1, 32)"),
(938,4,"yii\\db\\Command::execute","1602909154.7421","GSS Developer","UPDATE `akt_penjualan` SET `tanggal_penjualan`=NULL, `jenis_bayar`=NULL WHERE `id_penjualan`=1"),
(939,4,"yii\\db\\Command::execute","1602909154.7551","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=8208000 WHERE `id_akun`=117"),
(940,4,"yii\\db\\Command::execute","1602909154.7565","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=208"),
(941,4,"yii\\db\\Command::execute","1602909154.7583","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=0 WHERE `id_akun`=2"),
(942,4,"yii\\db\\Command::execute","1602909154.7593","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=209"),
(943,4,"yii\\db\\Command::execute","1602909154.7611","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=210"),
(944,4,"yii\\db\\Command::execute","1602909154.7628","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=211"),
(945,4,"yii\\db\\Command::execute","1602909154.7645","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=212"),
(946,4,"yii\\db\\Command::execute","1602909154.7662","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=213"),
(947,4,"yii\\db\\Command::execute","1602909154.7679","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=214"),
(948,4,"yii\\db\\Command::execute","1602909154.7692","GSS Developer","DELETE FROM `akt_jurnal_umum` WHERE `id_jurnal_umum`=32"),
(949,4,"yii\\db\\Command::execute","1602909154.7702","GSS Developer","DELETE FROM `akt_history_transaksi` WHERE `id_history_transaksi`=4"),
(950,4,"yii\\db\\Command::execute","1602909215.5028","GSS Developer","DELETE FROM `akt_penjualan_detail` WHERE `id_penjualan_detail`=1"),
(951,4,"yii\\db\\Command::execute","1602909215.5168","GSS Developer","UPDATE `akt_penjualan` SET `total`=0 WHERE `id_penjualan`=1"),
(952,4,"yii\\db\\Command::execute","1602909219.4665","GSS Developer","DELETE FROM `akt_penjualan` WHERE `id_penjualan`=1"),
(953,4,"yii\\db\\Command::execute","1602910698.3492","GSS Developer","UPDATE `akt_approver` SET `id_login`=NULL, `tingkat_approver`=1 WHERE `id_approver`=70"),
(954,4,"yii\\db\\Command::execute","1602910727.5281","GSS Developer","INSERT INTO `akt_penjualan` (`tanggal_order_penjualan`, `id_mata_uang`, `no_order_penjualan`, `id_customer`, `id_sales`, `status`) VALUES (\'2020-10-17\', 1, \'OP2010001\', 3, 1, 1)"),
(955,4,"yii\\db\\Command::execute","1602911693.4921","GSS Developer","INSERT INTO `akt_penjualan` (`tanggal_penjualan`, `no_penjualan`, `id_customer`, `id_sales`, `id_mata_uang`, `status`) VALUES (\'2020-10-17\', \'PJ2010001\', 3, 1, 1, 2)"),
(956,4,"yii\\db\\Command::execute","1602912100.1921","GSS Developer","INSERT INTO `akt_penjualan` (`tanggal_order_penjualan`, `id_mata_uang`, `no_order_penjualan`, `id_customer`, `id_sales`, `status`) VALUES (\'2020-10-17\', 1, \'OP2010001\', 3, NULL, 1)"),
(957,4,"yii\\db\\Command::execute","1602912172.7628","GSS Developer","UPDATE `pengaturan` SET `status`=0 WHERE `id_pengaturan`=2"),
(958,4,"yii\\db\\Command::execute","1602912190.3803","GSS Developer","INSERT INTO `akt_penjualan_detail` (`id_penjualan`, `id_item_stok`, `qty`, `harga`, `diskon`, `total`, `id_item_harga_jual`, `keterangan`) VALUES (4, 1, 1, 40, 0, 40, 1, \'qwe\')"),
(959,4,"yii\\db\\Command::execute","1602912190.3915","GSS Developer","UPDATE `akt_penjualan` SET `total`=40 WHERE `id_penjualan`=4"),
(960,4,"yii\\db\\Command::execute","1602912209.182","GSS Developer","DELETE FROM `akt_penjualan_detail` WHERE `id_penjualan_detail`=2"),
(961,4,"yii\\db\\Command::execute","1602912209.1914","GSS Developer","UPDATE `akt_penjualan` SET `total`=0 WHERE `id_penjualan`=4"),
(962,4,"yii\\db\\Command::execute","1602912219.7341","GSS Developer","INSERT INTO `akt_penjualan_detail` (`id_penjualan`, `id_item_stok`, `qty`, `harga`, `diskon`, `total`, `id_item_harga_jual`, `keterangan`) VALUES (4, 1, 1000000000, 40, 0, 40000000000, 1, \'\')"),
(963,4,"yii\\db\\Command::execute","1602912219.7478","GSS Developer","UPDATE `akt_penjualan` SET `total`=40000000000 WHERE `id_penjualan`=4"),
(964,4,"yii\\db\\Command::execute","1602912261.8314","GSS Developer","INSERT INTO `akt_penjualan` (`tanggal_order_penjualan`, `id_mata_uang`, `no_order_penjualan`, `id_customer`, `id_sales`, `status`) VALUES (\'2020-10-17\', 1, \'OP2010002\', 3, 1, 1)"),
(965,4,"yii\\db\\Command::execute","1602912272.3384","GSS Developer","INSERT INTO `akt_penjualan_detail` (`id_penjualan`, `id_item_stok`, `qty`, `harga`, `diskon`, `total`, `id_item_harga_jual`, `keterangan`) VALUES (5, 1, 1000, 40, 0, 40000, 1, \'\')"),
(966,4,"yii\\db\\Command::execute","1602912272.348","GSS Developer","UPDATE `akt_penjualan` SET `total`=40000 WHERE `id_penjualan`=5"),
(967,4,"yii\\db\\Command::execute","1602912276.9198","GSS Developer","DELETE FROM `akt_penjualan_detail` WHERE `id_penjualan_detail`=4"),
(968,4,"yii\\db\\Command::execute","1602912276.9283","GSS Developer","UPDATE `akt_penjualan` SET `total`=0 WHERE `id_penjualan`=5"),
(969,4,"yii\\db\\Command::execute","1602912490.2337","GSS Developer","DELETE FROM `akt_penjualan` WHERE `id_penjualan`=2"),
(970,4,"yii\\db\\Command::execute","1602912503.9054","GSS Developer","UPDATE `akt_penjualan` SET `id_customer`=3, `id_sales`=NULL, `id_mata_uang`=1, `ongkir`=0, `pajak`=0, `uang_muka`=0, `id_kas_bank`=NULL, `diskon`=0, `jenis_bayar`=1, `materai`=0, `tanggal_estimasi`=\'2020-10-17\' WHERE `id_penjualan`=4"),
(971,4,"yii\\db\\Command::execute","1602912522.1221","GSS Developer","UPDATE `akt_approver` SET `id_login`=11, `tingkat_approver`=1 WHERE `id_approver`=70"),
(972,4,"yii\\db\\Command::execute","1602912530.7767","GSS Developer","UPDATE `akt_penjualan` SET `the_approver`=11, `the_approver_date`=\'2020-10-17 12:28:50\', `no_penjualan`=\'PJ2010002\', `tanggal_penjualan`=\'2020-10-17\', `status`=2 WHERE `id_penjualan`=4"),
(973,4,"yii\\db\\Command::execute","1602912530.7813","GSS Developer","INSERT INTO `akt_jurnal_umum` (`no_jurnal_umum`, `tipe`, `tanggal`, `keterangan`) VALUES (\'JU2010007\', 1, \'2020-10-17\', \'Order Penjualan : OP2010001\')"),
(974,4,"yii\\db\\Command::execute","1602912530.7939","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=-39991792000 WHERE `id_akun`=117"),
(975,4,"yii\\db\\Command::execute","1602912530.7965","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `kredit`, `keterangan`) VALUES (33, 117, 40000000000, \'Order Penjualan : OP2010001\')"),
(976,4,"yii\\db\\Command::execute","1602912530.7981","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=40000000000 WHERE `id_akun`=2"),
(977,4,"yii\\db\\Command::execute","1602912530.799","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (33, 2, 40000000000, \'Order Penjualan : OP2010001\')"),
(978,4,"yii\\db\\Command::execute","1602912530.8005","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `kredit`, `keterangan`) VALUES (33, 73, 0, \'Order Penjualan : OP2010001\')"),
(979,4,"yii\\db\\Command::execute","1602912530.8021","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `kredit`, `keterangan`) VALUES (33, 47, 0, \'Order Penjualan : OP2010001\')"),
(980,4,"yii\\db\\Command::execute","1602912530.8036","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (33, 115, 0, \'Order Penjualan : OP2010001\')"),
(981,4,"yii\\db\\Command::execute","1602912530.8081","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `kredit`, `keterangan`) VALUES (33, 131, 0, \'Order Penjualan : OP2010001\')"),
(982,4,"yii\\db\\Command::execute","1602912530.8095","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `keterangan`) VALUES (33, 1, \'Order Penjualan : OP2010001\')"),
(983,4,"yii\\db\\Command::execute","1602912530.8118","GSS Developer","INSERT INTO `akt_history_transaksi` (`nama_tabel`, `id_tabel`, `id_jurnal_umum`) VALUES (\'akt_penjualan\', 4, 33)"),
(984,4,"yii\\db\\Command::execute","1602912610.4609","GSS Developer","UPDATE `akt_approver` SET `id_login`=NULL, `tingkat_approver`=1 WHERE `id_approver`=70"),
(985,4,"yii\\db\\Command::execute","1602912623.8795","GSS Developer","INSERT INTO `akt_penjualan_detail` (`id_penjualan`, `id_item_stok`, `qty`, `harga`, `diskon`, `total`, `id_item_harga_jual`, `keterangan`) VALUES (5, 1, 10, 40, 0, 400, 1, \'\')"),
(986,4,"yii\\db\\Command::execute","1602912623.8883","GSS Developer","UPDATE `akt_penjualan` SET `total`=400 WHERE `id_penjualan`=5"),
(987,4,"yii\\db\\Command::execute","1602912631.6453","GSS Developer","UPDATE `akt_penjualan` SET `id_customer`=3, `id_sales`=1, `id_mata_uang`=1, `ongkir`=0, `pajak`=0, `uang_muka`=0, `id_kas_bank`=NULL, `diskon`=0, `jenis_bayar`=1, `materai`=0, `tanggal_estimasi`=\'2020-10-28\' WHERE `id_penjualan`=5"),
(988,4,"yii\\db\\Command::execute","1602912639.6227","GSS Developer","UPDATE `akt_approver` SET `id_login`=11, `tingkat_approver`=1 WHERE `id_approver`=70"),
(989,4,"yii\\db\\Command::execute","1602912644.7381","GSS Developer","UPDATE `akt_penjualan` SET `the_approver`=11, `the_approver_date`=\'2020-10-17 12:30:44\', `no_penjualan`=\'PJ2010003\', `tanggal_penjualan`=\'2020-10-17\', `status`=2 WHERE `id_penjualan`=5"),
(990,4,"yii\\db\\Command::execute","1602912644.7498","GSS Developer","INSERT INTO `akt_jurnal_umum` (`no_jurnal_umum`, `tipe`, `tanggal`, `keterangan`) VALUES (\'JU2010008\', 1, \'2020-10-17\', \'Order Penjualan : OP2010002\')"),
(991,4,"yii\\db\\Command::execute","1602912644.7631","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=-2147484048 WHERE `id_akun`=117"),
(992,4,"yii\\db\\Command::execute","1602912644.7637","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `kredit`, `keterangan`) VALUES (34, 117, 400, \'Order Penjualan : OP2010002\')"),
(993,4,"yii\\db\\Command::execute","1602912644.7659","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=2147484047 WHERE `id_akun`=2"),
(994,4,"yii\\db\\Command::execute","1602912644.7663","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (34, 2, 400, \'Order Penjualan : OP2010002\')"),
(995,4,"yii\\db\\Command::execute","1602912644.7679","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `kredit`, `keterangan`) VALUES (34, 73, 0, \'Order Penjualan : OP2010002\')"),
(996,4,"yii\\db\\Command::execute","1602912644.7693","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `kredit`, `keterangan`) VALUES (34, 47, 0, \'Order Penjualan : OP2010002\')"),
(997,4,"yii\\db\\Command::execute","1602912644.7717","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (34, 115, 0, \'Order Penjualan : OP2010002\')"),
(998,4,"yii\\db\\Command::execute","1602912644.7744","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `kredit`, `keterangan`) VALUES (34, 131, 0, \'Order Penjualan : OP2010002\')"),
(999,4,"yii\\db\\Command::execute","1602912644.7762","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `keterangan`) VALUES (34, 1, \'Order Penjualan : OP2010002\')"),
(1000,4,"yii\\db\\Command::execute","1602912644.7804","GSS Developer","INSERT INTO `akt_history_transaksi` (`nama_tabel`, `id_tabel`, `id_jurnal_umum`) VALUES (\'akt_penjualan\', 5, 34)");
INSERT INTO `log` VALUES (1001,0,"Login","1602916639.08","User GSS","Login"),
(1002,4,"yii\\db\\Command::execute","1602916639.0801","User GSS","INSERT INTO `log` (`level`, `category`, `log_time`, `prefix`, `message`) VALUES (0, \'Login\', 1602916639.08, \'User GSS\', \'Login\')"),
(1003,0,"Login","1602918711.4979","GSS Developer","Login"),
(1004,4,"yii\\db\\Command::execute","1602918711.4981","GSS Developer","INSERT INTO `log` (`level`, `category`, `log_time`, `prefix`, `message`) VALUES (0, \'Login\', 1602918711.4979, \'GSS Developer\', \'Login\')"),
(1005,0,"Login","1602918948.0925","GSS Developer","Login"),
(1006,4,"yii\\db\\Command::execute","1602918948.0927","GSS Developer","INSERT INTO `log` (`level`, `category`, `log_time`, `prefix`, `message`) VALUES (0, \'Login\', 1602918948.0925, \'GSS Developer\', \'Login\')"),
(1007,0,"Login","1602920854.7258","GSS Developer","Login"),
(1008,4,"yii\\db\\Command::execute","1602920854.7259","GSS Developer","INSERT INTO `log` (`level`, `category`, `log_time`, `prefix`, `message`) VALUES (0, \'Login\', 1602920854.7258, \'GSS Developer\', \'Login\')"),
(1009,0,"Login","1603074113.1102","GSS Developer","Login"),
(1010,4,"yii\\db\\Command::execute","1603074113.1104","GSS Developer","INSERT INTO `log` (`level`, `category`, `log_time`, `prefix`, `message`) VALUES (0, \'Login\', 1603074113.1102, \'GSS Developer\', \'Login\')"),
(1011,4,"yii\\db\\Command::execute","1603074150.943","GSS Developer","UPDATE `akt_approver` SET `id_login`=NULL, `tingkat_approver`=1 WHERE `id_approver`=70"),
(1012,4,"yii\\db\\Command::execute","1603074157.6913","GSS Developer","INSERT INTO `akt_penjualan` (`tanggal_order_penjualan`, `id_mata_uang`, `no_order_penjualan`, `id_customer`, `id_sales`, `status`) VALUES (\'2020-10-19\', 1, \'OP2010003\', 3, 1, 1)"),
(1013,4,"yii\\db\\Command::execute","1603074403.3917","GSS Developer","UPDATE `pengaturan` SET `status`=1 WHERE `id_pengaturan`=2"),
(1014,4,"yii\\db\\Command::execute","1603074411.6448","GSS Developer","INSERT INTO `akt_penjualan` (`tanggal_penjualan`, `no_penjualan`, `id_customer`, `id_sales`, `id_mata_uang`, `status`) VALUES (\'2020-10-19\', \'PJ2010004\', 3, 3, 1, 2)"),
(1015,4,"yii\\db\\Command::execute","1603074589.5899","GSS Developer","UPDATE `akt_penjualan` SET `total`=0 WHERE `id_penjualan`=7"),
(1016,4,"yii\\db\\Command::execute","1603074645.7995","GSS Developer","INSERT INTO `akt_penjualan_detail` (`id_penjualan`, `id_item_stok`, `qty`, `harga`, `diskon`, `total`, `id_item_harga_jual`, `keterangan`) VALUES (7, 1, 11, 40, 0, 440, 1, \'\')"),
(1017,4,"yii\\db\\Command::execute","1603074645.8067","GSS Developer","UPDATE `akt_penjualan` SET `total`=440 WHERE `id_penjualan`=7"),
(1018,4,"yii\\db\\Command::execute","1603074743.2574","GSS Developer","DELETE FROM `akt_penjualan_detail` WHERE `id_penjualan_detail`=6"),
(1019,4,"yii\\db\\Command::execute","1603074743.2687","GSS Developer","UPDATE `akt_penjualan` SET `total`=0 WHERE `id_penjualan`=7"),
(1020,4,"yii\\db\\Command::execute","1603074754.2975","GSS Developer","INSERT INTO `akt_penjualan_detail` (`id_penjualan`, `id_item_stok`, `qty`, `harga`, `diskon`, `total`, `id_item_harga_jual`, `keterangan`) VALUES (7, 1, 11, 40, 10, 396, 1, \'\')"),
(1021,4,"yii\\db\\Command::execute","1603074754.3138","GSS Developer","UPDATE `akt_penjualan` SET `total`=396 WHERE `id_penjualan`=7"),
(1022,4,"yii\\db\\Command::execute","1603074779.0352","GSS Developer","DELETE FROM `akt_penjualan_detail` WHERE `id_penjualan_detail`=7"),
(1023,4,"yii\\db\\Command::execute","1603074779.0541","GSS Developer","UPDATE `akt_penjualan` SET `total`=0 WHERE `id_penjualan`=7"),
(1024,4,"yii\\db\\Command::execute","1603074819.2047","GSS Developer","INSERT INTO `akt_penjualan_detail` (`id_penjualan`, `id_item_stok`, `qty`, `harga`, `diskon`, `total`, `id_item_harga_jual`, `keterangan`) VALUES (7, 1, 10, 40000, 1.3, 394800, 1, \'\')"),
(1025,4,"yii\\db\\Command::execute","1603074819.2162","GSS Developer","UPDATE `akt_penjualan` SET `total`=394800 WHERE `id_penjualan`=7"),
(1026,4,"yii\\db\\Command::execute","1603074829.0842","GSS Developer","DELETE FROM `akt_penjualan_detail` WHERE `id_penjualan_detail`=8"),
(1027,4,"yii\\db\\Command::execute","1603074829.0995","GSS Developer","UPDATE `akt_penjualan` SET `total`=0 WHERE `id_penjualan`=7"),
(1028,4,"yii\\db\\Command::execute","1603074859.3191","GSS Developer","INSERT INTO `akt_penjualan_detail` (`id_penjualan`, `id_item_stok`, `qty`, `harga`, `diskon`, `total`, `id_item_harga_jual`, `keterangan`) VALUES (7, 1, 10, 40, 3.5, 386, 1, \'\')"),
(1029,4,"yii\\db\\Command::execute","1603074859.3406","GSS Developer","UPDATE `akt_penjualan` SET `total`=386 WHERE `id_penjualan`=7"),
(1030,4,"yii\\db\\Command::execute","1603074864.0851","GSS Developer","DELETE FROM `akt_penjualan_detail` WHERE `id_penjualan_detail`=9"),
(1031,4,"yii\\db\\Command::execute","1603074864.0961","GSS Developer","UPDATE `akt_penjualan` SET `total`=0 WHERE `id_penjualan`=7"),
(1032,4,"yii\\db\\Command::execute","1603075327.4735","GSS Developer","INSERT INTO `akt_penjualan_detail` (`id_penjualan`, `id_item_stok`, `qty`, `harga`, `diskon`, `total`, `id_item_harga_jual`, `keterangan`) VALUES (7, 1, 1, 40000, 3.5, 38600, 1, \'\')"),
(1033,4,"yii\\db\\Command::execute","1603075327.4796","GSS Developer","UPDATE `akt_penjualan` SET `total`=38600 WHERE `id_penjualan`=7"),
(1034,4,"yii\\db\\Command::execute","1603075332.7746","GSS Developer","DELETE FROM `akt_penjualan_detail` WHERE `id_penjualan_detail`=10"),
(1035,4,"yii\\db\\Command::execute","1603075332.7927","GSS Developer","UPDATE `akt_penjualan` SET `total`=0 WHERE `id_penjualan`=7"),
(1036,4,"yii\\db\\Command::execute","1603075344.9918","GSS Developer","INSERT INTO `akt_penjualan_detail` (`id_penjualan`, `id_item_stok`, `qty`, `harga`, `diskon`, `total`, `id_item_harga_jual`, `keterangan`) VALUES (7, 1, 10, 400000, 10.5, 3580000, 1, \'\')"),
(1037,4,"yii\\db\\Command::execute","1603075344.998","GSS Developer","UPDATE `akt_penjualan` SET `total`=3580000 WHERE `id_penjualan`=7"),
(1038,4,"yii\\db\\Command::execute","1603075350.8198","GSS Developer","DELETE FROM `akt_penjualan_detail` WHERE `id_penjualan_detail`=11"),
(1039,4,"yii\\db\\Command::execute","1603075350.869","GSS Developer","UPDATE `akt_penjualan` SET `total`=0 WHERE `id_penjualan`=7"),
(1040,4,"yii\\db\\Command::execute","1603075367.2655","GSS Developer","INSERT INTO `akt_penjualan_detail` (`id_penjualan`, `id_item_stok`, `qty`, `harga`, `diskon`, `total`, `id_item_harga_jual`, `keterangan`) VALUES (7, 1, 100, 400000, 80.44, 7824000, 1, \'\')"),
(1041,4,"yii\\db\\Command::execute","1603075367.2759","GSS Developer","UPDATE `akt_penjualan` SET `total`=7824000 WHERE `id_penjualan`=7"),
(1042,0,"Login","1603080897.7478","User GSS","Login"),
(1043,4,"yii\\db\\Command::execute","1603080897.748","User GSS","INSERT INTO `log` (`level`, `category`, `log_time`, `prefix`, `message`) VALUES (0, \'Login\', 1603080897.7478, \'User GSS\', \'Login\')"),
(1044,0,"Login","1603081975.2293","GSS Developer","Login"),
(1045,4,"yii\\db\\Command::execute","1603081975.2295","GSS Developer","INSERT INTO `log` (`level`, `category`, `log_time`, `prefix`, `message`) VALUES (0, \'Login\', 1603081975.2293, \'GSS Developer\', \'Login\')"),
(1046,0,"Login","1603155331.0451","User GSS","Login"),
(1047,4,"yii\\db\\Command::execute","1603155331.0453","User GSS","INSERT INTO `log` (`level`, `category`, `log_time`, `prefix`, `message`) VALUES (0, \'Login\', 1603155331.0451, \'User GSS\', \'Login\')"),
(1048,4,"yii\\db\\Command::execute","1603155393.5947","User GSS","UPDATE `akt_approver` SET `id_login`=17, `tingkat_approver`=1 WHERE `id_approver`=57"),
(1049,4,"yii\\db\\Command::execute","1603155977.9109","User GSS","INSERT INTO `akt_jurnal_umum` (`no_jurnal_umum`, `tanggal`, `tipe`) VALUES (\'JU2010009\', \'2020-10-20\', 1)"),
(1050,4,"yii\\db\\Command::execute","1603156002.8111","User GSS","UPDATE `akt_akun` SET `saldo_akun`=106000 WHERE `id_akun`=115"),
(1051,4,"yii\\db\\Command::execute","1603156002.821","User GSS","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `kredit`, `keterangan`) VALUES (35, 115, 100000, 0, \'beli kalkulator dan bolpoin kantor\')"),
(1052,4,"yii\\db\\Command::execute","1603156131.725","User GSS","INSERT INTO `akt_saldo_awal_kas` (`tanggal_transaksi`, `no_transaksi`, `id_kas_bank`, `jumlah`, `keterangan`) VALUES (\'2020-09-01\', \'SW2010003\', 2, 100000000, \'\')"),
(1053,4,"yii\\db\\Command::execute","1603156131.7288","User GSS","INSERT INTO `akt_jurnal_umum` (`no_jurnal_umum`, `tanggal`, `keterangan`, `tipe`) VALUES (\'JU2010010\', \'2020-10-20\', \'Set saldo awal kas : SW2010003\', 1)"),
(1054,4,"yii\\db\\Command::execute","1603156131.7537","User GSS","UPDATE `akt_kas_bank` SET `saldo`=150000000 WHERE `id_kas_bank`=2"),
(1055,4,"yii\\db\\Command::execute","1603156131.7574","User GSS","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`) VALUES (36, 1, 100000000)"),
(1056,4,"yii\\db\\Command::execute","1603156131.7609","User GSS","INSERT INTO `akt_history_transaksi` (`nama_tabel`, `id_tabel`, `id_jurnal_umum`) VALUES (\'akt_kas_bank\', 2, 230)"),
(1057,4,"yii\\db\\Command::execute","1603156131.7642","User GSS","UPDATE `akt_akun` SET `saldo_akun`=200000000 WHERE `id_akun`=119"),
(1058,4,"yii\\db\\Command::execute","1603156131.7658","User GSS","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `kredit`) VALUES (36, 119, 100000000)"),
(1059,4,"yii\\db\\Command::execute","1603156131.7675","User GSS","INSERT INTO `akt_history_transaksi` (`nama_tabel`, `id_tabel`, `id_jurnal_umum`) VALUES (\'akt_saldo_awal_kas\', 3, 36)"),
(1060,0,"Login","1603156144.6924","User GSS","Login"),
(1061,4,"yii\\db\\Command::execute","1603156144.6926","User GSS","INSERT INTO `log` (`level`, `category`, `log_time`, `prefix`, `message`) VALUES (0, \'Login\', 1603156144.6924, \'User GSS\', \'Login\')"),
(1062,4,"yii\\db\\Command::execute","1603156187.5339","User GSS","INSERT INTO `akt_saldo_awal_kas` (`tanggal_transaksi`, `no_transaksi`, `id_kas_bank`, `jumlah`, `keterangan`) VALUES (\'2020-09-01\', \'SW2010004\', 1, 200000000, \'\')"),
(1063,4,"yii\\db\\Command::execute","1603156187.5423","User GSS","INSERT INTO `akt_jurnal_umum` (`no_jurnal_umum`, `tanggal`, `keterangan`, `tipe`) VALUES (\'JU2010011\', \'2020-10-20\', \'Set saldo awal kas : SW2010004\', 1)"),
(1064,4,"yii\\db\\Command::execute","1603156187.5532","User GSS","UPDATE `akt_kas_bank` SET `saldo`=249998100 WHERE `id_kas_bank`=1"),
(1065,4,"yii\\db\\Command::execute","1603156187.5601","User GSS","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`) VALUES (37, 1, 200000000)"),
(1066,4,"yii\\db\\Command::execute","1603156187.5636","User GSS","INSERT INTO `akt_history_transaksi` (`nama_tabel`, `id_tabel`, `id_jurnal_umum`) VALUES (\'akt_kas_bank\', 1, 232)"),
(1067,4,"yii\\db\\Command::execute","1603156187.5701","User GSS","UPDATE `akt_akun` SET `saldo_akun`=400000000 WHERE `id_akun`=119"),
(1068,4,"yii\\db\\Command::execute","1603156187.5713","User GSS","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `kredit`) VALUES (37, 119, 200000000)"),
(1069,4,"yii\\db\\Command::execute","1603156187.5723","User GSS","INSERT INTO `akt_history_transaksi` (`nama_tabel`, `id_tabel`, `id_jurnal_umum`) VALUES (\'akt_saldo_awal_kas\', 4, 37)"),
(1070,4,"yii\\db\\Command::execute","1603156315.6909","User GSS","INSERT INTO `akt_jurnal_umum` (`no_jurnal_umum`, `tipe`, `tanggal`, `keterangan`) VALUES (\'JU2010012\', 1, \'2020-10-20\', \'Pembelian Harta Tetap : BT2010001\')"),
(1071,4,"yii\\db\\Command::execute","1603156315.7023","User GSS","UPDATE `akt_akun` SET `saldo_akun`=3000000 WHERE `id_akun`=133"),
(1072,4,"yii\\db\\Command::execute","1603156315.7039","User GSS","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (38, 133, 3000000, \'Pembelian Harta Tetap : BT2010001\')"),
(1073,4,"yii\\db\\Command::execute","1603156315.7235","User GSS","UPDATE `akt_akun` SET `saldo_akun`=12599600 WHERE `id_akun`=64"),
(1074,4,"yii\\db\\Command::execute","1603156315.7264","User GSS","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `kredit`, `keterangan`) VALUES (38, 64, 3420000, \'Pembelian Harta Tetap : BT2010001\')"),
(1075,4,"yii\\db\\Command::execute","1603156315.7303","User GSS","UPDATE `akt_akun` SET `saldo_akun`=1110600 WHERE `id_akun`=53"),
(1076,4,"yii\\db\\Command::execute","1603156315.7335","User GSS","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (38, 53, 300000, \'Pembelian Harta Tetap : BT2010001\')"),
(1077,4,"yii\\db\\Command::execute","1603156315.7362","User GSS","UPDATE `akt_akun` SET `saldo_akun`=275000 WHERE `id_akun`=122"),
(1078,4,"yii\\db\\Command::execute","1603156315.7377","User GSS","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (38, 122, 120000, \'Pembelian Harta Tetap : BT2010001\')"),
(1079,4,"yii\\db\\Command::execute","1603156315.7417","User GSS","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (38, 115, 0, \'Pembelian Harta Tetap : BT2010001\')"),
(1080,4,"yii\\db\\Command::execute","1603156315.7455","User GSS","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (38, 38, 0, \'Pembelian Harta Tetap : BT2010001\')"),
(1081,4,"yii\\db\\Command::execute","1603156315.7506","User GSS","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `keterangan`) VALUES (38, 1, \'Pembelian Harta Tetap : BT2010001\')"),
(1082,4,"yii\\db\\Command::execute","1603156315.7537","User GSS","INSERT INTO `akt_history_transaksi` (`nama_tabel`, `id_tabel`, `id_jurnal_umum`) VALUES (\'akt_kas_bank\', NULL, 240)"),
(1083,4,"yii\\db\\Command::execute","1603156315.7571","User GSS","UPDATE `akt_pembelian_harta_tetap` SET `status`=2, `id_login`=17, `tanggal_approve`=\'2020-10-20\' WHERE `id_pembelian_harta_tetap`=1"),
(1084,4,"yii\\db\\Command::execute","1603156315.7612","User GSS","INSERT INTO `akt_history_transaksi` (`nama_tabel`, `id_tabel`, `id_jurnal_umum`) VALUES (\'akt_pembelian_harta_tetap\', 1, 38)"),
(1085,0,"Login","1603166325.1351","GSS Developer","Login"),
(1086,4,"yii\\db\\Command::execute","1603166325.1353","GSS Developer","INSERT INTO `log` (`level`, `category`, `log_time`, `prefix`, `message`) VALUES (0, \'Login\', 1603166325.1351, \'GSS Developer\', \'Login\')"),
(1087,0,"Login","1603166809.048","GSS Developer","Login"),
(1088,4,"yii\\db\\Command::execute","1603166809.0481","GSS Developer","INSERT INTO `log` (`level`, `category`, `log_time`, `prefix`, `message`) VALUES (0, \'Login\', 1603166809.048, \'GSS Developer\', \'Login\')"),
(1089,4,"yii\\db\\Command::execute","1603166832.1691","GSS Developer","UPDATE `akt_pembelian` SET `id_customer`=1, `id_mata_uang`=1, `ongkir`=0, `diskon`=10.5, `pajak`=0, `total`=21480, `jenis_bayar`=1, `materai`=0, `uang_muka`=0, `id_kas_bank`=NULL WHERE `id_pembelian`=1"),
(1090,4,"yii\\db\\Command::execute","1603166832.1851","GSS Developer","INSERT INTO `akt_jurnal_umum` (`no_jurnal_umum`, `tipe`, `tanggal`, `keterangan`) VALUES (\'JU2010013\', 1, \'2020-10-20\', \'Pembelian : PE2010001\')"),
(1091,4,"yii\\db\\Command::execute","1603166832.2035","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=-2147462168 WHERE `id_akun`=117"),
(1092,4,"yii\\db\\Command::execute","1603166832.2058","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (39, 117, 21480, \'Pembelian : PE2010001\')"),
(1093,4,"yii\\db\\Command::execute","1603166832.2099","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=12621080 WHERE `id_akun`=64"),
(1094,4,"yii\\db\\Command::execute","1603166832.2113","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `kredit`, `keterangan`) VALUES (39, 64, 21480, \'Pembelian : PE2010001\')"),
(1095,4,"yii\\db\\Command::execute","1603166832.2133","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (39, 53, 0, \'Pembelian : PE2010001\')"),
(1096,4,"yii\\db\\Command::execute","1603166832.2153","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (39, 122, 0, \'Pembelian : PE2010001\')"),
(1097,4,"yii\\db\\Command::execute","1603166832.2177","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (39, 115, 0, \'Pembelian : PE2010001\')"),
(1098,4,"yii\\db\\Command::execute","1603166832.2195","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (39, 38, 0, \'Pembelian : PE2010001\')"),
(1099,4,"yii\\db\\Command::execute","1603166832.2213","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `keterangan`) VALUES (39, 1, \'Pembelian : PE2010001\')"),
(1100,4,"yii\\db\\Command::execute","1603166832.2289","GSS Developer","INSERT INTO `akt_history_transaksi` (`nama_tabel`, `id_tabel`, `id_jurnal_umum`) VALUES (\'akt_pembelian\', 1, 39)"),
(1101,4,"yii\\db\\Command::execute","1603166848.4071","GSS Developer","UPDATE `akt_pembelian` SET `diskon`=0, `jenis_bayar`=NULL WHERE `id_pembelian`=1"),
(1102,4,"yii\\db\\Command::execute","1603166848.4182","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=-2147483648 WHERE `id_akun`=117"),
(1103,4,"yii\\db\\Command::execute","1603166848.4292","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=241"),
(1104,4,"yii\\db\\Command::execute","1603166848.4311","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=12599600 WHERE `id_akun`=64"),
(1105,4,"yii\\db\\Command::execute","1603166848.4321","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=242"),
(1106,4,"yii\\db\\Command::execute","1603166848.4332","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=243"),
(1107,4,"yii\\db\\Command::execute","1603166848.4345","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=244"),
(1108,4,"yii\\db\\Command::execute","1603166848.441","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=245"),
(1109,4,"yii\\db\\Command::execute","1603166848.4429","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=246"),
(1110,4,"yii\\db\\Command::execute","1603166848.4465","GSS Developer","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=247"),
(1111,4,"yii\\db\\Command::execute","1603166848.4498","GSS Developer","DELETE FROM `akt_jurnal_umum` WHERE `id_jurnal_umum`=39"),
(1112,4,"yii\\db\\Command::execute","1603166848.451","GSS Developer","DELETE FROM `akt_history_transaksi` WHERE `id_history_transaksi`=13"),
(1113,4,"yii\\db\\Command::execute","1603167039.9489","GSS Developer","UPDATE `akt_pembelian` SET `id_customer`=1, `id_mata_uang`=1, `ongkir`=0, `diskon`=10.5, `pajak`=0, `total`=21480, `jenis_bayar`=1, `materai`=0, `uang_muka`=0, `id_kas_bank`=NULL WHERE `id_pembelian`=1"),
(1114,4,"yii\\db\\Command::execute","1603167039.958","GSS Developer","INSERT INTO `akt_jurnal_umum` (`no_jurnal_umum`, `tipe`, `tanggal`, `keterangan`) VALUES (\'JU2010013\', 1, \'2020-10-20\', \'Pembelian : PE2010001\')"),
(1115,4,"yii\\db\\Command::execute","1603167039.9718","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=-2147462168 WHERE `id_akun`=117"),
(1116,4,"yii\\db\\Command::execute","1603167039.9769","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (40, 117, 21480, \'Pembelian : PE2010001\')"),
(1117,4,"yii\\db\\Command::execute","1603167039.9799","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=12621080 WHERE `id_akun`=64"),
(1118,4,"yii\\db\\Command::execute","1603167039.981","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `kredit`, `keterangan`) VALUES (40, 64, 21480, \'Pembelian : PE2010001\')"),
(1119,4,"yii\\db\\Command::execute","1603167039.9825","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (40, 53, 0, \'Pembelian : PE2010001\')"),
(1120,4,"yii\\db\\Command::execute","1603167039.984","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (40, 122, 0, \'Pembelian : PE2010001\')"),
(1121,4,"yii\\db\\Command::execute","1603167039.9859","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (40, 115, 0, \'Pembelian : PE2010001\')"),
(1122,4,"yii\\db\\Command::execute","1603167039.9874","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `debit`, `keterangan`) VALUES (40, 38, 0, \'Pembelian : PE2010001\')"),
(1123,4,"yii\\db\\Command::execute","1603167039.9891","GSS Developer","INSERT INTO `akt_jurnal_umum_detail` (`id_jurnal_umum`, `id_akun`, `keterangan`) VALUES (40, 1, \'Pembelian : PE2010001\')"),
(1124,4,"yii\\db\\Command::execute","1603167039.9924","GSS Developer","INSERT INTO `akt_history_transaksi` (`nama_tabel`, `id_tabel`, `id_jurnal_umum`) VALUES (\'akt_pembelian\', 1, 40)"),
(1125,0,"Login","1603179927.779","User GSS","Login"),
(1126,4,"yii\\db\\Command::execute","1603179927.7792","User GSS","INSERT INTO `log` (`level`, `category`, `log_time`, `prefix`, `message`) VALUES (0, \'Login\', 1603179927.779, \'User GSS\', \'Login\')"),
(1127,4,"yii\\db\\Command::execute","1603180208.7052","User GSS","INSERT INTO `akt_item` (`kode_item`, `barcode_item`, `nama_item`, `nama_alias_item`, `id_tipe_item`, `id_merk`, `id_satuan`, `id_mitra_bisnis`, `keterangan_item`, `status_aktif_item`) VALUES (\'AI002\', \'\', \'MASKER\', \'PENUTUP WAJAH\', 10, 1, 2, 5, \'1 PAK ISI 50 PCS\', 1)"),
(1128,4,"yii\\db\\Command::execute","1603180270.6328","User GSS","INSERT INTO `akt_gudang` (`kode_gudang`, `nama_gudang`, `status_aktif_gudang`) VALUES (\'GD002\', \'MASKER COVID\', 1)"),
(1129,4,"yii\\db\\Command::execute","1603180301.0407","User GSS","INSERT INTO `akt_item_stok` (`id_item`, `qty`, `hpp`, `min`, `id_gudang`, `location`) VALUES (2, 0, 150000, 0, 2, \'JAWA TIMUR\')"),
(1130,4,"yii\\db\\Command::execute","1603180328.1235","User GSS","UPDATE `akt_item_stok` SET `id_item`=2, `id_gudang`=2, `qty`=0, `hpp`=150000, `min`=5 WHERE `id_item_stok`=2"),
(1131,4,"yii\\db\\Command::execute","1603180384.0389","User GSS","INSERT INTO `akt_item_harga_jual` (`id_item`, `harga_satuan`, `id_mata_uang`, `id_level_harga`) VALUES (2, 165000, 1, 2)"),
(1132,4,"yii\\db\\Command::execute","1603180416.5393","User GSS","UPDATE `akt_item` SET `id_tipe_item`=10, `id_merk`=1, `id_satuan`=5, `id_mitra_bisnis`=5, `status_aktif_item`=1 WHERE `id_item`=2"),
(1133,4,"yii\\db\\Command::execute","1603180499.8186","User GSS","INSERT INTO `akt_merk` (`kode_merk`, `nama_merk`) VALUES (\'MI002\', \'JUPITER\')"),
(1134,4,"yii\\db\\Command::execute","1603180672.9777","User GSS","INSERT INTO `akt_mitra_bisnis` (`id_level_harga`, `id_sales`, `kode_mitra_bisnis`, `nama_mitra_bisnis`, `deskripsi_mitra_bisnis`, `tipe_mitra_bisnis`, `status_mitra_bisnis`) VALUES (0, 0, \'MB007\', \'PT. PLASTIK MELAMBUNG\', \'ALAT-ALAT KESEHATAN\', 2, 1)"),
(1135,4,"yii\\db\\Command::execute","1603180788.7755","User GSS","INSERT INTO `akt_item` (`kode_item`, `barcode_item`, `nama_item`, `nama_alias_item`, `id_tipe_item`, `id_merk`, `id_satuan`, `id_mitra_bisnis`, `keterangan_item`, `status_aktif_item`) VALUES (\'AI003\', \'\', \'FACE SHIELD\', \'PELINDUNG WAJAH\', 10, 2, 2, 7, \'BISA DILIPAT\', 1)"),
(1136,4,"yii\\db\\Command::execute","1603180817.3716","User GSS","INSERT INTO `akt_item_stok` (`id_item`, `qty`, `hpp`, `min`, `id_gudang`, `location`) VALUES (3, 0, 15000, 5, 2, \'JAWA TIMUR\')"),
(1137,4,"yii\\db\\Command::execute","1603180841.7348","User GSS","INSERT INTO `akt_item_harga_jual` (`id_item`, `harga_satuan`, `id_mata_uang`, `id_level_harga`) VALUES (3, 17500, 1, 2)"),
(1138,4,"yii\\db\\Command::execute","1603180886.695","User GSS","UPDATE `akt_mitra_bisnis` SET `tipe_mitra_bisnis`=1, `status_mitra_bisnis`=1 WHERE `id_mitra_bisnis`=3"),
(1139,4,"yii\\db\\Command::execute","1603180913.0516","User GSS","UPDATE `akt_mitra_bisnis` SET `tipe_mitra_bisnis`=1, `status_mitra_bisnis`=1 WHERE `id_mitra_bisnis`=4"),
(1140,4,"yii\\db\\Command::execute","1603180931.5026","User GSS","UPDATE `akt_mitra_bisnis` SET `tipe_mitra_bisnis`=1, `status_mitra_bisnis`=1 WHERE `id_mitra_bisnis`=5"),
(1141,0,"Login","1603357230.2851","GSS Developer","Login"),
(1142,4,"yii\\db\\Command::execute","1603357230.2852","GSS Developer","INSERT INTO `log` (`level`, `category`, `log_time`, `prefix`, `message`) VALUES (0, \'Login\', 1603357230.2851, \'GSS Developer\', \'Login\')"),
(1143,0,"Login","1603357258.4041","GSS Developer","Login"),
(1144,4,"yii\\db\\Command::execute","1603357258.4041","GSS Developer","INSERT INTO `log` (`level`, `category`, `log_time`, `prefix`, `message`) VALUES (0, \'Login\', 1603357258.4041, \'GSS Developer\', \'Login\')"),
(1145,0,"Login","1603424798.2446","GSS Developer","Login"),
(1146,4,"yii\\db\\Command::execute","1603424798.2447","GSS Developer","INSERT INTO `log` (`level`, `category`, `log_time`, `prefix`, `message`) VALUES (0, \'Login\', 1603424798.2446, \'GSS Developer\', \'Login\')"),
(1147,0,"Login","1603438937.7979","User GSS","Login"),
(1148,4,"yii\\db\\Command::execute","1603438937.7979","User GSS","INSERT INTO `log` (`level`, `category`, `log_time`, `prefix`, `message`) VALUES (0, \'Login\', 1603438937.7979, \'User GSS\', \'Login\')"),
(1149,4,"yii\\db\\Command::execute","1603438967.5699","User GSS","INSERT INTO `akt_laba_rugi` (`tanggal`, `periode`, `status`, `tanggal_approve`, `id_login`) VALUES (\'2020-10-23\', 1, 1, \'2020-10-23 02:42:47pm\', 17)"),
(1150,4,"yii\\db\\Command::execute","1603438967.5744","User GSS","INSERT INTO `akt_laba_rugi_detail` (`id_laba_rugi`, `id_akun`, `saldo_akun`) VALUES (1, 43, 0)"),
(1151,4,"yii\\db\\Command::execute","1603438967.5758","User GSS","INSERT INTO `akt_laba_rugi_detail` (`id_laba_rugi`, `id_akun`, `saldo_akun`) VALUES (1, 44, 0)"),
(1152,4,"yii\\db\\Command::execute","1603438967.5775","User GSS","INSERT INTO `akt_laba_rugi_detail` (`id_laba_rugi`, `id_akun`, `saldo_akun`) VALUES (1, 82, 0)"),
(1153,4,"yii\\db\\Command::execute","1603438967.5792","User GSS","INSERT INTO `akt_laba_rugi_detail` (`id_laba_rugi`, `id_akun`, `saldo_akun`) VALUES (1, 83, 0)"),
(1154,4,"yii\\db\\Command::execute","1603438967.5816","User GSS","INSERT INTO `akt_laba_rugi_detail` (`id_laba_rugi`, `id_akun`, `saldo_akun`) VALUES (1, 84, 0)"),
(1155,4,"yii\\db\\Command::execute","1603438967.5841","User GSS","INSERT INTO `akt_laba_rugi_detail` (`id_laba_rugi`, `id_akun`, `saldo_akun`) VALUES (1, 85, 0)"),
(1156,4,"yii\\db\\Command::execute","1603438967.5854","User GSS","INSERT INTO `akt_laba_rugi_detail` (`id_laba_rugi`, `id_akun`, `saldo_akun`) VALUES (1, 86, 0)"),
(1157,4,"yii\\db\\Command::execute","1603438967.587","User GSS","INSERT INTO `akt_laba_rugi_detail` (`id_laba_rugi`, `id_akun`, `saldo_akun`) VALUES (1, 87, 0)"),
(1158,4,"yii\\db\\Command::execute","1603438967.5885","User GSS","INSERT INTO `akt_laba_rugi_detail` (`id_laba_rugi`, `id_akun`, `saldo_akun`) VALUES (1, 88, 0)"),
(1159,4,"yii\\db\\Command::execute","1603438967.5898","User GSS","INSERT INTO `akt_laba_rugi_detail` (`id_laba_rugi`, `id_akun`, `saldo_akun`) VALUES (1, 89, 0)"),
(1160,4,"yii\\db\\Command::execute","1603438967.5915","User GSS","INSERT INTO `akt_laba_rugi_detail` (`id_laba_rugi`, `id_akun`, `saldo_akun`) VALUES (1, 90, 0)"),
(1161,4,"yii\\db\\Command::execute","1603438967.5929","User GSS","INSERT INTO `akt_laba_rugi_detail` (`id_laba_rugi`, `id_akun`, `saldo_akun`) VALUES (1, 91, 0)"),
(1162,4,"yii\\db\\Command::execute","1603438967.5944","User GSS","INSERT INTO `akt_laba_rugi_detail` (`id_laba_rugi`, `id_akun`, `saldo_akun`) VALUES (1, 92, 0)"),
(1163,4,"yii\\db\\Command::execute","1603438967.5956","User GSS","INSERT INTO `akt_laba_rugi_detail` (`id_laba_rugi`, `id_akun`, `saldo_akun`) VALUES (1, 93, 0)"),
(1164,4,"yii\\db\\Command::execute","1603438967.5967","User GSS","INSERT INTO `akt_laba_rugi_detail` (`id_laba_rugi`, `id_akun`, `saldo_akun`) VALUES (1, 94, 0)"),
(1165,4,"yii\\db\\Command::execute","1603438967.5981","User GSS","INSERT INTO `akt_laba_rugi_detail` (`id_laba_rugi`, `id_akun`, `saldo_akun`) VALUES (1, 95, 0)"),
(1166,4,"yii\\db\\Command::execute","1603438967.5997","User GSS","INSERT INTO `akt_laba_rugi_detail` (`id_laba_rugi`, `id_akun`, `saldo_akun`) VALUES (1, 96, 0)"),
(1167,4,"yii\\db\\Command::execute","1603438967.6009","User GSS","INSERT INTO `akt_laba_rugi_detail` (`id_laba_rugi`, `id_akun`, `saldo_akun`) VALUES (1, 97, 0)"),
(1168,4,"yii\\db\\Command::execute","1603438967.6022","User GSS","INSERT INTO `akt_laba_rugi_detail` (`id_laba_rugi`, `id_akun`, `saldo_akun`) VALUES (1, 98, 0)"),
(1169,4,"yii\\db\\Command::execute","1603438967.6035","User GSS","INSERT INTO `akt_laba_rugi_detail` (`id_laba_rugi`, `id_akun`, `saldo_akun`) VALUES (1, 99, 0)"),
(1170,4,"yii\\db\\Command::execute","1603438967.6049","User GSS","INSERT INTO `akt_laba_rugi_detail` (`id_laba_rugi`, `id_akun`, `saldo_akun`) VALUES (1, 100, 0)"),
(1171,4,"yii\\db\\Command::execute","1603438967.6061","User GSS","INSERT INTO `akt_laba_rugi_detail` (`id_laba_rugi`, `id_akun`, `saldo_akun`) VALUES (1, 101, 0)"),
(1172,4,"yii\\db\\Command::execute","1603438967.6074","User GSS","INSERT INTO `akt_laba_rugi_detail` (`id_laba_rugi`, `id_akun`, `saldo_akun`) VALUES (1, 102, 0)"),
(1173,4,"yii\\db\\Command::execute","1603438967.6088","User GSS","INSERT INTO `akt_laba_rugi_detail` (`id_laba_rugi`, `id_akun`, `saldo_akun`) VALUES (1, 103, 0)"),
(1174,4,"yii\\db\\Command::execute","1603438967.6102","User GSS","INSERT INTO `akt_laba_rugi_detail` (`id_laba_rugi`, `id_akun`, `saldo_akun`) VALUES (1, 104, 0)"),
(1175,4,"yii\\db\\Command::execute","1603438967.6115","User GSS","INSERT INTO `akt_laba_rugi_detail` (`id_laba_rugi`, `id_akun`, `saldo_akun`) VALUES (1, 105, 0)"),
(1176,4,"yii\\db\\Command::execute","1603438967.6129","User GSS","INSERT INTO `akt_laba_rugi_detail` (`id_laba_rugi`, `id_akun`, `saldo_akun`) VALUES (1, 106, 0)"),
(1177,4,"yii\\db\\Command::execute","1603438967.6145","User GSS","INSERT INTO `akt_laba_rugi_detail` (`id_laba_rugi`, `id_akun`, `saldo_akun`) VALUES (1, 107, 0)"),
(1178,4,"yii\\db\\Command::execute","1603438967.6159","User GSS","INSERT INTO `akt_laba_rugi_detail` (`id_laba_rugi`, `id_akun`, `saldo_akun`) VALUES (1, 108, 0)"),
(1179,4,"yii\\db\\Command::execute","1603438967.6172","User GSS","INSERT INTO `akt_laba_rugi_detail` (`id_laba_rugi`, `id_akun`, `saldo_akun`) VALUES (1, 109, 0)"),
(1180,4,"yii\\db\\Command::execute","1603438967.6185","User GSS","INSERT INTO `akt_laba_rugi_detail` (`id_laba_rugi`, `id_akun`, `saldo_akun`) VALUES (1, 110, 0)"),
(1181,4,"yii\\db\\Command::execute","1603438967.6199","User GSS","INSERT INTO `akt_laba_rugi_detail` (`id_laba_rugi`, `id_akun`, `saldo_akun`) VALUES (1, 111, 0)"),
(1182,4,"yii\\db\\Command::execute","1603438967.6213","User GSS","INSERT INTO `akt_laba_rugi_detail` (`id_laba_rugi`, `id_akun`, `saldo_akun`) VALUES (1, 112, 0)"),
(1183,4,"yii\\db\\Command::execute","1603438967.6226","User GSS","INSERT INTO `akt_laba_rugi_detail` (`id_laba_rugi`, `id_akun`, `saldo_akun`) VALUES (1, 113, 0)"),
(1184,4,"yii\\db\\Command::execute","1603438967.6239","User GSS","INSERT INTO `akt_laba_rugi_detail` (`id_laba_rugi`, `id_akun`, `saldo_akun`) VALUES (1, 115, 106000)"),
(1185,4,"yii\\db\\Command::execute","1603438967.6254","User GSS","INSERT INTO `akt_laba_rugi_detail` (`id_laba_rugi`, `id_akun`, `saldo_akun`) VALUES (1, 116, 0)"),
(1186,4,"yii\\db\\Command::execute","1603438967.6268","User GSS","INSERT INTO `akt_laba_rugi_detail` (`id_laba_rugi`, `id_akun`, `saldo_akun`) VALUES (1, 121, 0)"),
(1187,4,"yii\\db\\Command::execute","1603438967.628","User GSS","INSERT INTO `akt_laba_rugi_detail` (`id_laba_rugi`, `id_akun`, `saldo_akun`) VALUES (1, 123, 0)"),
(1188,4,"yii\\db\\Command::execute","1603438967.6294","User GSS","INSERT INTO `akt_laba_rugi_detail` (`id_laba_rugi`, `id_akun`, `saldo_akun`) VALUES (1, 124, 0)"),
(1189,4,"yii\\db\\Command::execute","1603438967.6316","User GSS","INSERT INTO `akt_laba_rugi_detail` (`id_laba_rugi`, `id_akun`, `saldo_akun`) VALUES (1, 125, 0)"),
(1190,4,"yii\\db\\Command::execute","1603438967.6334","User GSS","INSERT INTO `akt_laba_rugi_detail` (`id_laba_rugi`, `id_akun`, `saldo_akun`) VALUES (1, 129, 0)"),
(1191,4,"yii\\db\\Command::execute","1603438967.6354","User GSS","INSERT INTO `akt_laba_rugi_detail` (`id_laba_rugi`, `id_akun`, `saldo_akun`) VALUES (1, 130, 0)"),
(1192,4,"yii\\db\\Command::execute","1603438967.6371","User GSS","INSERT INTO `akt_laba_rugi_detail` (`id_laba_rugi`, `id_akun`, `saldo_akun`) VALUES (1, 131, 0)"),
(1193,4,"yii\\db\\Command::execute","1603438967.6403","User GSS","INSERT INTO `akt_laporan_ekuitas` (`id_laba_rugi`, `setor_tambahan`, `prive`, `modal`, `laba_bersih`) VALUES (1, 0, 0, 0, -106000)"),
(1194,4,"yii\\db\\Command::execute","1603438967.644","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (1, 1, 0)"),
(1195,4,"yii\\db\\Command::execute","1603438967.6455","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (1, 2, 2147483647)"),
(1196,4,"yii\\db\\Command::execute","1603438967.6469","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (1, 3, 0)"),
(1197,4,"yii\\db\\Command::execute","1603438967.6484","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (1, 5, 0)"),
(1198,4,"yii\\db\\Command::execute","1603438967.65","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (1, 6, 0)"),
(1199,4,"yii\\db\\Command::execute","1603438967.6512","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (1, 7, 0)"),
(1200,4,"yii\\db\\Command::execute","1603438967.6525","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (1, 8, 0)"),
(1201,4,"yii\\db\\Command::execute","1603438967.6539","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (1, 37, 0)"),
(1202,4,"yii\\db\\Command::execute","1603438967.6553","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (1, 38, 1000)"),
(1203,4,"yii\\db\\Command::execute","1603438967.6565","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (1, 39, 0)"),
(1204,4,"yii\\db\\Command::execute","1603438967.6577","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (1, 40, 0)"),
(1205,4,"yii\\db\\Command::execute","1603438967.6589","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (1, 41, 0)"),
(1206,4,"yii\\db\\Command::execute","1603438967.6603","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (1, 42, 0)"),
(1207,4,"yii\\db\\Command::execute","1603438967.6619","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (1, 45, 0)"),
(1208,4,"yii\\db\\Command::execute","1603438967.6634","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (1, 46, 0)"),
(1209,4,"yii\\db\\Command::execute","1603438967.6647","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (1, 47, 0)"),
(1210,4,"yii\\db\\Command::execute","1603438967.6661","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (1, 48, 0)"),
(1211,4,"yii\\db\\Command::execute","1603438967.6674","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (1, 49, 0)"),
(1212,4,"yii\\db\\Command::execute","1603438967.669","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (1, 50, 0)"),
(1213,4,"yii\\db\\Command::execute","1603438967.6703","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (1, 51, 0)"),
(1214,4,"yii\\db\\Command::execute","1603438967.6717","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (1, 53, 1110600)"),
(1215,4,"yii\\db\\Command::execute","1603438967.673","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (1, 54, 0)"),
(1216,4,"yii\\db\\Command::execute","1603438967.6745","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (1, 55, 0)"),
(1217,4,"yii\\db\\Command::execute","1603438967.6758","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (1, 56, 0)"),
(1218,4,"yii\\db\\Command::execute","1603438967.6777","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (1, 57, 0)"),
(1219,4,"yii\\db\\Command::execute","1603438967.6794","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (1, 64, 12621080)"),
(1220,4,"yii\\db\\Command::execute","1603438967.6817","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (1, 65, 0)"),
(1221,4,"yii\\db\\Command::execute","1603438967.683","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (1, 66, 0)"),
(1222,4,"yii\\db\\Command::execute","1603438967.6846","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (1, 67, 0)"),
(1223,4,"yii\\db\\Command::execute","1603438967.686","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (1, 68, 0)"),
(1224,4,"yii\\db\\Command::execute","1603438967.6874","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (1, 69, 0)"),
(1225,4,"yii\\db\\Command::execute","1603438967.6887","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (1, 70, 0)"),
(1226,4,"yii\\db\\Command::execute","1603438967.6902","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (1, 71, 0)"),
(1227,4,"yii\\db\\Command::execute","1603438967.6915","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (1, 72, 0)"),
(1228,4,"yii\\db\\Command::execute","1603438967.6972","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (1, 73, 0)"),
(1229,4,"yii\\db\\Command::execute","1603438967.6989","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (1, 74, 0)"),
(1230,4,"yii\\db\\Command::execute","1603438967.701","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (1, 75, 0)"),
(1231,4,"yii\\db\\Command::execute","1603438967.7026","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (1, 76, 0)"),
(1232,4,"yii\\db\\Command::execute","1603438967.7041","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (1, 77, 0)"),
(1233,4,"yii\\db\\Command::execute","1603438967.7054","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (1, 78, 0)"),
(1234,4,"yii\\db\\Command::execute","1603438967.7068","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (1, 79, 0)"),
(1235,4,"yii\\db\\Command::execute","1603438967.7081","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (1, 80, 0)"),
(1236,4,"yii\\db\\Command::execute","1603438967.7095","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (1, 81, 0)"),
(1237,4,"yii\\db\\Command::execute","1603438967.7109","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (1, 114, 0)"),
(1238,4,"yii\\db\\Command::execute","1603438967.7126","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (1, 117, -2147462168)"),
(1239,4,"yii\\db\\Command::execute","1603438967.7141","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (1, 118, 0)"),
(1240,4,"yii\\db\\Command::execute","1603438967.7154","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (1, 119, 400000000)"),
(1241,4,"yii\\db\\Command::execute","1603438967.7167","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (1, 120, 0)"),
(1242,4,"yii\\db\\Command::execute","1603438967.7183","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (1, 122, 275000)"),
(1243,4,"yii\\db\\Command::execute","1603438967.7196","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (1, 126, 0)"),
(1244,4,"yii\\db\\Command::execute","1603438967.7208","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (1, 127, 0)"),
(1245,4,"yii\\db\\Command::execute","1603438967.7221","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (1, 128, 0)"),
(1246,4,"yii\\db\\Command::execute","1603438967.7236","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (1, 132, 0)"),
(1247,4,"yii\\db\\Command::execute","1603438967.7248","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (1, 133, 3000000)"),
(1248,4,"yii\\db\\Command::execute","1603439020.5502","User GSS","INSERT INTO `akt_laba_rugi` (`tanggal`, `periode`, `status`, `tanggal_approve`, `id_login`) VALUES (\'2020-10-23\', 1, 1, \'2020-10-23 02:43:40pm\', 17)"),
(1249,4,"yii\\db\\Command::execute","1603439020.5586","User GSS","INSERT INTO `akt_laba_rugi_detail` (`id_laba_rugi`, `id_akun`, `saldo_akun`) VALUES (2, 43, 0)"),
(1250,4,"yii\\db\\Command::execute","1603439020.5624","User GSS","INSERT INTO `akt_laba_rugi_detail` (`id_laba_rugi`, `id_akun`, `saldo_akun`) VALUES (2, 44, 0)"),
(1251,4,"yii\\db\\Command::execute","1603439020.5637","User GSS","INSERT INTO `akt_laba_rugi_detail` (`id_laba_rugi`, `id_akun`, `saldo_akun`) VALUES (2, 82, 0)"),
(1252,4,"yii\\db\\Command::execute","1603439020.5649","User GSS","INSERT INTO `akt_laba_rugi_detail` (`id_laba_rugi`, `id_akun`, `saldo_akun`) VALUES (2, 83, 0)"),
(1253,4,"yii\\db\\Command::execute","1603439020.5662","User GSS","INSERT INTO `akt_laba_rugi_detail` (`id_laba_rugi`, `id_akun`, `saldo_akun`) VALUES (2, 84, 0)"),
(1254,4,"yii\\db\\Command::execute","1603439020.5675","User GSS","INSERT INTO `akt_laba_rugi_detail` (`id_laba_rugi`, `id_akun`, `saldo_akun`) VALUES (2, 85, 0)"),
(1255,4,"yii\\db\\Command::execute","1603439020.5689","User GSS","INSERT INTO `akt_laba_rugi_detail` (`id_laba_rugi`, `id_akun`, `saldo_akun`) VALUES (2, 86, 0)"),
(1256,4,"yii\\db\\Command::execute","1603439020.5733","User GSS","INSERT INTO `akt_laba_rugi_detail` (`id_laba_rugi`, `id_akun`, `saldo_akun`) VALUES (2, 87, 0)"),
(1257,4,"yii\\db\\Command::execute","1603439020.5759","User GSS","INSERT INTO `akt_laba_rugi_detail` (`id_laba_rugi`, `id_akun`, `saldo_akun`) VALUES (2, 88, 0)"),
(1258,4,"yii\\db\\Command::execute","1603439020.5772","User GSS","INSERT INTO `akt_laba_rugi_detail` (`id_laba_rugi`, `id_akun`, `saldo_akun`) VALUES (2, 89, 0)"),
(1259,4,"yii\\db\\Command::execute","1603439020.5786","User GSS","INSERT INTO `akt_laba_rugi_detail` (`id_laba_rugi`, `id_akun`, `saldo_akun`) VALUES (2, 90, 0)"),
(1260,4,"yii\\db\\Command::execute","1603439020.5824","User GSS","INSERT INTO `akt_laba_rugi_detail` (`id_laba_rugi`, `id_akun`, `saldo_akun`) VALUES (2, 91, 0)"),
(1261,4,"yii\\db\\Command::execute","1603439020.584","User GSS","INSERT INTO `akt_laba_rugi_detail` (`id_laba_rugi`, `id_akun`, `saldo_akun`) VALUES (2, 92, 0)"),
(1262,4,"yii\\db\\Command::execute","1603439020.5854","User GSS","INSERT INTO `akt_laba_rugi_detail` (`id_laba_rugi`, `id_akun`, `saldo_akun`) VALUES (2, 93, 0)"),
(1263,4,"yii\\db\\Command::execute","1603439020.5868","User GSS","INSERT INTO `akt_laba_rugi_detail` (`id_laba_rugi`, `id_akun`, `saldo_akun`) VALUES (2, 94, 0)"),
(1264,4,"yii\\db\\Command::execute","1603439020.5882","User GSS","INSERT INTO `akt_laba_rugi_detail` (`id_laba_rugi`, `id_akun`, `saldo_akun`) VALUES (2, 95, 0)"),
(1265,4,"yii\\db\\Command::execute","1603439020.5895","User GSS","INSERT INTO `akt_laba_rugi_detail` (`id_laba_rugi`, `id_akun`, `saldo_akun`) VALUES (2, 96, 0)"),
(1266,4,"yii\\db\\Command::execute","1603439020.5908","User GSS","INSERT INTO `akt_laba_rugi_detail` (`id_laba_rugi`, `id_akun`, `saldo_akun`) VALUES (2, 97, 0)"),
(1267,4,"yii\\db\\Command::execute","1603439020.5921","User GSS","INSERT INTO `akt_laba_rugi_detail` (`id_laba_rugi`, `id_akun`, `saldo_akun`) VALUES (2, 98, 0)"),
(1268,4,"yii\\db\\Command::execute","1603439020.5948","User GSS","INSERT INTO `akt_laba_rugi_detail` (`id_laba_rugi`, `id_akun`, `saldo_akun`) VALUES (2, 99, 0)"),
(1269,4,"yii\\db\\Command::execute","1603439020.597","User GSS","INSERT INTO `akt_laba_rugi_detail` (`id_laba_rugi`, `id_akun`, `saldo_akun`) VALUES (2, 100, 0)"),
(1270,4,"yii\\db\\Command::execute","1603439020.5985","User GSS","INSERT INTO `akt_laba_rugi_detail` (`id_laba_rugi`, `id_akun`, `saldo_akun`) VALUES (2, 101, 0)"),
(1271,4,"yii\\db\\Command::execute","1603439020.6034","User GSS","INSERT INTO `akt_laba_rugi_detail` (`id_laba_rugi`, `id_akun`, `saldo_akun`) VALUES (2, 102, 0)"),
(1272,4,"yii\\db\\Command::execute","1603439020.605","User GSS","INSERT INTO `akt_laba_rugi_detail` (`id_laba_rugi`, `id_akun`, `saldo_akun`) VALUES (2, 103, 0)"),
(1273,4,"yii\\db\\Command::execute","1603439020.6076","User GSS","INSERT INTO `akt_laba_rugi_detail` (`id_laba_rugi`, `id_akun`, `saldo_akun`) VALUES (2, 104, 0)"),
(1274,4,"yii\\db\\Command::execute","1603439020.6092","User GSS","INSERT INTO `akt_laba_rugi_detail` (`id_laba_rugi`, `id_akun`, `saldo_akun`) VALUES (2, 105, 0)"),
(1275,4,"yii\\db\\Command::execute","1603439020.6105","User GSS","INSERT INTO `akt_laba_rugi_detail` (`id_laba_rugi`, `id_akun`, `saldo_akun`) VALUES (2, 106, 0)"),
(1276,4,"yii\\db\\Command::execute","1603439020.6119","User GSS","INSERT INTO `akt_laba_rugi_detail` (`id_laba_rugi`, `id_akun`, `saldo_akun`) VALUES (2, 107, 0)"),
(1277,4,"yii\\db\\Command::execute","1603439020.6135","User GSS","INSERT INTO `akt_laba_rugi_detail` (`id_laba_rugi`, `id_akun`, `saldo_akun`) VALUES (2, 108, 0)"),
(1278,4,"yii\\db\\Command::execute","1603439020.6148","User GSS","INSERT INTO `akt_laba_rugi_detail` (`id_laba_rugi`, `id_akun`, `saldo_akun`) VALUES (2, 109, 0)"),
(1279,4,"yii\\db\\Command::execute","1603439020.616","User GSS","INSERT INTO `akt_laba_rugi_detail` (`id_laba_rugi`, `id_akun`, `saldo_akun`) VALUES (2, 110, 0)"),
(1280,4,"yii\\db\\Command::execute","1603439020.6172","User GSS","INSERT INTO `akt_laba_rugi_detail` (`id_laba_rugi`, `id_akun`, `saldo_akun`) VALUES (2, 111, 0)"),
(1281,4,"yii\\db\\Command::execute","1603439020.6189","User GSS","INSERT INTO `akt_laba_rugi_detail` (`id_laba_rugi`, `id_akun`, `saldo_akun`) VALUES (2, 112, 0)"),
(1282,4,"yii\\db\\Command::execute","1603439020.6223","User GSS","INSERT INTO `akt_laba_rugi_detail` (`id_laba_rugi`, `id_akun`, `saldo_akun`) VALUES (2, 113, 0)"),
(1283,4,"yii\\db\\Command::execute","1603439020.6239","User GSS","INSERT INTO `akt_laba_rugi_detail` (`id_laba_rugi`, `id_akun`, `saldo_akun`) VALUES (2, 115, 106000)"),
(1284,4,"yii\\db\\Command::execute","1603439020.6253","User GSS","INSERT INTO `akt_laba_rugi_detail` (`id_laba_rugi`, `id_akun`, `saldo_akun`) VALUES (2, 116, 0)"),
(1285,4,"yii\\db\\Command::execute","1603439020.6269","User GSS","INSERT INTO `akt_laba_rugi_detail` (`id_laba_rugi`, `id_akun`, `saldo_akun`) VALUES (2, 121, 0)"),
(1286,4,"yii\\db\\Command::execute","1603439020.6283","User GSS","INSERT INTO `akt_laba_rugi_detail` (`id_laba_rugi`, `id_akun`, `saldo_akun`) VALUES (2, 123, 0)"),
(1287,4,"yii\\db\\Command::execute","1603439020.63","User GSS","INSERT INTO `akt_laba_rugi_detail` (`id_laba_rugi`, `id_akun`, `saldo_akun`) VALUES (2, 124, 0)"),
(1288,4,"yii\\db\\Command::execute","1603439020.6313","User GSS","INSERT INTO `akt_laba_rugi_detail` (`id_laba_rugi`, `id_akun`, `saldo_akun`) VALUES (2, 125, 0)"),
(1289,4,"yii\\db\\Command::execute","1603439020.633","User GSS","INSERT INTO `akt_laba_rugi_detail` (`id_laba_rugi`, `id_akun`, `saldo_akun`) VALUES (2, 129, 0)"),
(1290,4,"yii\\db\\Command::execute","1603439020.6352","User GSS","INSERT INTO `akt_laba_rugi_detail` (`id_laba_rugi`, `id_akun`, `saldo_akun`) VALUES (2, 130, 0)"),
(1291,4,"yii\\db\\Command::execute","1603439020.6365","User GSS","INSERT INTO `akt_laba_rugi_detail` (`id_laba_rugi`, `id_akun`, `saldo_akun`) VALUES (2, 131, 0)"),
(1292,4,"yii\\db\\Command::execute","1603439020.6401","User GSS","INSERT INTO `akt_laporan_ekuitas` (`id_laba_rugi`, `setor_tambahan`, `prive`, `modal`, `laba_bersih`) VALUES (2, NULL, 0, 0, -106000)"),
(1293,4,"yii\\db\\Command::execute","1603439020.6448","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (2, 1, 0)"),
(1294,4,"yii\\db\\Command::execute","1603439020.6462","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (2, 2, 2147483647)"),
(1295,4,"yii\\db\\Command::execute","1603439020.648","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (2, 3, 0)"),
(1296,4,"yii\\db\\Command::execute","1603439020.6498","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (2, 5, 0)"),
(1297,4,"yii\\db\\Command::execute","1603439020.6511","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (2, 6, 0)"),
(1298,4,"yii\\db\\Command::execute","1603439020.6525","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (2, 7, 0)"),
(1299,4,"yii\\db\\Command::execute","1603439020.6542","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (2, 8, 0)"),
(1300,4,"yii\\db\\Command::execute","1603439020.6555","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (2, 37, 0)"),
(1301,4,"yii\\db\\Command::execute","1603439020.6569","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (2, 38, 1000)"),
(1302,4,"yii\\db\\Command::execute","1603439020.6593","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (2, 39, 0)"),
(1303,4,"yii\\db\\Command::execute","1603439020.6622","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (2, 40, 0)"),
(1304,4,"yii\\db\\Command::execute","1603439020.6637","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (2, 41, 0)"),
(1305,4,"yii\\db\\Command::execute","1603439020.6652","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (2, 42, 0)"),
(1306,4,"yii\\db\\Command::execute","1603439020.667","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (2, 45, 0)"),
(1307,4,"yii\\db\\Command::execute","1603439020.6684","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (2, 46, 0)"),
(1308,4,"yii\\db\\Command::execute","1603439020.6734","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (2, 47, 0)"),
(1309,4,"yii\\db\\Command::execute","1603439020.6748","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (2, 48, 0)"),
(1310,4,"yii\\db\\Command::execute","1603439020.6761","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (2, 49, 0)"),
(1311,4,"yii\\db\\Command::execute","1603439020.6774","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (2, 50, 0)"),
(1312,4,"yii\\db\\Command::execute","1603439020.6788","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (2, 51, 0)"),
(1313,4,"yii\\db\\Command::execute","1603439020.6832","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (2, 53, 1110600)"),
(1314,4,"yii\\db\\Command::execute","1603439020.6847","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (2, 54, 0)"),
(1315,4,"yii\\db\\Command::execute","1603439020.686","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (2, 55, 0)"),
(1316,4,"yii\\db\\Command::execute","1603439020.6874","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (2, 56, 0)"),
(1317,4,"yii\\db\\Command::execute","1603439020.6887","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (2, 57, 0)"),
(1318,4,"yii\\db\\Command::execute","1603439020.6925","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (2, 64, 12621080)"),
(1319,4,"yii\\db\\Command::execute","1603439020.6938","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (2, 65, 0)"),
(1320,4,"yii\\db\\Command::execute","1603439020.6955","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (2, 66, 0)"),
(1321,4,"yii\\db\\Command::execute","1603439020.6967","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (2, 67, 0)"),
(1322,4,"yii\\db\\Command::execute","1603439020.6988","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (2, 68, 0)"),
(1323,4,"yii\\db\\Command::execute","1603439020.7031","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (2, 69, 0)"),
(1324,4,"yii\\db\\Command::execute","1603439020.7043","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (2, 70, 0)"),
(1325,4,"yii\\db\\Command::execute","1603439020.7063","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (2, 71, 0)"),
(1326,4,"yii\\db\\Command::execute","1603439020.7081","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (2, 72, 0)"),
(1327,4,"yii\\db\\Command::execute","1603439020.7096","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (2, 73, 0)"),
(1328,4,"yii\\db\\Command::execute","1603439020.7113","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (2, 74, 0)"),
(1329,4,"yii\\db\\Command::execute","1603439020.7126","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (2, 75, 0)"),
(1330,4,"yii\\db\\Command::execute","1603439020.7143","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (2, 76, 0)"),
(1331,4,"yii\\db\\Command::execute","1603439020.7155","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (2, 77, 0)"),
(1332,4,"yii\\db\\Command::execute","1603439020.7167","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (2, 78, 0)"),
(1333,4,"yii\\db\\Command::execute","1603439020.7181","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (2, 79, 0)"),
(1334,4,"yii\\db\\Command::execute","1603439020.7195","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (2, 80, 0)"),
(1335,4,"yii\\db\\Command::execute","1603439020.7211","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (2, 81, 0)"),
(1336,4,"yii\\db\\Command::execute","1603439020.7225","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (2, 114, 0)"),
(1337,4,"yii\\db\\Command::execute","1603439020.724","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (2, 117, -2147462168)"),
(1338,4,"yii\\db\\Command::execute","1603439020.7254","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (2, 118, 0)"),
(1339,4,"yii\\db\\Command::execute","1603439020.727","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (2, 119, 400000000)"),
(1340,4,"yii\\db\\Command::execute","1603439020.7283","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (2, 120, 0)"),
(1341,4,"yii\\db\\Command::execute","1603439020.73","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (2, 122, 275000)"),
(1342,4,"yii\\db\\Command::execute","1603439020.7313","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (2, 126, 0)"),
(1343,4,"yii\\db\\Command::execute","1603439020.7329","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (2, 127, 0)"),
(1344,4,"yii\\db\\Command::execute","1603439020.7343","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (2, 128, 0)"),
(1345,4,"yii\\db\\Command::execute","1603439020.7358","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (2, 132, 0)"),
(1346,4,"yii\\db\\Command::execute","1603439020.7371","User GSS","INSERT INTO `akt_laporan_posisi_keuangan` (`id_laba_rugi`, `id_akun`, `nominal`) VALUES (2, 133, 3000000)"),
(1347,0,"Login","1603445113.9153","GSS Developer","Login"),
(1348,4,"yii\\db\\Command::execute","1603445113.9154","GSS Developer","INSERT INTO `log` (`level`, `category`, `log_time`, `prefix`, `message`) VALUES (0, \'Login\', 1603445113.9153, \'GSS Developer\', \'Login\')"),
(1349,0,"Login","1603463233.4031","User GSS","Login"),
(1350,4,"yii\\db\\Command::execute","1603463233.4032","User GSS","INSERT INTO `log` (`level`, `category`, `log_time`, `prefix`, `message`) VALUES (0, \'Login\', 1603463233.4031, \'User GSS\', \'Login\')"),
(1351,4,"yii\\db\\Command::execute","1603463459.74","User GSS","UPDATE `akt_pembelian_harta_tetap` SET `status`=1, `tanggal_approve`=\'2020-10-23\' WHERE `id_pembelian_harta_tetap`=1"),
(1352,4,"yii\\db\\Command::execute","1603463459.7464","User GSS","UPDATE `akt_akun` SET `saldo_akun`=0 WHERE `id_akun`=133"),
(1353,4,"yii\\db\\Command::execute","1603463459.7477","User GSS","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=234"),
(1354,4,"yii\\db\\Command::execute","1603463459.7492","User GSS","UPDATE `akt_akun` SET `saldo_akun`=9201080 WHERE `id_akun`=64"),
(1355,4,"yii\\db\\Command::execute","1603463459.7506","User GSS","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=235"),
(1356,4,"yii\\db\\Command::execute","1603463459.755","User GSS","UPDATE `akt_akun` SET `saldo_akun`=810600 WHERE `id_akun`=53"),
(1357,4,"yii\\db\\Command::execute","1603463459.7562","User GSS","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=236"),
(1358,4,"yii\\db\\Command::execute","1603463459.7579","User GSS","UPDATE `akt_akun` SET `saldo_akun`=155000 WHERE `id_akun`=122"),
(1359,4,"yii\\db\\Command::execute","1603463459.7592","User GSS","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=237"),
(1360,4,"yii\\db\\Command::execute","1603463459.7606","User GSS","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=238"),
(1361,4,"yii\\db\\Command::execute","1603463459.7643","User GSS","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=239"),
(1362,4,"yii\\db\\Command::execute","1603463459.7657","User GSS","DELETE FROM `akt_jurnal_umum_detail` WHERE `id_jurnal_umum_detail`=240"),
(1363,4,"yii\\db\\Command::execute","1603463459.767","User GSS","DELETE FROM `akt_jurnal_umum` WHERE `id_jurnal_umum`=38"),
(1364,4,"yii\\db\\Command::execute","1603463459.7694","User GSS","DELETE FROM `akt_history_transaksi` WHERE `id_history_transaksi`=12"),
(1365,4,"yii\\db\\Command::execute","1603463466.1414","User GSS","UPDATE `akt_pembelian_harta_tetap` SET `status`=3 WHERE `id_pembelian_harta_tetap`=1"),
(1366,0,"Login","1603508387.9568","User GSS","Login"),
(1367,4,"yii\\db\\Command::execute","1603508387.9569","User GSS","INSERT INTO `log` (`level`, `category`, `log_time`, `prefix`, `message`) VALUES (0, \'Login\', 1603508387.9568, \'User GSS\', \'Login\')"),
(1368,4,"yii\\db\\Command::execute","1603508414.1946","User GSS","UPDATE `setting` SET `id_kota`=1, `foto`=\'1603508414_maintenance_page-12f699da.jpg\' WHERE `id_setting`=1"),
(1369,0,"Login","1603513700.9709","GSS Developer","Login"),
(1370,4,"yii\\db\\Command::execute","1603513700.971","GSS Developer","INSERT INTO `log` (`level`, `category`, `log_time`, `prefix`, `message`) VALUES (0, \'Login\', 1603513700.9709, \'GSS Developer\', \'Login\')"),
(1371,0,"Login","1603519311.4949","GSS Developer","Login"),
(1372,4,"yii\\db\\Command::execute","1603519311.495","GSS Developer","INSERT INTO `log` (`level`, `category`, `log_time`, `prefix`, `message`) VALUES (0, \'Login\', 1603519311.4949, \'GSS Developer\', \'Login\')"),
(1373,0,"Login","1603528701.4051","GSS Developer","Login"),
(1374,4,"yii\\db\\Command::execute","1603528701.4052","GSS Developer","INSERT INTO `log` (`level`, `category`, `log_time`, `prefix`, `message`) VALUES (0, \'Login\', 1603528701.4051, \'GSS Developer\', \'Login\')"),
(1375,0,"Login","1603531170.9919","GSS Developer","Login"),
(1376,4,"yii\\db\\Command::execute","1603531170.9919","GSS Developer","INSERT INTO `log` (`level`, `category`, `log_time`, `prefix`, `message`) VALUES (0, \'Login\', 1603531170.9919, \'GSS Developer\', \'Login\')"),
(1377,4,"yii\\db\\Command::execute","1603531286.3488","GSS Developer","DELETE FROM `akt_item_tipe` WHERE `id_tipe_item`=18"),
(1378,4,"yii\\db\\Command::execute","1603531289.9045","GSS Developer","DELETE FROM `akt_item_tipe` WHERE `id_tipe_item`=17"),
(1379,4,"yii\\db\\Command::execute","1603531294.6349","GSS Developer","DELETE FROM `akt_item_tipe` WHERE `id_tipe_item`=16"),
(1380,4,"yii\\db\\Command::execute","1603531328.8694","GSS Developer","DELETE FROM `akt_item_tipe` WHERE `id_tipe_item`=15"),
(1381,4,"yii\\db\\Command::execute","1603531389.8994","GSS Developer","DELETE FROM `akt_item_tipe` WHERE `id_tipe_item`=14"),
(1382,4,"yii\\db\\Command::execute","1603531400.0713","GSS Developer","DELETE FROM `akt_item_tipe` WHERE `id_tipe_item`=13"),
(1383,4,"yii\\db\\Command::execute","1603531404.0825","GSS Developer","DELETE FROM `akt_item_tipe` WHERE `id_tipe_item`=12"),
(1384,4,"yii\\db\\Command::execute","1603531408.8438","GSS Developer","DELETE FROM `akt_item_tipe` WHERE `id_tipe_item`=11"),
(1385,0,"Login","1603672843.5738","User GSS","Login"),
(1386,4,"yii\\db\\Command::execute","1603672843.5739","User GSS","INSERT INTO `log` (`level`, `category`, `log_time`, `prefix`, `message`) VALUES (0, \'Login\', 1603672843.5738, \'User GSS\', \'Login\')"),
(1387,0,"Login","1603766938.8602","GSS Developer","Login"),
(1388,4,"yii\\db\\Command::execute","1603766938.8603","GSS Developer","INSERT INTO `log` (`level`, `category`, `log_time`, `prefix`, `message`) VALUES (0, \'Login\', 1603766938.8602, \'GSS Developer\', \'Login\')"),
(1389,0,"Login","1603767706.3296","GSS Developer","Login"),
(1390,4,"yii\\db\\Command::execute","1603767706.3297","GSS Developer","INSERT INTO `log` (`level`, `category`, `log_time`, `prefix`, `message`) VALUES (0, \'Login\', 1603767706.3296, \'GSS Developer\', \'Login\')"),
(1391,4,"yii\\db\\Command::execute","1603769053.6452","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=0, `header`=1, `parent`=1, `jenis`=4, `klasifikasi`=18, `status_aktif`=1, `saldo_normal`=1 WHERE `id_akun`=118"),
(1392,4,"yii\\db\\Command::execute","1603769320.7226","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=0, `header`=1, `parent`=1, `jenis`=8, `klasifikasi`=25, `status_aktif`=1, `saldo_normal`=1 WHERE `id_akun`=102"),
(1393,4,"yii\\db\\Command::execute","1603769344.914","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=0, `header`=1, `parent`=1, `jenis`=8, `klasifikasi`=25, `status_aktif`=1, `saldo_normal`=1 WHERE `id_akun`=99"),
(1394,4,"yii\\db\\Command::execute","1603769863.9863","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=0, `header`=1, `parent`=1, `jenis`=4, `klasifikasi`=13, `status_aktif`=1, `saldo_normal`=2 WHERE `id_akun`=131"),
(1395,4,"yii\\db\\Command::execute","1603771088.1519","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=0, `header`=1, `parent`=1, `jenis`=4, `klasifikasi`=13, `status_aktif`=1, `saldo_normal`=2 WHERE `id_akun`=131"),
(1396,4,"yii\\db\\Command::execute","1603771630.9306","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=0, `header`=1, `parent`=1, `jenis`=8, `klasifikasi`=18, `status_aktif`=1, `saldo_normal`=1 WHERE `id_akun`=114"),
(1397,4,"yii\\db\\Command::execute","1603771763.8006","GSS Developer","INSERT INTO `akt_klasifikasi` (`klasifikasi`) VALUES (\'Hutang Jangka Pendek\')"),
(1398,4,"yii\\db\\Command::execute","1603771776.4241","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=0, `header`=0, `parent`=1, `jenis`=5, `klasifikasi`=28, `status_aktif`=1, `saldo_normal`=2 WHERE `id_akun`=65"),
(1399,4,"yii\\db\\Command::execute","1603772061.6607","GSS Developer","UPDATE `akt_klasifikasi` SET `klasifikasi`=\'Pendapatan Di Terima Di Muka\' WHERE `id_klasifikasi`=15"),
(1400,4,"yii\\db\\Command::execute","1603772071.4924","GSS Developer","UPDATE `akt_akun` SET `saldo_akun`=0, `header`=1, `parent`=1, `jenis`=4, `klasifikasi`=15, `status_aktif`=1, `saldo_normal`=2 WHERE `id_akun`=131");


DROP TABLE IF EXISTS `login`;

CREATE TABLE `login` (
  `id_login` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(21) NOT NULL,
  `password` varchar(32) NOT NULL,
  `nama` varchar(200) NOT NULL,
  `foto` varchar(100) NOT NULL,
  PRIMARY KEY (`id_login`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;

INSERT INTO `login` VALUES (4,"approver1","a8abe17c8a4dc107c42b9ceb7d98907d","Pak Trias","avatar5.png"),
(5,"approver2","83612ac9fbf80ea96b74f970cc873d5c","Pak Taukhid","avatar5.png"),
(6,"approver3","788b953fa8534027fb80d2d796dceec4","Pak Slamet","avatar5.png"),
(11,"admin","1e21d885875ce28ecd17872f40e67e05","GSS Developer","1598935038_GSS.png"),
(17,"usergss","202cb962ac59075b964b07152d234b70","User GSS","1602730271_ben-gAe1pHGc6ms-unsplash.jpg");


DROP TABLE IF EXISTS `menu_navigasi`;

CREATE TABLE `menu_navigasi` (
  `id_menu` int(11) NOT NULL AUTO_INCREMENT,
  `nama_menu` varchar(200) NOT NULL,
  `url` varchar(200) NOT NULL,
  `id_parent` int(11) NOT NULL,
  `no_urut` int(11) NOT NULL,
  `icon` varchar(100) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id_menu`),
  KEY `id_parent` (`id_parent`),
  KEY `status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=100 DEFAULT CHARSET=latin1;

INSERT INTO `menu_navigasi` VALUES (1,"MASTER DATA","#",0,2,"database",0),
(2,"Menu Navigasi","menu-navigasi",1,1,"bars",0),
(3,"Login","login",1,2,"users",0),
(4,"Hak Akses","systemrole",1,3,"user-tag",0),
(5,"Barang","akt-item",1,4,"box",0),
(6,"Mitra Bisnis","akt-mitra-bisnis",1,5,"users",0),
(7,"Merk Barang","akt-merk",1,6,"boxes",0),
(8,"Akun","akt-akun",1,7,"check",0),
(9,"Gudang","akt-gudang",1,8,"home",0),
(10,"Kas/Bank","akt-kas-bank",1,9,"building",0),
(11,"Terminal Kasir","akt-terminal-kasir",1,10,"train",1),
(12,"Mesin EDC","akt-mesin-edc",1,11,"calendar-alt",1),
(13,"Kartu Kredit","akt-credit-card",1,12,"credit-card",1),
(14,"Departemen","akt-departement",1,13,"clipboard-list",1),
(15,"Proyek","akt-proyek",1,14,"gavel",1),
(16,"Kota","akt-kota",1,15,"map-marker-alt",0),
(17,"Cabang","akt-cabang",1,16,"flag-checkered",1),
(18,"Mata Uang","akt-mata-uang",1,17,"usd",0),
(19,"Pajak","akt-pajak",1,18,"hand-holding-usd",1),
(20,"Pegawai","akt-pegawai",1,19,"user-tie",0),
(21,"Sales","akt-sales",1,20,"street-view",0),
(22,"Penagih","akt-penagih",1,21,"address-book",1),
(23,"Level Harga","akt-level-harga",1,22,"level-up-alt",0),
(24,"PEMBELIAN","#",0,2,"cart-plus",0),
(25,"Permintaan Pembelian","akt-permintaan-pembelian",24,1,"file",1),
(26,"Order Pembelian","akt-pembelian",24,2,"barcode",0),
(27,"Penerimaan Pembelian","akt-pembelian-penerimaan-sendiri",24,4,"handshake-o ",0),
(28,"Pembelian","akt-pembelian-pembelian",24,3,"shopping-cart ",0),
(29,"Tipe Barang","akt-item-tipe",1,23,"list",0),
(30,"Satuan","akt-satuan",1,24,"list",0),
(31,"Pembelian Harta Tetap","akt-pembelian-harta-tetap",24,6,"list-alt",0),
(32,"STOK","#",0,3,"warehouse",0),
(33,"PRODUKSI","#",0,4,"chart-area",0),
(34,"KAS / BANK","#",0,5,"money-check-alt",0),
(35,"PENJUALAN","#",0,6,"shopping-cart",0),
(36,"AKUNTANSI","#",0,7,"chart-bar",0),
(37,"SISTEM","#",0,8,"cogs",0),
(38,"Permintaan Barang","akt-permintaan-barang",32,1,"list",1),
(39,"Klasifikasi","akt-klasifikasi",1,25,"list",0),
(40,"Bill of Material","akt-bom",33,1,"credit-card ",0),
(41,"Penyesuaian Stok","akt-penyesuaian-stok",32,2,"th-large",0),
(42,"Produksi B.o.M","akt-produksi-bom",33,2,"area-chart",0),
(43,"Stok Masuk","akt-stok-masuk",32,3,"cart-plus",0),
(44,"Produksi Manual","akt-produksi-manual",33,3,"area-chart",0),
(45,"Stok Keluar","akt-stok-keluar",32,4,"cart-plus",0),
(46,"Laporan Produksi","akt-laporan-produksi",33,4,"fa fa-file",0),
(47,"Transfer Stok","akt-transfer-stok",32,5,"truck",0),
(48,"Stok Opname","akt-stok-opname",32,6,"cubes",0),
(49,"Penerimaan Biaya","akt-penerimaan-pembayaran",34,1,"money-check-alt",0),
(50,"Pembayaran","akt_pembayaran",34,2,"money-check-alt",1),
(51,"Pembayaran Biaya","akt-pembayaran-biaya",34,3,"money-check-alt",0),
(52,"Uang Muka","akt-uang-muka",34,4,"money-check-alt",1),
(53,"Lihat Kas","akt-lihat-kas",34,5,"money-check-alt",0),
(54,"Lihat Piutang","akt-piutang",34,6,"money-check-alt",0),
(55,"Penyesuaian Kas","akt-penyesuaian-kas",34,8,"fa fa-tasks",0),
(56,"Transfer Kas","akt-transfer-kas",34,8,"fa fa-book",0),
(57,"Cek/Giro","akt-cek-giro",34,9,"fa fa-list-alt",0),
(58,"Rekonsiliasi Bank","akt-rekonsiliasi-bank",34,10,"money-check-alt",1),
(59,"Laporan Kas","akt-laporan-kas",34,11,"folder",0),
(60,"Penawaran Penjualan","akt-penawaran-penjualan",35,1,"shopping-cart",1),
(61,"Order Penjualan","akt-penjualan",35,2,"shopping-cart",0),
(62,"Penjualan","akt-penjualan-penjualan",35,3,"shopping-cart",0),
(63,"Pengiriman","akt-penjualan-pengiriman-parent",35,4,"truck",0),
(65,"Penjualan Harta Tetap","akt-penjualan-harta-tetap",35,10,"shopping-cart",0),
(67,"Retur Penjualan","akt-retur-penjualan",35,8,"shopping-cart",0),
(68,"Nota Potong","akt-nota-poong",35,9,"shopping-cart",1),
(69,"Jurnal Umum","akt-jurnal-umum",36,1,"chart-bar",0),
(70,"Tutup Buku","akt-tutup-buku",36,2,"chart-bar",0),
(71,"Tutup Buku Tahun","akt-tutup-buku-tahun",36,3,"chart-bar",1),
(73,"Anggaran","akt-anggaran",36,5,"money",0),
(74,"Harta Tetap","akt-harta-tetap",1,29,"chart-bar",1),
(76,"Kelompok Harta Tetap","akt-kelompok-harta-tetap",36,6,"chart-bar",0),
(77,"Laporan Stok","akt-laporan-stok",32,7,"file",0),
(78,"Jurnal Transaksi","jurnal-transaksi",1,26,"chart-bar",0),
(79,"Data Perusahaan","setting",37,1,"hospital-o",0),
(80,"Lihat Hutang","akt-hutang",34,7,"money-check-alt",0),
(81,"Retur Pembelian","akt-retur-pembelian",24,5,"list",0),
(82,"Harta Tetap","akt-harta-tetap/index-akutansi",36,7,"fa fa-car",0),
(83,"Pengafkiran Harta Tetap","#",36,10,"money-check-alt",1),
(84,"Laporan Akuntansi","akt-laporan-akuntansi",36,12,"file",0),
(85,"Approver","akt-approver",1,27,"users",0),
(86,"Jenis Approver","akt-jenis-approver",1,28,"users",0),
(87,"Pengajuan Biaya","akt-pengajuan-biaya",34,12,"book",0),
(88,"Lihat Stok","akt-lihat-stok",32,8,"cube",0),
(89,"Set Saldo Awal Kas","akt-saldo-awal-kas",37,2,"bank",0),
(90,"Set Saldo Awal Akun","akt-saldo-awal-akun",37,3,"fa fa-check",0),
(91,"Set Saldo Awal Stok","akt-saldo-awal-stok",37,4,"cube",0),
(92,"Home","site",0,1,"home",0),
(93,"Jurnal Penyesuaian","akt-jurnal-umum-penyesuaian",36,11,"book",0),
(94,"Laporan Penjualan","akt-laporan-penjualan",35,11,"file-text",0),
(95,"Laporan Pembelian","akt-laporan-pembelian",24,7,"file-text",0),
(96,"Log","log",37,5,"list-ul",0),
(97,"Rekap Log","log/rekap-log",37,6,"list-ul",0),
(98,"Depresiasi","akt-depresiasi-harta-tetap",36,8,"database",0),
(99,"Pengaturan","pengaturan",37,7,"cog",0);


DROP TABLE IF EXISTS `menu_navigasi_role`;

CREATE TABLE `menu_navigasi_role` (
  `id_menu_role` int(11) NOT NULL AUTO_INCREMENT,
  `id_menu` int(11) NOT NULL,
  `id_system_role` int(11) NOT NULL,
  PRIMARY KEY (`id_menu_role`),
  KEY `id_menu` (`id_menu`),
  KEY `id_system_role` (`id_system_role`)
) ENGINE=InnoDB AUTO_INCREMENT=150 DEFAULT CHARSET=latin1;

INSERT INTO `menu_navigasi_role` VALUES (4,3,1),
(5,4,1),
(6,5,1),
(7,6,1),
(8,7,1),
(9,8,1),
(10,9,1),
(11,10,1),
(12,11,1),
(13,12,1),
(14,13,1),
(15,14,1),
(16,15,1),
(17,16,1),
(18,17,1),
(20,19,1),
(21,20,1),
(22,21,1),
(23,22,1),
(24,23,1),
(25,24,1),
(26,25,1),
(27,26,1),
(29,27,1),
(30,28,1),
(31,29,1),
(32,30,1),
(33,31,1),
(36,34,1),
(37,35,1),
(38,36,1),
(39,37,1),
(45,41,1),
(47,43,1),
(49,44,1),
(50,45,1),
(54,46,1),
(55,47,1),
(56,48,1),
(57,49,1),
(58,50,1),
(59,51,1),
(60,52,1),
(61,53,1),
(62,54,1),
(63,55,1),
(64,56,1),
(65,57,1),
(66,58,1),
(67,59,1),
(68,60,1),
(69,61,1),
(70,62,1),
(71,63,1),
(72,65,1),
(73,67,1),
(74,68,1),
(75,69,1),
(76,70,1),
(77,71,1),
(78,73,1),
(81,77,1),
(84,79,1),
(85,80,1),
(86,81,1),
(88,83,1),
(89,84,1),
(90,85,1),
(94,33,6),
(95,33,1),
(98,40,6),
(99,40,1),
(100,42,6),
(101,42,1),
(102,32,6),
(103,32,1),
(104,38,6),
(105,38,1),
(106,88,1),
(107,89,1),
(109,90,1),
(110,91,1),
(111,92,6),
(112,92,1),
(113,93,1),
(117,1,9),
(118,1,1),
(122,87,9),
(123,87,1),
(124,76,9),
(125,76,1),
(126,74,9),
(127,74,1),
(128,94,9),
(129,94,1),
(131,95,6),
(132,95,1),
(134,78,9),
(135,2,9),
(136,18,9),
(137,39,9),
(138,86,9),
(139,96,9),
(140,96,1),
(141,97,9),
(142,97,1),
(143,82,1),
(144,98,9),
(145,98,6),
(146,98,1),
(147,99,9),
(148,99,6),
(149,99,1);


DROP TABLE IF EXISTS `pengaturan`;

CREATE TABLE `pengaturan` (
  `id_pengaturan` int(11) NOT NULL AUTO_INCREMENT,
  `nama_pengaturan` varchar(40) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_pengaturan`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

INSERT INTO `pengaturan` VALUES (1,"Button Pembelian",1),
(2,"Button Penjualan",1);


DROP TABLE IF EXISTS `setting`;

CREATE TABLE `setting` (
  `id_setting` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(200) NOT NULL,
  `nama_usaha` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `alamat` text NOT NULL,
  `id_kota` int(11) NOT NULL,
  `telepon` varchar(50) NOT NULL,
  `fax` varchar(200) NOT NULL,
  `npwp` varchar(200) NOT NULL,
  `direktur` varchar(200) NOT NULL,
  `foto` varchar(255) NOT NULL,
  PRIMARY KEY (`id_setting`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `setting` VALUES (1,"GSS ACCOUNTING","SOFTWARE HOUSE","accounting@klikgss.com","Jl. MH THAMRIN NO 28, \r\nSemarang, Indonesia",1,085998887776,123456789,987654321,"Daniel ","1603508414_maintenance_page-12f699da.jpg");


DROP TABLE IF EXISTS `system_role`;

CREATE TABLE `system_role` (
  `id_system_role` int(11) NOT NULL AUTO_INCREMENT,
  `nama_role` varchar(50) NOT NULL,
  PRIMARY KEY (`id_system_role`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

INSERT INTO `system_role` VALUES (1,"SYSTEM ADMINISTRATOR"),
(6,"MANAGER"),
(9,"DEVELOPER");


DROP TABLE IF EXISTS `user_role`;

CREATE TABLE `user_role` (
  `id_user_role` int(11) NOT NULL AUTO_INCREMENT,
  `id_system_role` int(11) NOT NULL,
  `id_login` int(11) NOT NULL,
  PRIMARY KEY (`id_user_role`),
  KEY `id_system_role` (`id_system_role`),
  KEY `id_login` (`id_login`)
) ENGINE=MyISAM AUTO_INCREMENT=31 DEFAULT CHARSET=latin1;

INSERT INTO `user_role` VALUES (1,1,1),
(5,1,2),
(18,9,3),
(6,6,4),
(7,6,5),
(8,6,6),
(9,6,7),
(10,6,8),
(11,1,8),
(12,1,9),
(14,6,10),
(28,9,11),
(19,1,3),
(20,9,12),
(21,1,12),
(22,6,13),
(23,1,13),
(24,9,15),
(25,1,15),
(26,6,16),
(27,1,16),
(29,1,11),
(30,1,17);


SET foreign_key_checks = 1;
